import Promoted from './promoted';
import PromotionPopup from './promotionPopup';

import '@babel/polyfill';

export {
  Promoted,
  PromotionPopup,
};
