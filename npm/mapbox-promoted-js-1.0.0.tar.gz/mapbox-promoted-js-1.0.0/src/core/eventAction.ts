import mapboxgl, { Map } from 'mapbox-gl';
import { CONFIG } from 'utils/config';
import { isUrl } from 'utils/string';
import { tileToQuadkey, coordianteToTile } from 'utils/geometry';
import EventData from './eventData';
import { EVENT_TYPES } from './helpers';

class EventAction implements Promoted.EventAction {
  private _map: mapboxgl.Map;
  private _promoted: Promoted.Core;
  private _session: Promoted.Session;
  private _source?: Promoted.Source;
  private _logger: Promoted.Logger;
  private _renderedFeatureLogs: { [featureId: string]: FeatureLog } = {};
  private _requestingImageIds: string[] = [];
  private _preZoomLevel: number;
  private _lastActionType?: string;

  constructor(map: Map, promoted: Promoted.Core, session: Promoted.Session, logger: Promoted.Logger) {
    this._map = map;
    this._promoted = promoted;
    this._session = session;
    this._logger = logger;
    this._preZoomLevel = this._map.getZoom();

    this._session.sessoinEndCallback = this.updateRenderedFeatureSessions.bind(this);
    this._lastActionType = 'load';

    this._map.on('load', this.load.bind(this));
    this._map.on('moveend', this.moveend.bind(this));
    this._map.on('click', this.updateSession.bind(this));
    this._map.on('idle', this.idle.bind(this));
    this._map.on('styleimagemissing', this.styleImageMissing.bind(this));

    window.addEventListener('load', () => this.activate());
    document.readyState === 'complete' && this.activate();
  }

  set source(source: Promoted.Source) {
    this._source = source;
  }

  private activate() {
    window.renderApp && window.renderApp(CONFIG);
  }

  private load(event: mapboxgl.MapboxEvent<any> & mapboxgl.EventData) {
    try {
      this.updateSourcedata(event);
      this._promoted.fire(new EventData(EVENT_TYPES.LOAD, { map: event.target }));
      this._session.start();
    } catch(error) {
      console.error(error);
      (error instanceof Error) && this._logger.log('error_internal', error.stack || error.message);
    }
  }

  private updateSourcedata(event: mapboxgl.MapboxEvent<any> & mapboxgl.EventData) {
    if (!this._source) {
      throw new Error('It did not initialize source module.');
    }
    const bounds = this._map.getBounds();
    const z = Math.floor(this._map.getZoom());
    const sw = bounds.getSouthWest();
    const ne = bounds.getNorthEast();
    const startTile = coordianteToTile(sw.lng, sw.lat, z);
    const endTile = coordianteToTile(ne.lng, ne.lat, z);
    const tiles = [];
    const quadkeys = [];
    for (let x = startTile.x; x <= endTile.x; x ++) {
      for (let y = endTile.y; y <= startTile.y; y ++) {
        const quadkey = tileToQuadkey(x, y, z);
        quadkeys.push(quadkey);
        tiles.push({ x, y, z, quadkey });
      }
    }
    this._source.addSource(quadkeys);
    this._promoted.fire(
      new EventData(EVENT_TYPES.SOURCEDATA, {
        map: this._map,
        originalEvent: event.originalEvent,
        tiles
      })
    );
  }

  private moveend(event: mapboxgl.MapboxEvent<any> & mapboxgl.EventData) {
    try {
      const zoomLevel = this._map.getZoom();
      const isZoomed = this._preZoomLevel !== zoomLevel;

      this._lastActionType = isZoomed ? 'zoom' : 'move';
      this.updateSourcedata(event);

      if (isZoomed) {
        this._preZoomLevel = zoomLevel;
        this._promoted.fire(
          new EventData(EVENT_TYPES.ZOOMEND, {
            map: event.target,
            originalEvent: event.originalEvent,
          })
        );
      } else {
        this._promoted.fire(
          new EventData(EVENT_TYPES.MOVEEND, {
            map: event.target,
            originalEvent: event.originalEvent,
          })
        );
      }
      this._session.update();
    } catch (error: any) {
      console.error(error);
      this._logger.log('error_internal', error);
    }
  }

  public click(event: mapboxgl.MapMouseEvent & { features?: mapboxgl.MapboxGeoJSONFeature[] | undefined; } & mapboxgl.EventData) {
    try {
      const feature = event.features && event.features[0] as Feature;
      if (!feature) { return; }
      this._promoted.fire(new EventData(EVENT_TYPES.CLICK_PIN, {
        map: event.target,
        originalEvent: event.originalEvent,
        feature,
      }));
      this._promoted.show(feature);
    } catch (error: any) {
      console.error(error);
      this._logger.log('error_internal', error);
    }
  }

  private idle(event: mapboxgl.MapboxEvent & mapboxgl.EventData) {
    const { appearedFeatures, disappearedFeatures } = this.updateRenderedFeatures();
    this._promoted.fire(
      new EventData(EVENT_TYPES.SOURCEDATAEND, {
        map: this._map,
        originalEvent: event.originalEvent,
        appearedFeatures,
        disappearedFeatures,
      })
    );
  }

  private styleImageMissing(event: any) {
    try {
      const imageId: string = event.id;
      const isRequesting = this._requestingImageIds.find(requestingImageId => requestingImageId === imageId);
      const isRequested = this._map.hasImage(imageId);
      if (!imageId || isRequesting || isRequested) {
        return;
      }
      this._requestingImageIds.push(imageId);
      if (isUrl(imageId)) {
        this._map.loadImage(imageId, (error?: Error, image?: HTMLImageElement | ImageBitmap) => {
          this._requestingImageIds = this._requestingImageIds.filter(requestingImageId => requestingImageId !== imageId);
          if (error) { throw error; }
          if (!image) { throw new Error('Failed getting image.'); }
          this._map.addImage(imageId, image);
        });
      }
    } catch (error: any) {
      console.error(error);
      this._logger.log('error_internal', error);
    }
  }

  private updateSession() {
    this._session.update();
  }

  public updateRenderedFeatureSessions() {
    const zoomLevel = this._map.getZoom();
    const featureLogs = Object.values(this._renderedFeatureLogs);
    const updateRenderedFeatureLogs: { [featureId: string]: FeatureLog } = {};
    const disappearedFeatureLogs: { [featureId: string]: FeatureLog } = {};

    for (const featureLog of featureLogs) {
      updateRenderedFeatureLogs[featureLog.feature.properties.feature_id] = {
        feature: featureLog.feature,
        startActionType: 'session',
        startZoomLevel: zoomLevel,
        visibleStartTime: Date.now(),
      };
      disappearedFeatureLogs[featureLog.feature.properties.feature_id] = {
        ...featureLog,
        endActionType: 'session',
        endZoomLevel: zoomLevel,
        visibleEndTime: Date.now(),
      };
    }

    this._renderedFeatureLogs = updateRenderedFeatureLogs;
    
    featureLogs.length && (
      this._logger.visibles(this._session.sessionId, Object.values(disappearedFeatureLogs))
    );
  }

  public updateRenderedFeatures(): {
    appearedFeatures: Feature[];
    disappearedFeatures: Feature[];
  } {
    const zoomLevel = this._map.getZoom();
    const features = this.getPromotionFeatures();
    const appearedFeatures: Feature[] = [];
    const appearedFeatureLogs: { [featureId: string]: FeatureLog } = {};
    const disappearedFeatures: Feature[] = [];
    const disappearedFeatureLogs: { [featureId: string]: FeatureLog } = {};

    // disappeared feature objects that was rendered before
    const updateRenderedFeatureLogs: { [featureId: string]: FeatureLog } = {};
    for (const featureLog of Object.values(this._renderedFeatureLogs)) {
      const isExist = !!features[featureLog.feature.properties.feature_id];
      if (!isExist) {
        disappearedFeatures.push(featureLog.feature);
        disappearedFeatureLogs[featureLog.feature.properties.feature_id] = {
          ...featureLog,
          endActionType: this._lastActionType,
          endZoomLevel: zoomLevel,
          visibleEndTime: Date.now(),
        };
      } else {
        updateRenderedFeatureLogs[featureLog.feature.properties.feature_id] = featureLog;
      }
    }
    this._renderedFeatureLogs = updateRenderedFeatureLogs;

    // adding appeared new feature objects
    for (const feature of Object.values(features)) {
      const isExisted = !!this._renderedFeatureLogs[feature.properties.feature_id];
      if (!isExisted && feature.properties.cps) {
        appearedFeatures.push(feature);
        appearedFeatureLogs[feature.properties.feature_id] = {
          feature,
          startActionType: this._lastActionType,
          startZoomLevel: zoomLevel,
          visibleStartTime: Date.now(),
        };
      }
    };
    this._renderedFeatureLogs = { ...this._renderedFeatureLogs, ...appearedFeatureLogs };

    Object.keys(disappearedFeatureLogs).length && (
      this._logger.visibles(this._session.sessionId, Object.values(disappearedFeatureLogs))
    );

    return {
      appearedFeatures,
      disappearedFeatures,
    }
  }

  public getPromotionFeatures(): { [key: string]: Feature } {
    if (!this._source || !this._source.layer) {
      return {};
    }
    const layers = [this._promoted.layerId];
    const features = this._map.queryRenderedFeatures(undefined, { layers }) as Feature[];
    const promotionFeatures: { [key: string]: Feature } = {};
    for (const feature of features) {
      promotionFeatures[feature.properties.feature_id] = feature;
    }
    return promotionFeatures;
  }
}

export default EventAction;
