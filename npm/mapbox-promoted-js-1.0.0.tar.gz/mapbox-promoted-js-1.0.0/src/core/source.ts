import mapboxgl, { Map } from 'mapbox-gl';
import { getFeatures } from 'apis/features';
import { COLORS } from 'utils/color';
import { quadkeyToTile, getTileCornerCoordinates } from 'utils/geometry';
import {
  createLayer,
  createSelectedTextColor,
  createSelectedTextHaloColor,
} from 'utils/layer';

class Source implements Promoted.Source {
  private _map: mapboxgl.Map;
  private _promoted: Promoted.Core;
  private _eventAction: Promoted.EventAction;
  private _logger: Promoted.Logger;
  private _source?: mapboxgl.GeoJSONSourceRaw;
  private _layer?: mapboxgl.SymbolLayer;
  private _tilesets: { [quadkey: string]: Feature[] } = {};
  private _features: { [featureId: string]: Feature } = {};
  private _isInitialRequired = false;

  constructor(map: Map, promoted: Promoted.Core, eventAction: Promoted.EventAction, logger: Promoted.Logger) {
    this._map = map;
    this._promoted = promoted;
    this._logger = logger;
    this._eventAction = eventAction;
  }

  get source(): mapboxgl.GeoJSONSource {
    return this._map.getSource(this.sourceId) as mapboxgl.GeoJSONSource;
  }

  get layer(): mapboxgl.SymbolLayer {
    return this._map.getLayer(this.layerId) as mapboxgl.SymbolLayer;
  }
  
  get sourceId(): string {
    return 'promoted-source';
  }

  get layerId() : string {
    return 'promoted-layer';
  }

  get tilesets(): { [quadkey: string]: Feature[] } {
    return this._tilesets;
  }

  private updateFeatures(quadkey: string, features: Feature[], isFetch = false) {
    try {
      const { x, y, z } = quadkeyToTile(quadkey);
      const cornerCoordinates = getTileCornerCoordinates(x, y, z);
   
      if (isFetch && Object.keys(this._features).length === 0) {
        this._features = this._eventAction.getPromotionFeatures();
      }
      if (isFetch) {
        this._tilesets[quadkey] = features;
      }
  
      // Adding or updating features by key.
      for (const feature of features) {
        this._features[feature.properties.feature_id] = feature;
      }
      // Remove features that are droped at the new auction.
      for (const feature of Object.values(this._features)) {
        const coordinates = (feature.geometry as any).coordinates;
        // Current features which are contained at the coordinates that was requested.
        if (
          cornerCoordinates.ne.lng <= coordinates[0] && coordinates[0] < cornerCoordinates.sw.lng &&
          cornerCoordinates.sw.lat <= coordinates[1] && coordinates[1] < cornerCoordinates.ne.lat
        ) {
          const targetFeature = features.find(responseFeature =>
            responseFeature.properties.feature_id === feature.properties.feature_id);
          if (!targetFeature) {
            delete this._features[feature.properties.feature_id];
          }
        }
        // else {
        //   delete this._features[feature.properties.id];
        // }
      }
      this.source && this.source.setData({
        type: 'FeatureCollection',
        features: Object.values(this._features),
      });
    } catch (error: any) {
      this._logger.log('error_internal', error);
    }
  }

  public requestFeatures(quadkeys: string[]) {
    for (const quadkey of quadkeys) {
      // It is already requested, and there are same data at this._tileset.
      if (this._tilesets[quadkey]) {
        const features = this._tilesets[quadkey];
        this.updateFeatures(quadkey, features);
        continue;
      }
      // There is not data with a quadkey, it need to make request.
      getFeatures(quadkey).then((response: GeoJSON.FeatureCollection<GeoJSON.Geometry> ) => {
        const features = response.features as Feature[];
        this.updateFeatures(quadkey, features, true);
      }).catch((error) => {
        console.error(error);
        if (error.status !== 0) {
          this._logger.log('error_internal', error.text || error.toString());
        }
      });
    }
  }

  public addSource(quadkeys: string[]) {
    this.requestFeatures(quadkeys);
    // WARNING: When if developer change map style like satellite, and update source and layer, it will happen warning like berow.
    // -> Unable to perform style diff: Unimplemented: setSprite.. Rebuilding the style from scratch.
    // When if happen this warning, soures and layers will be removed.
    // And rebuilding from scratch makes "this._isInitialRequired is true", but "this.source is undefined", because source was removed.
    // So this "if" branch is to avoid to make fatal error, to continue running application.
    if (this._isInitialRequired && this.source || quadkeys.length <= 0) {
      return;
    }
    this._isInitialRequired = true;
    this._source = {
      type: 'geojson',
      data: {
        type: 'FeatureCollection',
        features: []
      },
    };
    this._layer = createLayer(this.layerId, this.sourceId);
    this._map.addSource(this.sourceId, this._source);
    this._map.addLayer(this._layer);
    this._map.on('click', this.layerId, this._eventAction.click.bind(this));
  }

  public visibleLayer() {
    this._map.setLayoutProperty(this.layerId, 'visibility', 'visible');
  }

  public hideLayer() {
    this._map.setLayoutProperty(this.layerId, 'visibility', 'none');
  }

  public reload() {
    if (!this._isInitialRequired) {
      return;
    }
    this._source = undefined;
    this._tilesets = {};
    this._features = {};
    this._isInitialRequired = false;
    this.layer && this._map.removeLayer(this.layerId);
    this.source && this._map.removeSource(this.sourceId);
  }

  // private hasListener(type: EventTypes) {
  //   return !!this._listeners && this._listeners[type] && this._listeners[type].length > 0;
  // }

  public selectFeature(feature: Feature) {
    const { feature_id } = feature.properties;
    const textColor = createSelectedTextColor(feature_id);
    const textHaloColor = createSelectedTextHaloColor(feature_id);
    this._map.setPaintProperty(this.layerId, 'text-color', textColor);
    this._map.setPaintProperty(this.layerId, 'text-halo-color', textHaloColor);
  }

  public deselectLayer() {
    this._map.setPaintProperty(
      this.layerId,
      'text-color',
      this._promoted.isDarkMode ? COLORS.FONT_COLOR_LIGHT : COLORS.FONT_COLOR_DARK,
    );
    this._map.setPaintProperty(
      this.layerId,
      'text-halo-color',
      this._promoted.isDarkMode ? COLORS.FONT_HALO_COLOR_LIGHT : COLORS.FONT_HALO_COLOR_DARK,
    );
  }
}

export default Source;
