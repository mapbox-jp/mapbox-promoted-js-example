import { isUrl } from 'utils/string';

describe('utils/string.isUrl', () => {
  const httpsGeojsonUrl = 'https://test.co.jp/test.json';
  const httpGeojsonUrl = 'http://test.co.jp/test.json';
  const mapboxSourceUrl = 'mapbox://mapbox-ads.abcdefg';

  it('is http geojson', () => (
    expect(isUrl(httpsGeojsonUrl)).toEqual(true)
  ));

  it('is https geojson', () => (
    expect(isUrl(httpGeojsonUrl)).toEqual(true)
  ));

  it('is mapbox source url', () => (
    expect(isUrl(mapboxSourceUrl)).toEqual(false)
  ));
});
