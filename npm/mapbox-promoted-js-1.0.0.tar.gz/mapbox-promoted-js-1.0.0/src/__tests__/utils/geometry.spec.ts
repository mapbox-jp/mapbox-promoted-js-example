import {
  coordianteToTile,
  tileToQuadkey,
  quadkeyToTile,
  getTileCornerCoordinates,
  coordinateToQuadkey,
  tileToCoordinate,
} from 'utils/geometry';
import { COORDINATES, CORNER_COORDINATES, TILESETS } from 'mock/map';

describe('utils/geometry.coordianteToTile', () => {
  const test = (key, zoomLevel) => {
    const coordinates = COORDINATES[key];
    const tileset = TILESETS[key];
    expect(coordianteToTile(coordinates.lng, coordinates.lat, zoomLevel)).toMatchObject({
      x: tileset[zoomLevel].x,
      y: tileset[zoomLevel].y,
      z: zoomLevel,
    });
  };

  describe('Valid tile from coordinate at Tokyo', () => {
    it('zoom 21', () => test('TOKYO', 21));
    it('zoom 19', () => test('TOKYO', 19));
    it('zoom 17', () => test('TOKYO', 17));
    it('zoom 15', () => test('TOKYO', 15));
    it('zoom 13', () => test('TOKYO', 13));
    it('zoom 11', () => test('TOKYO', 11));
    it('zoom 9', () => test('TOKYO', 9));
    it('zoom 7', () => test('TOKYO', 7));
    it('zoom 5', () => test('TOKYO', 5));
    it('zoom 3', () => test('TOKYO', 3));
    it('zoom 1', () => test('TOKYO', 1));
  });

  describe('Valid tile from coordinate at Washington', () => {
    it('zoom 21', () => test('WASHINGTON', 21));
    it('zoom 19', () => test('WASHINGTON', 19));
    it('zoom 17', () => test('WASHINGTON', 17));
    it('zoom 15', () => test('WASHINGTON', 15));
    it('zoom 13', () => test('WASHINGTON', 13));
    it('zoom 11', () => test('WASHINGTON', 11));
    it('zoom 9', () => test('WASHINGTON', 9));
    it('zoom 7', () => test('WASHINGTON', 7));
    it('zoom 5', () => test('WASHINGTON', 5));
    it('zoom 3', () => test('WASHINGTON', 3));
    it('zoom 1', () => test('WASHINGTON', 1));
  });

  describe('Valid tile from coordinate at Sydney', () => {
    it('zoom 21', () => test('SYDNEY', 21));
    it('zoom 19', () => test('SYDNEY', 19));
    it('zoom 17', () => test('SYDNEY', 17));
    it('zoom 15', () => test('SYDNEY', 15));
    it('zoom 13', () => test('SYDNEY', 13));
    it('zoom 11', () => test('SYDNEY', 11));
    it('zoom 9', () => test('SYDNEY', 9));
    it('zoom 7', () => test('SYDNEY', 7));
    it('zoom 5', () => test('SYDNEY', 5));
    it('zoom 3', () => test('SYDNEY', 3));
    it('zoom 1', () => test('SYDNEY', 1));
  });

  describe('Valid tile from coordinate at London', () => {
    it('zoom 21', () => test('LONDON', 21));
    it('zoom 19', () => test('LONDON', 19));
    it('zoom 17', () => test('LONDON', 17));
    it('zoom 15', () => test('LONDON', 15));
    it('zoom 13', () => test('LONDON', 13));
    it('zoom 11', () => test('LONDON', 11));
    it('zoom 9', () => test('LONDON', 9));
    it('zoom 7', () => test('LONDON', 7));
    it('zoom 5', () => test('LONDON', 5));
    it('zoom 3', () => test('LONDON', 3));
    it('zoom 1', () => test('LONDON', 1));
  });
});

describe('utils/geometry.tileToQuadkey', () => {
  const test = (key, zoomLevel) => {
    const tileset = TILESETS[key][zoomLevel];
    expect(tileToQuadkey(tileset.x, tileset.y, zoomLevel)).toEqual(tileset.quadkey);
  };

  describe('Valid quadkey from tile at Tokyo', () => {
    it('zoom 21', () => test('TOKYO', 21));
    it('zoom 19', () => test('TOKYO', 19));
    it('zoom 17', () => test('TOKYO', 17));
    it('zoom 15', () => test('TOKYO', 15));
    it('zoom 13', () => test('TOKYO', 13));
    it('zoom 11', () => test('TOKYO', 11));
    it('zoom 9', () => test('TOKYO', 9));
    it('zoom 7', () => test('TOKYO', 7));
    it('zoom 5', () => test('TOKYO', 5));
    it('zoom 3', () => test('TOKYO', 3));
    it('zoom 1', () => test('TOKYO', 1));
  });

  describe('Valid quadkey from tile at Washington', () => {
    it('zoom 21', () => test('WASHINGTON', 21));
    it('zoom 19', () => test('WASHINGTON', 19));
    it('zoom 17', () => test('WASHINGTON', 17));
    it('zoom 15', () => test('WASHINGTON', 15));
    it('zoom 13', () => test('WASHINGTON', 13));
    it('zoom 11', () => test('WASHINGTON', 11));
    it('zoom 9', () => test('WASHINGTON', 9));
    it('zoom 7', () => test('WASHINGTON', 7));
    it('zoom 5', () => test('WASHINGTON', 5));
    it('zoom 3', () => test('WASHINGTON', 3));
    it('zoom 1', () => test('WASHINGTON', 1));
  });

  describe('Valid quadkey from tile at Sydney', () => {
    it('zoom 21', () => test('SYDNEY', 21));
    it('zoom 19', () => test('SYDNEY', 19));
    it('zoom 17', () => test('SYDNEY', 17));
    it('zoom 15', () => test('SYDNEY', 15));
    it('zoom 13', () => test('SYDNEY', 13));
    it('zoom 11', () => test('SYDNEY', 11));
    it('zoom 9', () => test('SYDNEY', 9));
    it('zoom 7', () => test('SYDNEY', 7));
    it('zoom 5', () => test('SYDNEY', 5));
    it('zoom 3', () => test('SYDNEY', 3));
    it('zoom 1', () => test('SYDNEY', 1));
  });

  describe('Valid quadkey from tile at London', () => {
    it('zoom 21', () => test('LONDON', 21));
    it('zoom 19', () => test('LONDON', 19));
    it('zoom 17', () => test('LONDON', 17));
    it('zoom 15', () => test('LONDON', 15));
    it('zoom 13', () => test('LONDON', 13));
    it('zoom 11', () => test('LONDON', 11));
    it('zoom 9', () => test('LONDON', 9));
    it('zoom 7', () => test('LONDON', 7));
    it('zoom 5', () => test('LONDON', 5));
    it('zoom 3', () => test('LONDON', 3));
    it('zoom 1', () => test('LONDON', 1));
  });
});

describe('utils/geometry.quadkeyToTile', () => {
  const test = (key, zoomLevel) => {
    const tileset = TILESETS[key][zoomLevel];
    expect(quadkeyToTile(tileset.quadkey)).toEqual({
      x: tileset.x,
      y: tileset.y,
      z: zoomLevel,
    });
  };

  describe('Valid tile from quadkey at Tokyo', () => {
    it('zoom 21', () => test('TOKYO', 21));
    it('zoom 19', () => test('TOKYO', 19));
    it('zoom 17', () => test('TOKYO', 17));
    it('zoom 15', () => test('TOKYO', 15));
    it('zoom 13', () => test('TOKYO', 13));
    it('zoom 11', () => test('TOKYO', 11));
    it('zoom 9', () => test('TOKYO', 9));
    it('zoom 7', () => test('TOKYO', 7));
    it('zoom 5', () => test('TOKYO', 5));
    it('zoom 3', () => test('TOKYO', 3));
    it('zoom 1', () => test('TOKYO', 1));
  });

  describe('Valid tile from quadkey at Washington', () => {
    it('zoom 21', () => test('WASHINGTON', 21));
    it('zoom 19', () => test('WASHINGTON', 19));
    it('zoom 17', () => test('WASHINGTON', 17));
    it('zoom 15', () => test('WASHINGTON', 15));
    it('zoom 13', () => test('WASHINGTON', 13));
    it('zoom 11', () => test('WASHINGTON', 11));
    it('zoom 9', () => test('WASHINGTON', 9));
    it('zoom 7', () => test('WASHINGTON', 7));
    it('zoom 5', () => test('WASHINGTON', 5));
    it('zoom 3', () => test('WASHINGTON', 3));
    it('zoom 1', () => test('WASHINGTON', 1));
  });

  describe('Valid tile from quadkey at Sydney', () => {
    it('zoom 21', () => test('SYDNEY', 21));
    it('zoom 19', () => test('SYDNEY', 19));
    it('zoom 17', () => test('SYDNEY', 17));
    it('zoom 15', () => test('SYDNEY', 15));
    it('zoom 13', () => test('SYDNEY', 13));
    it('zoom 11', () => test('SYDNEY', 11));
    it('zoom 9', () => test('SYDNEY', 9));
    it('zoom 7', () => test('SYDNEY', 7));
    it('zoom 5', () => test('SYDNEY', 5));
    it('zoom 3', () => test('SYDNEY', 3));
    it('zoom 1', () => test('SYDNEY', 1));
  });

  describe('Valid tile from quadkey at London', () => {
    it('zoom 21', () => test('LONDON', 21));
    it('zoom 19', () => test('LONDON', 19));
    it('zoom 17', () => test('LONDON', 17));
    it('zoom 15', () => test('LONDON', 15));
    it('zoom 13', () => test('LONDON', 13));
    it('zoom 11', () => test('LONDON', 11));
    it('zoom 9', () => test('LONDON', 9));
    it('zoom 7', () => test('LONDON', 7));
    it('zoom 5', () => test('LONDON', 5));
    it('zoom 3', () => test('LONDON', 3));
    it('zoom 1', () => test('LONDON', 1));
  });
});

describe('utils/geometry.getTileCornerCoordinates', () => {
  const test = (key, zoomLevel) => {
    const tileset = TILESETS[key][zoomLevel];
    const expectedCornerCoordinates = CORNER_COORDINATES[key][zoomLevel];
    const cornerCoordinates = getTileCornerCoordinates(tileset.x, tileset.y, zoomLevel);
    expect({
      sw: {
        lng: cornerCoordinates.sw.lng.toFixed(12),
        lat: cornerCoordinates.sw.lat.toFixed(12),
      },
      ne: {
        lng: cornerCoordinates.ne.lng.toFixed(12),
        lat: cornerCoordinates.ne.lat.toFixed(12),
      }
    }).toEqual({
      sw: {
        lng: expectedCornerCoordinates.sw.lng.toFixed(12),
        lat: expectedCornerCoordinates.sw.lat.toFixed(12),
      },
      ne: {
        lng: expectedCornerCoordinates.ne.lng.toFixed(12),
        lat: expectedCornerCoordinates.ne.lat.toFixed(12),
      }
    });
  };

  describe('Valid coordinates from tile at Tokyo', () => {
    it('zoom 21', () => test('TOKYO', 21));
    it('zoom 19', () => test('TOKYO', 19));
    it('zoom 17', () => test('TOKYO', 17));
    it('zoom 15', () => test('TOKYO', 15));
    it('zoom 13', () => test('TOKYO', 13));
    it('zoom 11', () => test('TOKYO', 11));
    it('zoom 9', () => test('TOKYO', 9));
    it('zoom 7', () => test('TOKYO', 7));
    it('zoom 5', () => test('TOKYO', 5));
    it('zoom 3', () => test('TOKYO', 3));
    it('zoom 1', () => test('TOKYO', 1));
  });

  describe('Valid coordinates from tile at London', () => {
    it('zoom 21', () => test('LONDON', 21));
    it('zoom 19', () => test('LONDON', 19));
    it('zoom 17', () => test('LONDON', 17));
    it('zoom 15', () => test('LONDON', 15));
    it('zoom 13', () => test('LONDON', 13));
    it('zoom 11', () => test('LONDON', 11));
    it('zoom 9', () => test('LONDON', 9));
    it('zoom 7', () => test('LONDON', 7));
    it('zoom 5', () => test('LONDON', 5));
    it('zoom 3', () => test('LONDON', 3));
    it('zoom 1', () => test('LONDON', 1));
  });
});

describe('utils/geometry.coordinateToQuadkey', () => {
  const test = (key, zoomLevel) => {
    const coordinates = COORDINATES[key];
    const tileset = TILESETS[key];
    expect(coordinateToQuadkey(coordinates.lng, coordinates.lat, zoomLevel)).toEqual(tileset[zoomLevel].quadkey);
  };

  describe('Valid quadkey from coordinate at Tokyo', () => {
    it('zoom 21', () => test('TOKYO', 21));
    it('zoom 19', () => test('TOKYO', 19));
    it('zoom 17', () => test('TOKYO', 17));
    it('zoom 15', () => test('TOKYO', 15));
    it('zoom 13', () => test('TOKYO', 13));
    it('zoom 11', () => test('TOKYO', 11));
    it('zoom 9', () => test('TOKYO', 9));
    it('zoom 7', () => test('TOKYO', 7));
    it('zoom 5', () => test('TOKYO', 5));
    it('zoom 3', () => test('TOKYO', 3));
    it('zoom 1', () => test('TOKYO', 1));
  });

  describe('Valid quadkey from coordinate at Washington', () => {
    it('zoom 21', () => test('WASHINGTON', 21));
    it('zoom 19', () => test('WASHINGTON', 19));
    it('zoom 17', () => test('WASHINGTON', 17));
    it('zoom 15', () => test('WASHINGTON', 15));
    it('zoom 13', () => test('WASHINGTON', 13));
    it('zoom 11', () => test('WASHINGTON', 11));
    it('zoom 9', () => test('WASHINGTON', 9));
    it('zoom 7', () => test('WASHINGTON', 7));
    it('zoom 5', () => test('WASHINGTON', 5));
    it('zoom 3', () => test('WASHINGTON', 3));
    it('zoom 1', () => test('WASHINGTON', 1));
  });

  describe('Valid quadkey from coordinate at Sydney', () => {
    it('zoom 21', () => test('SYDNEY', 21));
    it('zoom 19', () => test('SYDNEY', 19));
    it('zoom 17', () => test('SYDNEY', 17));
    it('zoom 15', () => test('SYDNEY', 15));
    it('zoom 13', () => test('SYDNEY', 13));
    it('zoom 11', () => test('SYDNEY', 11));
    it('zoom 9', () => test('SYDNEY', 9));
    it('zoom 7', () => test('SYDNEY', 7));
    it('zoom 5', () => test('SYDNEY', 5));
    it('zoom 3', () => test('SYDNEY', 3));
    it('zoom 1', () => test('SYDNEY', 1));
  });

  describe('Valid quadkey from coordinate at London', () => {
    it('zoom 21', () => test('LONDON', 21));
    it('zoom 19', () => test('LONDON', 19));
    it('zoom 17', () => test('LONDON', 17));
    it('zoom 15', () => test('LONDON', 15));
    it('zoom 13', () => test('LONDON', 13));
    it('zoom 11', () => test('LONDON', 11));
    it('zoom 9', () => test('LONDON', 9));
    it('zoom 7', () => test('LONDON', 7));
    it('zoom 5', () => test('LONDON', 5));
    it('zoom 3', () => test('LONDON', 3));
    it('zoom 1', () => test('LONDON', 1));
  });
});

describe('utils/geometry.tileToCoordinate', () => {
  const test = (key, zoomLevel) => {
    const tileset = TILESETS[key][zoomLevel];
    const cornerCoordinates = CORNER_COORDINATES[key][zoomLevel];
    const coordinate = tileToCoordinate(tileset.x, tileset.y, zoomLevel);
    expect({
      lng: coordinate.lng.toFixed(12),
      lat: coordinate.lat.toFixed(12),
    }).toEqual({
      lng: cornerCoordinates.ne.lng.toFixed(12),
      lat: cornerCoordinates.ne.lat.toFixed(12),
    });
  };

  describe('Valid coordinate from tile at Tokyo', () => {
    it('zoom 21', () => test('TOKYO', 21));
    it('zoom 19', () => test('TOKYO', 19));
    it('zoom 17', () => test('TOKYO', 17));
    it('zoom 15', () => test('TOKYO', 15));
    it('zoom 13', () => test('TOKYO', 13));
    it('zoom 11', () => test('TOKYO', 11));
    it('zoom 9', () => test('TOKYO', 9));
    it('zoom 7', () => test('TOKYO', 7));
    it('zoom 5', () => test('TOKYO', 5));
    it('zoom 3', () => test('TOKYO', 3));
    it('zoom 1', () => test('TOKYO', 1));
  });

  describe('Valid coordinate from tile at London', () => {
    it('zoom 21', () => test('LONDON', 21));
    it('zoom 19', () => test('LONDON', 19));
    it('zoom 17', () => test('LONDON', 17));
    it('zoom 15', () => test('LONDON', 15));
    it('zoom 13', () => test('LONDON', 13));
    it('zoom 11', () => test('LONDON', 11));
    it('zoom 9', () => test('LONDON', 9));
    it('zoom 7', () => test('LONDON', 7));
    it('zoom 5', () => test('LONDON', 5));
    it('zoom 3', () => test('LONDON', 3));
    it('zoom 1', () => test('LONDON', 1));
  });
});
