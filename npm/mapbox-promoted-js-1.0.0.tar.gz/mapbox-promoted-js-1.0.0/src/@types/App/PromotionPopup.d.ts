declare namespace PromotionPopup {
  const CLICK_TYPES: {
    readonly ADS: 'Ads';
    readonly CARD: 'Card';
    readonly BANNER: 'BannerDetail';
    readonly CALL: 'Call';
    readonly NAVIGATION: 'Navigation';
    readonly DETAIL: 'Detail';
  };
  export type ClickTypes = typeof CLICK_TYPES[keyof typeof CLICK_TYPES];
}

declare var showPromotionPopup: ((
  feature: Feature,
  onClick?: (type: PromotionPopup.ClickTypes, feature: Feature) => void,
  onClose?: (feature: Feature) => void
) => void) | undefined;
declare var closePromotionPopup: ((feature: Feature) => void) | undefined;
