import ReactDOM from 'react-dom';
import React, { useRef, useEffect, useState, useMemo, useCallback } from 'react';
import { PROMOTION_TYPES } from 'core/helpers';
import { isSmall, isMedium } from 'utils/browser';
import Card from 'molecules/Card';
// import LandscapeCard from 'molecules/LandscapeCard';
// import Images from 'molecules/Images';
// import Video from 'molecules/Video';
import { GlobalStyle } from './styles';

type CloseHandler = {
  featureId: string;
  close: () => void;
};
let closeHandlers: CloseHandler[] = [];

window.showPromotionPopup = (
  feature: Feature,
  onClick?: (type: PromotionPopup.ClickTypes, feature: Feature) => void,
  onClose?: (feature: Feature) => void
) => {
  const element = document.querySelector(`.mapbox-promoted-popup__content__feature-${feature.properties.feature_id}`);
  if (!element) { return; }
  const content = element.querySelector('.mapbox-promoted-popup__content');
  !content && ReactDOM.render(
    <Popup
      feature={feature}
      onClick={onClick}
      onClose={onClose}
    />,
    element
  );
};

window.closePromotionPopup = (feature: Feature) => {
  const { properties } = feature;
  const { feature_id } = properties;
  const closeHandler = closeHandlers.find(handler => handler.featureId === feature_id);
  if (!closeHandler) { return; }
  closeHandler.close();
  closeHandlers = closeHandlers.filter(closeHandler => closeHandler.featureId !== feature_id);
};

type Props = {
  feature: Feature;
  onClick?: (type: PromotionPopup.ClickTypes, feature: Feature) => void;
  onClose?: (feature: Feature) => void;
};

const Popup: React.FC<Props> = props => {
  const { feature, onClick, onClose } = props;
  const { properties } = feature;
  const { promotion_type, feature_id } = properties;

  const ref = useRef<HTMLDivElement>(null);
  const [isFadeout, setIsFadeout] = useState(false);
  const [isRendered, setIsRendered] = useState(false);

  const enableScale = useMemo(() =>
    promotion_type === undefined || promotion_type === PROMOTION_TYPES.CARD, []);

  const handleClick = (type: PromotionPopup.ClickTypes) => {
    onClick && onClick(type, feature);
  };
  const handleClickOutside = useCallback(
    (event: MouseEvent) => {
      if (ref.current && !ref.current.contains(event.target as Node)) {
        close();
      }
    }, []
  );
  const handleResize = useCallback(
    () => {
      if (ref.current) {
        const clientWidth = ref.current.clientWidth;
        const clientHeight = ref.current.clientHeight;
        const popupContent = document.querySelector(`.mapbox-promoted-popup__content__feature-${feature_id}`) as HTMLElement;
        const popup = document.querySelector(`.mapbox-promoted-popup__feature-${feature_id}`) as HTMLElement;
        const width = enableScale ? `calc(${clientWidth}px * ${isSmall() ? '0.8' : isMedium() ? '0.9' : '1.0'})` : `${clientWidth}px`;
        const height = enableScale ? `calc(${clientHeight}px * ${isSmall() ? '0.8' : isMedium() ? '0.9' : '1.0'})` : `${clientHeight}px`;
        if (popupContent) {
          popupContent.style.width = width;
          popupContent.style.height = height;
        }
        if (popup) {
          popup.style.width = width;
          popup.style.height = height;
        }
        setIsRendered(true);
      }
    }, []
  );

  const renderPromotion = () => {
    switch (promotion_type) {
      case PROMOTION_TYPES.CARD:
      default:
        return (
          <Card 
            feature={feature}
            isRendered={isRendered}
            isFadeout={isFadeout}
            onClick={handleClick}
            ref={ref}
          />
        );
    }
  };
  const close = () => {
    setIsFadeout(true);
    setTimeout(() => {
      onClose && onClose(feature);
      const popup = document.querySelector(`.mapbox-promoted-popup__feature-${feature_id}`);
      if (!popup || !popup.parentNode) { return; }
      popup.parentNode.removeChild(popup);
    }, 150);
    removeEventListeners();
  };
  const removeEventListeners = () => {
    document.removeEventListener('click', handleClickOutside);
    window.removeEventListener('resize', handleResize);
  };

  useEffect(() => {
    closeHandlers.push({ featureId: feature_id, close: () => close() });
    document.addEventListener('click', handleClickOutside);
    window.addEventListener('resize', handleResize);
    return () => removeEventListeners();
  }, []);
  useEffect(() => {
    handleResize();
  }, [ref]);

  return (
    <>
      <GlobalStyle />
      {renderPromotion()}
    </>
  );
};

export default Popup;
