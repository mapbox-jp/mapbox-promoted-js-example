import React, { useMemo } from 'react';
import { DEFAULT_BANNER_SIZE } from 'utils/config';
import PromotionTag from 'atoms/PromotionTag';
import ActionItems from './ActionItems';
import MenuItems from './MenuItems';
import {
  GlobalStyle,
  Container,
  Wrapper,
  Banner,
  BannerImg,
  Content,
  Header,
  HeaderTitle,
  HeaderTitleLabel,
  HeaderPromotionTag,
  HeaderSubtitle,
  HeaderSubtitleLabel,
  ActionsContainer,
  Actions,
  ActionSpace,
  MenuContainer,
  Menu,
} from './styles';
import { CLICK_TYPES } from './helpers';

const PREFIX_CLASSNAME = 'promotion-popup__card';

type Props = {
  feature: Feature;
  isFadeout: boolean;
  isRendered: boolean;
  onClick: (type: PromotionPopup.ClickTypes, feature: Feature) => void;
};

const Card = React.forwardRef<HTMLDivElement, Props>((props, ref) => {
  const { feature, isFadeout, isRendered, onClick } = props;
  const { properties } = feature;
  const { name_ja, subtitle, promotion_banner } = properties;

  const bannerSize = useMemo(() => {
    const { promotion_banner_width, promotion_banner_height } = properties;
    return {
      width: promotion_banner_width || DEFAULT_BANNER_SIZE.WIDTH,
      height: promotion_banner_height || DEFAULT_BANNER_SIZE.HEIGHT,
    };
  }, [properties]);

  const handleClick = (type: PromotionPopup.ClickTypes) => {
    onClick && onClick(type, feature);
  };

  return (
    <>
      <GlobalStyle />
      <Container
        className={PREFIX_CLASSNAME}
        isFadeout={isFadeout}
        isRendered={isRendered}
        onClick={() => handleClick(CLICK_TYPES.CARD)}
        ref={ref}
      >
        <Wrapper
          className={`${PREFIX_CLASSNAME}-wrapper`}
          isRendered={isRendered}
        >
          <Banner
            className={`${PREFIX_CLASSNAME}__banner`}
            height={280 / bannerSize.width * bannerSize.height}
            onClick={() => handleClick(CLICK_TYPES.BANNER)}
          >
            <BannerImg
              className={`${PREFIX_CLASSNAME}__banner-img`}
              src={promotion_banner}
              width={bannerSize.width}
              height={bannerSize.height}
            />
          </Banner>
          <Content className={`${PREFIX_CLASSNAME}-content`}>
            <Header className={`${PREFIX_CLASSNAME}__header`}>
              <HeaderTitle className={`${PREFIX_CLASSNAME}__header-title`}>
                <HeaderTitleLabel className={`${PREFIX_CLASSNAME}__header-title-label`}>
                  {name_ja || ''}
                </HeaderTitleLabel>
                <HeaderPromotionTag className={`${PREFIX_CLASSNAME}__header-promotion-tag-wrapper`}>
                  <PromotionTag
                    classPrefix={`${PREFIX_CLASSNAME}__header`}
                    onClick={() => handleClick(CLICK_TYPES.ADS)}
                  />
                </HeaderPromotionTag>
              </HeaderTitle>
              {subtitle && (
                <HeaderSubtitle className={`${PREFIX_CLASSNAME}__header__subtitle`}>
                  <HeaderSubtitleLabel className={`${PREFIX_CLASSNAME}__header__subtitle-label`}>
                    {subtitle}
                  </HeaderSubtitleLabel>
                </HeaderSubtitle>
              )}
            </Header>
            {properties && (
              <MenuContainer className={`${PREFIX_CLASSNAME}__menu-container`}>
                <Menu className={`${PREFIX_CLASSNAME}__menu`}>
                  <MenuItems properties={properties} onClick={handleClick} />
                </Menu>
              </MenuContainer>
            )}
            {properties && (
              <ActionsContainer className={`${PREFIX_CLASSNAME}__actions-container`}>
                <Actions className={`${PREFIX_CLASSNAME}__actions`}>
                  <ActionSpace className={`${PREFIX_CLASSNAME}__action-space`} />
                  <ActionItems properties={properties} onClick={handleClick} />
                  <ActionSpace className={`${PREFIX_CLASSNAME}__action-space`} />
                </Actions>
              </ActionsContainer>
            )}
          </Content>
        </Wrapper>
      </Container>
    </>
  );
});

export default Card;
