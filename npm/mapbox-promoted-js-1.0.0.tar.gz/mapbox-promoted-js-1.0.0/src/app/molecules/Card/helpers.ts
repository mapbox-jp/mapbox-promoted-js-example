export const CLICK_TYPES = {
  ADS: 'Ads',
  CARD: 'Card',
  BANNER: 'BannerDetail',
  CALL: 'Call',
  NAVIGATION: 'Navigation',
  DETAIL: 'Detail',
} as const;
