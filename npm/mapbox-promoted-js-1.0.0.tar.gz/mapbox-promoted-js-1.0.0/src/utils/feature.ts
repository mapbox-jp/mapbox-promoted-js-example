import { isSaturday, isSunday } from 'date-fns';

export const getOpenCloseLabel = (properties: Feature.Properties) => {
  const { sat_open, sat_close, sun_open, sun_close, week_open, week_close } = properties;
  const today = new Date();
  let open = '';
  let close = '';
  if (isSaturday(today) && sat_open && sat_close) {
    open = `${sat_open}`;
    close = `${sat_close}`;
  } else if (isSunday(today) && sun_open && sun_close) {
    open = `${sun_open}`;
    close = `${sun_close}`;
  } else if (week_open && week_close) {
    open = `${week_open}`;
    close = `${week_close}`;
  } else {
    return undefined;
  }
  for (let i = 4 - open.length; i > 0; i --) {
    open = '0' + open;
  }
  for (let i = 4 - close.length; i > 0; i --) {
    close = '0' + close;
  }
  const openMatch = `${open}`.match(/(\d{1,2})(\d{2})$/);
  const openHour = openMatch && openMatch.length >= 3 ? openMatch[1] : '';
  const openMin = openMatch && openMatch.length >= 3 ? openMatch[2] : '';
  const closeMatch = `${close}`.match(/(\d{1,2})(\d{2})$/);
  const closeHour = closeMatch && closeMatch.length >= 3 ? closeMatch[1] : '';
  const closeMin = closeMatch && closeMatch.length >= 3 ? closeMatch[2] : '';
  const openLanbel = `${openHour}:${openMin}`;
  const closeLanbel = `${closeHour}:${closeMin}`;
  return `${openLanbel} - ${closeLanbel}`;
};
