import rollup from 'rollup';
import pluginTypescript from '@rollup/plugin-typescript';
import pluginCommonjs from '@rollup/plugin-commonjs';
import pluginNodeResolve from '@rollup/plugin-node-resolve';
import { babel as pluginBabel, getBabelOutputPlugin } from '@rollup/plugin-babel';
import { terser as pluginTerser } from 'rollup-plugin-terser';
import pluginPolyfill from 'rollup-plugin-polyfill-node';
import { exec, spawn } from 'child_process';

import * as path from 'path';

const plugins = [
  getBabelOutputPlugin({
    allowAllFormats: true,
    presets: [
      [
        '@babel/preset-env',
        {
          targets: {
            ie: 11,
            edge: 16,
            chrome: 64,
            firefox: 58,
            safari: 11
          }
        }
      ]
    ]
  })
];

const __DEV__ = process.env.NODE_ENV === 'development';
!__DEV__ && (
  plugins.push(pluginTerser())
);

const config = [
  {
    input: 'src/core/index.ts',
    output: [
      {
        file: 'lib/core/browser/index.js',
        exports: 'named',
        name: 'PromotedCore',
        format: 'iife',
        sourcemap: __DEV__ ? 'inline' : '',
        globals: {
          'mapbox-gl': 'mapboxgl'
        },
        plugins
      },
      {
        file: 'lib/core/commonjs/index.js',
        exports: 'named',
        name: 'PromotedCore',
        format: 'amd',
        sourcemap: __DEV__ ? 'inline' : '',
        plugins
      }
    ],
    plugins: [
      pluginTypescript({
        tsconfig: 'tsconfig.json',
        module: 'esnext',
      }),
      pluginNodeResolve({
        browser: true
      }),
      pluginCommonjs({
        extensions: ['.js', '.ts']
      }),
      pluginBabel({
        babelHelpers: 'bundled',
        configFile: path.resolve(__dirname, '.babelrc.js'),
        exclude: /node_modules/
      }),
      pluginPolyfill()
    ],
    external: [
      'mapbox-gl'
    ]
  }
];

let isUpdating = false;
const watcher = rollup.watch(config);
const execute = (script) => {
  console.log(`start ${script}`);
  return new Promise((resolve, reject) => {
    const process = exec(script, (err, stdout, stderr) => {
      console.log(`end ${script}`);
      if (err) {
        reject(err);
      }
      resolve();
    });
    process.stdout.on('data', (data) => {
      console.log(data); 
    });
  });
};
watcher.on('event', async event => {
  if (event.code === 'END') {
    console.log('start');
    try {
      if (!isUpdating) {
        console.log('start 123123');
        const packageName = `mapbox-promoted-js-${process.env.VERSION}.tar.gz`;
        const examplePackagePath = `mapbox-promoted-js-example/npm/${packageName}`;
        // const promotedJsPath = 'node_modules/mapbox-promoted-js';
        await execute(`scripts/generate_package.sh ${process.env.VERSION}`);
        await execute(`[ -e ${examplePackagePath} ] && rm ${examplePackagePath}`);
        await execute(`rsync -a --ignore-existing tmp/${packageName} mapbox-promoted-js-example/npm/${packageName}`);
        await execute(`(cd mapbox-promoted-js-example/npm/; npm uninstall mapbox-promoted-js)`);
        await execute(`(cd mapbox-promoted-js-example/npm/; npm install webpack-cli)`);
        await execute(`(cd mapbox-promoted-js-example/npm/; npm install webpack-cli)`);
        await execute(`(cd mapbox-promoted-js-example/npm/; npm install webpack-cli)`);
        // await execute(`(cd mapbox-promoted-js-example/npm/; npm install file:${packageName})`);
        await execute(`(cd mapbox-promoted-js-example/npm/; npm run build:dev)`);
        // await execute(`(cd mapbox-promoted-js-example/npm/; yarn remove mapbox-promoted-js)`);
        // await execute(`(cd mapbox-promoted-js-example/npm/; yarn add file:${packageName})`);
        // await execute(`(cd mapbox-promoted-js-example/npm/; yarn)`);
        // await execute(`(cd mapbox-promoted-js-example/npm/; yarn build:dev)`);
      }
      console.log('end');
    } catch(error) {
      console.log(error);
    }
  }
});

export default config;
