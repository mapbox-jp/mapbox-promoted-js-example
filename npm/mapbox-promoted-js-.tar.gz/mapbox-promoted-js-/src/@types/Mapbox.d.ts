declare namespace MapboxJS {
  interface StyleImageMissingEvent {
    id?: string;
  }
}
