declare namespace Promoted {
  namespace AjaxError {
    type Options = {
      name?: string;
      url?: string;
    };
  }

  class AjaxError implements Error {
    constructor(message: string, status?: number, options?: AjaxError.Options);
    get text(): string;
    get message(): string;
    get status(): number | undefined;
    get name(): string;
    get url(): string;
    get stackAt(): string;
  }
}
