declare namespace Promoted {
  namespace Session {
    namespace Event {
      type Listener = (type: EventTypes, event: Promoted.EventData) => any;
      type Listeners = { [key: string]: Array<Listener> };
    }

    const EVENT_TYPES: {
      readonly START_SESSION: 'start_session';
      readonly UPDATE_SESSION: 'update_session';
      readonly END_SESSION: 'end_session';
    };
    type EventTypes = typeof EVENT_TYPES[keyof typeof EVENT_TYPES];
  
    class Event {
      public on(type: EventTypes, listener: Event.Listener): void;
      public off(type: EventTypes, listener: Event.Listener): void;
      public fire(event: EventData): void;
    }
  }
}
