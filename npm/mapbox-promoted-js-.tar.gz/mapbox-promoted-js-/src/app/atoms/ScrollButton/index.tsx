import React from 'react';
// Components
import Icon, { ICON_TYPE } from 'atoms/Icon';
import { Container } from './styles';

export const DIRECTION_TYPE = {
  LEFT: 'left',
  RIGHT: 'right',
};
export type DirectionType = typeof DIRECTION_TYPE[keyof typeof DIRECTION_TYPE];

export const SIZE_TYPE = {
  SMALL: 'small',
  MEDIUM: 'medium',
};
export type SizeType = typeof SIZE_TYPE[keyof typeof SIZE_TYPE];

type Props = {
  classPrefix?: string;
  type?: DirectionType;
  size?: SizeType;
  onClick?: () => void;
};

const ScrollButton: React.FC<Props> = props => {
  const { classPrefix, type, size, onClick } = props;
  const PREFIX_CLASSNAME = `${classPrefix}__scroll-button-${type}`;
  const fontSize = size === SIZE_TYPE.SMALL ? '12px' : '14px';
  const handleClick = () => onClick && onClick();
  return (
    <Container
      className={PREFIX_CLASSNAME}
      size={size}
      onClick={handleClick}
    >
      <Icon
        className={`${PREFIX_CLASSNAME}__icon`}
        type={type === DIRECTION_TYPE.LEFT ?
          ICON_TYPE.ANGLE_LEFT : ICON_TYPE.ANGLE_RIGHT}
        size={fontSize}
        width={fontSize}
        height={fontSize}
      />
    </Container>
  );
};

export default ScrollButton;
