import styled from 'styled-components';
import { SizeType, SIZE_TYPE } from './index';

type Container = {
  size?: SizeType;
};

export const Container = styled.span`
  display: flex;
  justify-content: center;
  align-items: center;
  width: ${({ size }: Container) => size === SIZE_TYPE.SMALL ? '22px' : '30px'};
  height: ${({ size }: Container) => size === SIZE_TYPE.SMALL ? '22px' : '30px'};
  border-radius: 50%;
  background-color: #ffffff;
  box-shadow: 0 0 5px rgb(0 0 0 / 30%);
  cursor: pointer;
  z-index: 5;
`;
