import React, { useRef, useMemo, useState } from 'react';
import { CONFIG } from 'utils/config';
import { getBusinessHoursLabel } from 'utils/businessHours';
// Components
import Icon, { ICON_TYPE } from 'atoms/Icon';
import BusinessHours from '../BusinessHours';
import News from '../News';
import Products from '../Products';
import Media from '../Media';
import {
  Container,
  Row,
  Title,
  OpenerIcon,
  Opener,
  BusinessHoursWrapper,
  Value,
  Label,
  LabelText,
  LabelTextWrapper,
  LabelAnchar,
  Remarks,
} from './styles';
import { CLICK_TYPES } from '../helpers';

type Props = {
  classPrefix?: string;
  feature: Feature;
  onClick: (
    type: Promotion.ClickTypes,
    profileItem?: Feature.ProfileItem
  ) => void;
};

const PREFIX_PROFILE_CLASSNAME = 'promotion-profile';

const Summary: React.FC<Props> = props => {
  const { classPrefix, feature, onClick } = props;
  const { properties } = feature;
  const {
    summary,
    address_ja,
    address_remark,
    business_hours,
    business_hours_remark,
    phone_number,
    promotion_url
  } = properties;
  const PREFIX_CLASSNAME = `${classPrefix}__summary`;

  const businessHoursRef = useRef<HTMLUListElement>(null);
  const [isOpeningBusinessHours, setIsOpeningBusinessHours] = useState(false);
  const profile = useMemo(
    () => properties.profile && typeof properties.profile === 'string' ?
      JSON.parse(properties.profile) : properties.profile,
    [properties.feature_id]
  );

  const enableProfile = profile && !!Object.values(profile).find(value => value);

  const handleClick = (type: Promotion.ClickTypes, item?: Feature.ProfileItem) => {
    if (!!business_hours && type === CLICK_TYPES.BUSINESS_HOURS) {
      setIsOpeningBusinessHours(!isOpeningBusinessHours);
    }
    onClick && onClick(type, item);
  };

  return (
    <Container
      className={PREFIX_CLASSNAME}
      enableProfile={enableProfile}
    >
      {summary ? (
        <Row
          className={`${PREFIX_CLASSNAME}__row`}
          onClick={() => handleClick(CLICK_TYPES.SUMMARY)}
        >
          <Title className={`${PREFIX_CLASSNAME}__row-title`}>
            概要
          </Title>
          <Value className={`${PREFIX_CLASSNAME}__row-value`}>
            <Label className={`${PREFIX_CLASSNAME}__row-label`}>
              <LabelText
                className={`${PREFIX_CLASSNAME}__row-label__text`}
                lineClamp='initial'
              >
                {summary}
              </LabelText>
            </Label>
          </Value>
        </Row>
      ) : null}
      {address_ja ? (
        <Row
          className={`${PREFIX_CLASSNAME}__row`}
          onClick={() => handleClick(CLICK_TYPES.ADDRESS)}
        >
          <Value className={`${PREFIX_CLASSNAME}__row-value`}>
            <Label className={`${PREFIX_CLASSNAME}__row-label`}>
              <Icon
                type={ICON_TYPE.MAP_MARKER_DOT}
                size='14px'
                width='14px'
                height='14px'
                color={CONFIG.BASE_COLOR}
                margin='0 12px 0 0'
              />
              {address_remark ? (
                <LabelTextWrapper className={`${PREFIX_CLASSNAME}__row-label__text-wrapper`}>
                  <LabelText className={`${PREFIX_CLASSNAME}__row-label__text`}>
                    {address_ja}
                  </LabelText>
                  <Remarks className={`${PREFIX_CLASSNAME}__row-title__remark`}>
                    {address_remark}
                  </Remarks>
                </LabelTextWrapper>
              ) : (
                <LabelText className={`${PREFIX_CLASSNAME}__row-label__text`}>
                  {address_ja}
                </LabelText>
              )}
            </Label>
          </Value>
        </Row>
      ) : null}
      <Row
        className={`${PREFIX_CLASSNAME}__row`}
        cursor='pointer'
        onClick={() => handleClick(CLICK_TYPES.BUSINESS_HOURS)}
      >
        <Value className={`${PREFIX_CLASSNAME}__row-value`}>
          <Label className={`${PREFIX_CLASSNAME}__row-label`}>
            <Icon
              type={ICON_TYPE.CLOCK}
              size='14px'
              width='14px'
              height='14px'
              color={CONFIG.BASE_COLOR}
              margin='0 12px 0 0'
            />               
            {business_hours_remark ? (
              <LabelTextWrapper className={`${PREFIX_CLASSNAME}__row-label__text-wrapper`}>
                <LabelText className={`${PREFIX_CLASSNAME}__row-label__text`}>
                  {!business_hours ? '詳細はお問い合わせください' : getBusinessHoursLabel(business_hours)}
                </LabelText>
                <Remarks className={`${PREFIX_CLASSNAME}__row-title__remark`}>
                  {business_hours_remark}
                </Remarks>
              </LabelTextWrapper>
            ) : (
              <LabelText className={`${PREFIX_CLASSNAME}__row-label__text`}>
                {!business_hours ? '詳細はお問い合わせください' : getBusinessHoursLabel(business_hours)}
              </LabelText>
            )}
            {business_hours ? (
              <OpenerIcon
                className={`${PREFIX_CLASSNAME}__row-opener-icon`}
                isOpening={isOpeningBusinessHours}
              >
                <Icon
                  type={ICON_TYPE.ANGLE_DOWN}
                  size='14px'
                  width='14px'
                  height='14px'
                />
              </OpenerIcon>
            ) : null}
          </Label>
        </Value>
        {business_hours ? (
          <Opener
            className={`${PREFIX_CLASSNAME}__row-opener`}
            isOpening={isOpeningBusinessHours}
            height={businessHoursRef.current?.clientHeight}
          >
            <BusinessHoursWrapper className={`${PREFIX_CLASSNAME}__business-hours-wrapper`}>
              <BusinessHours
                classPrefix={PREFIX_CLASSNAME}
                businessHours={business_hours}
                ref={businessHoursRef}
              />
            </BusinessHoursWrapper>
          </Opener>
        ) : null}
      </Row>
      {phone_number ? (
        <Row
          className={`${PREFIX_CLASSNAME}__row`}
          onClick={() => handleClick(CLICK_TYPES.CALL)}
        >
          <Value className={`${PREFIX_CLASSNAME}__row-value`}>
            <Label className={`${PREFIX_CLASSNAME}__row-label`}>
              <Icon
                type={ICON_TYPE.PHONE}
                size='14px'
                width='14px'
                height='14px'
                color={CONFIG.BASE_COLOR}
                margin='0 12px 0 0'
              />              
              <LabelText className={`${PREFIX_CLASSNAME}__row-label__text`}>
                {phone_number}
              </LabelText>
            </Label>
          </Value>
        </Row>
      ) : null}
      {promotion_url ? (
        <Row
          className={`${PREFIX_CLASSNAME}__row`}
          onClick={() => handleClick(CLICK_TYPES.DETAIL)}
        >
          <Value className={`${PREFIX_CLASSNAME}__row-value`}>
            <Label className={`${PREFIX_CLASSNAME}__row-label`}>
              <Icon
                type={ICON_TYPE.EARTH}
                size='14px'
                width='14px'
                height='14px'
                color={CONFIG.BASE_COLOR}
                margin='0 12px 0 0'
              />
              <LabelAnchar
                className={`${PREFIX_CLASSNAME}__row-label__text`}
                href={promotion_url}
                target='_blank'
              >
                {promotion_url}
              </LabelAnchar>
            </Label>
          </Value>
        </Row>
      ) : null}
      {profile.news ? (
        <Row
          className={`${PREFIX_CLASSNAME}__row`}
          padding='10px 0 12px 0'
        >
          <Title className={`${PREFIX_CLASSNAME}__row-title`}>
            最新情報
          </Title>
          <Value
            className={`${PREFIX_CLASSNAME}__row-value`}
            padding='0'
            margin='0 -10px'
          >
            <News
              classPrefix={PREFIX_PROFILE_CLASSNAME}
              isHorizontal
              onClick={news => handleClick(CLICK_TYPES.NEWS_ITEM, news)}
            />
          </Value>
        </Row>
      ) : null}
      {profile.products ? (
        <Row
          className={`${PREFIX_CLASSNAME}__row`}
          padding='10px 0 12px 0'
        >
          <Title className={`${PREFIX_CLASSNAME}__row-title`}>
            メニュー
          </Title>
          <Value
            className={`${PREFIX_CLASSNAME}__row-value`}
            padding='0'
            margin='0 -10px'
          >
            <Products
              classPrefix={PREFIX_PROFILE_CLASSNAME}
              isHorizontal
              onClick={product => handleClick(CLICK_TYPES.PRODUCT_ITEM, product)}
            />
          </Value>
        </Row>
      ) : null}
      {profile.media ? (
        <Row
          className={`${PREFIX_CLASSNAME}__row`}
          padding='10px 0 12px 0'
        >
          <Title className={`${PREFIX_CLASSNAME}__row-title`}>
            写真
          </Title>
          <Value
            className={`${PREFIX_CLASSNAME}__row-value`}
            padding='0'
            margin='0 -10px'
          >
            <Media
              classPrefix={PREFIX_PROFILE_CLASSNAME}
              isHorizontal
              onClick={media => handleClick(CLICK_TYPES.MEDIA_ITEM, media)}
            />
          </Value>
        </Row>
      ) : null}
    </Container>
  );
};

export default Summary;
