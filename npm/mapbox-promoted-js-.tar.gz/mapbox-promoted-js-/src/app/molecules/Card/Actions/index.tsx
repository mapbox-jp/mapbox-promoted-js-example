import React, { useRef, useMemo, useState } from 'react';
// Components
import ScrollButton from 'atoms/ScrollButton';
import ActionItem from './Item';
import {
  Container,
  ScrollButtonLeft,
  ScrollButtonRight,
  ActionItems,
} from './styles';
import { ACTION_TYPES, ACTIONS, ActionTypes } from './helpers';

type Props = {
  classPrefix?: string;
  feature: Feature;
  onClick: (type: Promotion.ClickTypes) => void;
};

const ACTIONS_ITEM_WIDTH = 68;

const Actions: React.FC<Props> = props => {
  const { classPrefix, feature, onClick } = props;
  const { properties } = feature;
  const { feature_id } = properties;
  const PREFIX_CLASSNAME = `${classPrefix}__actions`;

  const ref = useRef<HTMLUListElement>(null);
  const [isHovering, setIsHovering] = useState(false);
  const externalLinks: Feature.ExternalLink[] = useMemo(
    () => properties.external_links && typeof properties.external_links === 'string' ?
      JSON.parse(properties.external_links) : properties.external_links || [],
    [feature_id]
  );

  const keys = Object.values(ACTION_TYPES) as ActionTypes[];
  const handleClick = (type: Promotion.ClickTypes) => onClick(type);
  const handleMouseEnter = () => setIsHovering(true);
  const handleMouseLeave = () => setIsHovering(false);
  const handleScroll = (left: boolean = false) => {
    if (!ref.current) { return; }
    ref.current.scroll({
      left: ref.current.scrollLeft + (
        left ? -1 * ACTIONS_ITEM_WIDTH : ACTIONS_ITEM_WIDTH
      ),
      behavior: 'smooth'
    });
    ref.current.scrollLeft
  };

  return (
    <Container
      className={PREFIX_CLASSNAME}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      {isHovering && (
        <ScrollButtonLeft onClick={() => handleScroll(true)}>
          <ScrollButton type='left' />
        </ScrollButtonLeft>
      )}
      <ActionItems
        className={`${PREFIX_CLASSNAME}-items`}
        ref={ref}
      >
        {keys.map(key => {
          const action = ACTIONS[key];
          let value = (properties as any)[action.key];
          if (action.key.includes('external_links')) {
            const serviceType = action.key.split('.')[1];
            const externalLink = externalLinks.find(externalLink =>
              externalLink.type === serviceType);
            if (!externalLink) { return; }
            value = externalLink.url;
          }
          return !!value || action.isRequired ? (
            <ActionItem
              classPrefix={classPrefix}
              type={key}
              value={value}
              isBlank={action.isBlank}
              onClick={handleClick}
              key={`${PREFIX_CLASSNAME}-${key}`}
            />
          ) : null;
        })}
      </ActionItems>
      {isHovering && (
        <ScrollButtonRight onClick={() => handleScroll()}>
          <ScrollButton type='right' />
        </ScrollButtonRight>
      )}
    </Container>
  );
};

export default Actions;
