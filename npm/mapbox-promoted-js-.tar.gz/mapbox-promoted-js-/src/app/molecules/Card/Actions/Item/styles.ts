import styled, { createGlobalStyle } from 'styled-components';
import { CONFIG } from 'utils/config';

type Container = {
  isHorizontal?: boolean;
};

export const createItemGlobalStyle = (className?: string, space?: string) => createGlobalStyle`
  .${className} {
    &:first-child {
      margin-left: ${space || '9px'}
    }
    &:last-child {
      margin-right: ${space || '9px'}
    }
  }
`;
export const ItemButton = styled.button`
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 8px;
  width: 32px;
  height: 32px;
  white-space: nowrap;
  vertical-align: baseline;
  color: ${() => CONFIG.BASE_COLOR};
  border: 1px solid ${() => CONFIG.BASE_COLOR};
  border-radius: 8px;
  background-color: transparent;
  text-decoration: none;
  cursor: pointer;
`;
export const ItemIcon = styled.span`
  display: flex;
  justify-content: center;
  align-items: center;
  width: 14px;
  min-width: 14px;
  height: 14px;
  min-height: 14px;
  font-size: 14px;
  cursor: pointer;
`;
export const ItemLabel = styled.span`
  margin: 12px 0 0 0;
  font-size: 13px;
  line-height: 1.5;
  color: ${() => CONFIG.BASE_COLOR};
`;
export const Container = styled.li`
  width: 68px;
  min-width: 68px;
  display: flex;
  flex-direction: column;
  align-items: center;
  & + & {
    margin-left: 6px;
  }
  &:hover {
    ${ItemButton} {
      color: #ffffff;
      background-color: ${() => CONFIG.BASE_COLOR};
      transition: background-color 0.1s, color 0.1s;
    }
  }
`;
