import React from 'react';
// Components
import Icon from 'atoms/Icon';
import { ACTIONS, ActionTypes } from '../helpers';
import {
  createItemGlobalStyle,
  Container,
  ItemButton,
  ItemIcon,
  ItemLabel,
} from './styles';

type Props = {
  classPrefix?: string;
  type: ActionTypes;
  value: string;
  isBlank?: boolean;
  onClick: (type: Promotion.ClickTypes) => void;
};

const Item: React.FC<Props> = props => {
  const { classPrefix, type, value, isBlank, onClick } = props;
  const PREFIX_CLASSNAME = `${classPrefix}__actions-item`;

  const GlobalStyle = createItemGlobalStyle(PREFIX_CLASSNAME);
  const action = ACTIONS[type];
  const { classKey, iconType, clickType } = action;
  const label = action.label || value;

  const handleClick = (type: Promotion.ClickTypes) => {
    onClick(type)
    isBlank && window.open(value);
  };

  return (
    <>
      <GlobalStyle />
      <Container
        className={`${PREFIX_CLASSNAME} ${PREFIX_CLASSNAME}-${classKey}`}
        onClick={() => clickType && handleClick(clickType)}
      >
        <ItemButton className={`${PREFIX_CLASSNAME}__button`}>
          <ItemIcon className={`${PREFIX_CLASSNAME}__icon`}>
            <Icon
              type={iconType}
              size='14px'
              width='14px'
              height='14px'
            />
          </ItemIcon>
        </ItemButton>
        <ItemLabel className={`${PREFIX_CLASSNAME}__label`}>
          {label}
        </ItemLabel>
      </Container>
    </>
  );
};

export default Item;
