import React, { useEffect, useMemo, useState } from 'react';
import { CONFIG, DEFAULT_BANNER_SIZE } from 'utils/config';
// Components
import PhotoModal from 'molecules/PhotoModal';
import HeaderInfo from './HeaderInfo';
import Tabs, { Tab } from './Tabs';
import Actions from './Actions';
import Summary from './Summary';
import News from './News';
import Products from './Products';
import Media from './Media';
import Info from './Info';
import {
  Container,
  Header,
  Banner,
  BannerAnchar,
  BannerImg,
} from './styles';
import {
  CLICK_TYPES,
  TAB_TYPES,
  TabTypes,
} from './helpers';
import {
  ProfileContext,
  useProfile,
} from './hooks';

type Props = {
  id?: string;
  classPrefix: string;
  feature: Feature;
  height?: string;
  isFadeout?: boolean;
  onClick?: (type: Promotion.ClickTypes, profileItems?: Feature.ProfileItems) => void;
  onUpdate?: (feature: Feature) => void;
};
type SelectedProfileItem = {
  type: Feature.ProfileItemTypes;
  item?: Feature.ProfileItem;
};

const PREFIX_PROFILE_CLASSNAME = 'promotion-profile';

const Card = React.forwardRef<HTMLDivElement, Props>((props, ref) => {
  const { id, classPrefix, feature, height, onClick, onUpdate } = props;
  const { properties } = feature;
  const { feature_id, promotion_url, promotion_banner } = properties;

  const [featureId, setFeatureId] = useState<string>(feature_id);
  const [selectedTab, setSelectedTab] = useState<TabTypes>(TAB_TYPES.SUMARRY);
  const profile = useMemo(
    () => properties.profile && typeof properties.profile === 'string' ?
      JSON.parse(properties.profile) : properties.profile,
    [feature_id]
  );

  const enableProfile = profile && !!Object.values(profile).find(value => value);
  const profileContext = useProfile(feature_id, enableProfile);

  const [selectedProfileItem, setSelectedProfileItem] = useState<SelectedProfileItem>();
  const bannerSize = useMemo(() => {
    const { promotion_banner_width, promotion_banner_height } = properties;
    return {
      width: promotion_banner_width || DEFAULT_BANNER_SIZE.WIDTH,
      height: promotion_banner_height || DEFAULT_BANNER_SIZE.HEIGHT,
    };
  }, [feature_id]);
  useEffect(() => {
    if (featureId !== properties.feature_id) {
      setFeatureId(properties.feature_id);
      setSelectedTab(TAB_TYPES.SUMARRY);
    }
    onUpdate && onUpdate(feature);
  }, [feature_id]);

  const handleClickTab = (type: TabTypes) => {
    setSelectedTab(type);
    switch (type) {
      case TAB_TYPES.NEWS:
        handleClick(CLICK_TYPES.NEWS);
        break;
      case TAB_TYPES.PRODUCT:
        handleClick(CLICK_TYPES.PRODUCT);
        break;
      case TAB_TYPES.MEDIA:
        handleClick(CLICK_TYPES.MEDIA);
        break;
      default:
        handleClick(CLICK_TYPES.TAB);
        break;
    }
  };
  const handleClick = (type: Promotion.ClickTypes, item?: Feature.ProfileItem, isSummary?: boolean) => {
    const profileItems: Feature.ProfileItems = {};
    if (item && type === CLICK_TYPES.NEWS_ITEM) {
      isSummary && handleClickTab(TAB_TYPES.NEWS);
      setSelectedProfileItem({ type, item });
      profileItems['news'] = item as Feature.Profile.News;
    } else if (item && type === CLICK_TYPES.PRODUCT_ITEM) {
      isSummary && setSelectedTab(TAB_TYPES.PRODUCT);
      setSelectedProfileItem({ type, item });
      profileItems['product'] = item as Feature.Profile.Product;
    } else if (item && type === CLICK_TYPES.MEDIA_ITEM) {
      profileItems['media'] = item as Feature.Profile.Media;
      setSelectedProfileItem({ type, item });
    }
    onClick && onClick(type, profileItems);
  };
  const handleClosePhotoModal = () => {
    setSelectedProfileItem(undefined);
  };

  const renderTabs = () => {
    return enableProfile ? (
      <>
        <Tabs classPrefix={classPrefix}>
          <Tab
            classPrefix={classPrefix}
            label='概要'
            isSelected={selectedTab === TAB_TYPES.SUMARRY}
            onClick={() => handleClickTab(TAB_TYPES.SUMARRY)}
          />
          {profile.news && (
            <Tab
              classPrefix={classPrefix}
              label='最新情報'
              isSelected={selectedTab === TAB_TYPES.NEWS}
              onClick={() => handleClickTab(TAB_TYPES.NEWS)}
            />
          )}
          {profile.products && (
            <Tab
              classPrefix={classPrefix}
              label='メニュー'
              isSelected={selectedTab === TAB_TYPES.PRODUCT}
              onClick={() => handleClickTab(TAB_TYPES.PRODUCT)}
            />
          )}
          {profile.media && (
            <Tab
              classPrefix={classPrefix}
              label='写真'
              isSelected={selectedTab === TAB_TYPES.MEDIA}
              onClick={() => handleClickTab(TAB_TYPES.MEDIA)}
            />
          )}
          <Tab
            classPrefix={classPrefix}
            label='情報'
            isSelected={selectedTab === TAB_TYPES.INFO}
            onClick={() => handleClickTab(TAB_TYPES.INFO)}
          />
        </Tabs>
        {renderContent()}
      </>
    ) : (
      <Summary
        classPrefix={classPrefix}
        feature={feature}
        onClick={handleClick}
      />
    );
  };
  const renderContent = () => {
    switch (selectedTab) {
      case TAB_TYPES.SUMARRY:
        return (
          <Summary
            classPrefix={classPrefix}
            feature={feature}
            onClick={(type, item) => handleClick(type, item, true)}
          />
        );
      case TAB_TYPES.NEWS:
        return (
          <News
            classPrefix={PREFIX_PROFILE_CLASSNAME}
            selectedNews={selectedProfileItem && selectedProfileItem.type === CLICK_TYPES.NEWS_ITEM ?
              selectedProfileItem.item as Feature.Profile.News : undefined}
            onClick={news => handleClick(CLICK_TYPES.NEWS_ITEM, news)}
          />
        );
      case TAB_TYPES.PRODUCT:
        return (
          <Products
            classPrefix={PREFIX_PROFILE_CLASSNAME}
            selectedProduct={selectedProfileItem && selectedProfileItem.type === CLICK_TYPES.PRODUCT_ITEM ?
              selectedProfileItem.item as Feature.Profile.Product : undefined}
            onClick={product => handleClick(CLICK_TYPES.PRODUCT_ITEM, product)}
          />
        );
      case TAB_TYPES.MEDIA:
        return (
          <Media
            classPrefix={PREFIX_PROFILE_CLASSNAME}
            onClick={media => handleClick(CLICK_TYPES.MEDIA_ITEM, media)}
          />
        );
      case TAB_TYPES.INFO:
        return (
          <Info
            classPrefix={classPrefix}
            feature={feature}
            onClick={handleClick}
          />
        );
      default:
        return null;
    }
  };
  const renderBanner = () => promotion_url ? (
    <BannerAnchar
      className={`${classPrefix}__banner`}
      href={promotion_url}
      target='_blank'
      onClick={() => handleClick(CLICK_TYPES.BANNER)}
    >
      <BannerImg
        className={`${classPrefix}__banner-img`}
        src={promotion_banner}
        width={bannerSize.width}
        height={bannerSize.height}
      />
    </BannerAnchar>
  ) : (
    <Banner
      className={`${classPrefix}__banner`}
      onClick={() => handleClick(CLICK_TYPES.BANNER)}
    >
      <BannerImg
        className={`${classPrefix}__banner-img`}
        src={promotion_banner}
        width={bannerSize.width}
        height={bannerSize.height}
      />
    </Banner>
  );
  return (
    <ProfileContext.Provider value={profileContext}>
      {CONFIG.MEDIA_MODAL && selectedProfileItem && selectedProfileItem.item && selectedProfileItem.type === CLICK_TYPES.MEDIA_ITEM ? (
        <PhotoModal
          classPrefix={classPrefix}
          isOpen
          showingMedia={selectedProfileItem.item as Feature.Profile.Media}
          media={profileContext.media}
          onClose={handleClosePhotoModal}
        />
      ) : null}
      <Container
        id={id}
        className={classPrefix}
        height={height}
        ref={ref}
      >
        <Header className={`${classPrefix}__header`}>
          {renderBanner()}
          <HeaderInfo
            classPrefix={classPrefix}
            feature={feature}
            onClick={handleClick}
          />
          <Actions
            classPrefix={classPrefix}
            feature={feature}
            onClick={handleClick}
          />
        </Header>
        {renderTabs()}
      </Container>
    </ProfileContext.Provider>
  );
});

export default Card;
