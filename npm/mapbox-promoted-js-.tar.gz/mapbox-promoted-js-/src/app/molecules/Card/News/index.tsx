import React, { useContext, useEffect, useRef, useState } from 'react';
import { ProfileContext } from 'molecules/Card/hooks';
// Components
import ScrollButton from 'atoms/ScrollButton';
import Item from './Item';
import {
  Container,
  Items,
  ScrollButtonLeft,
  ScrollButtonRight,
  EmptyColumn,
} from './styles';

type Props = {
  classPrefix?: string;
  selectedNews?: Feature.Profile.News;
  isHorizontal?: boolean;
  onClick?: (news: Feature.Profile.News) => void;
};

const NEWS_ITEM_WIDTH = 140;

const News: React.FC<Props> = props => {
  const { classPrefix, selectedNews, isHorizontal, onClick } = props;
  const {
    news,
    newsIsLasted,
    readmoreNews
  } = useContext(ProfileContext);
  const PREFIX_CLASSNAME = `${classPrefix}-news`;

  const newsRef = useRef<HTMLUListElement>(null);
  const [isHovering, setIsHovering] = useState(false);

  const handleReadMore = () => readmoreNews();
  const handleMouseEnter = () => setIsHovering(true);
  const handleMouseLeave = () => setIsHovering(false);
  const handleScroll = (left: boolean = false) => {
    if (!newsRef.current) { return; }
    newsRef.current.scroll({
      left: newsRef.current.scrollLeft + (
        left ? -1 * NEWS_ITEM_WIDTH : NEWS_ITEM_WIDTH
      ),
      behavior: 'smooth'
    });
    newsRef.current.scrollLeft
  };

  useEffect(() => {
    if (selectedNews) {
      const id = `promotion-profile-news__${selectedNews.id}`;
      const target = document.getElementById(id);
      target && target.scrollIntoView();
    }
  }, []);

  return (
    <Container
      className={PREFIX_CLASSNAME}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
    >
      {isHorizontal && isHovering && (
        <ScrollButtonLeft
          className={`${PREFIX_CLASSNAME}__scroll-button-left__wrapper`}
          onClick={() => handleScroll(true)}
        >
          <ScrollButton
            classPrefix={PREFIX_CLASSNAME}
            type='left'
            size='medium'
          />
        </ScrollButtonLeft>
      )}
      <Items
        className={`${PREFIX_CLASSNAME}__items`}
        isHorizontal={isHorizontal}
        ref={newsRef}
      >
        {isHorizontal ? (
          <EmptyColumn className={`${PREFIX_CLASSNAME}__empty-column`} />
        ) : null}
        {news.length ? news.map((row: Feature.Profile.News, i) => (
          <Item
            classPrefix={PREFIX_CLASSNAME}
            news={row}
            isLast={i === news.length - 1 && !newsIsLasted}
            isHorizontal={isHorizontal}
            onReadMore={handleReadMore}
            onClick={onClick}
            key={`news-item__${row.id}`}
          />
        )) : (
          <Item
            classPrefix={PREFIX_CLASSNAME}
            isHorizontal={isHorizontal}
            onClick={onClick}
            key='news-item__empty'
          />          
        )}
        {isHorizontal ? (
          <EmptyColumn className={`${PREFIX_CLASSNAME}__empty-column`} />
        ) : null}
      </Items>
      {isHorizontal && isHovering && (
        <ScrollButtonRight
          className={`${PREFIX_CLASSNAME}__scroll-button-right__wrapper`}
          onClick={() => handleScroll()}
        >
          <ScrollButton
            classPrefix={PREFIX_CLASSNAME}
            type='right'
            size='medium'
          />
        </ScrollButtonRight>
      )}
    </Container>
  );
};

export default News;