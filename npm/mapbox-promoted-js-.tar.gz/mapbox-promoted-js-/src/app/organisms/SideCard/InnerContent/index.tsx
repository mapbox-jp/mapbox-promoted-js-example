import React, { useRef, useEffect } from 'react';
import { observeElementExist } from 'utils/browser';
// Components
import Card from 'molecules/Card';
import { PREFIX_CLASSNAME } from '../index';

export const SideCardInnerContent: React.FC<{
  container: HTMLElement,
  feature: Feature,
  onClick?: (type: Promotion.ClickTypes, feature: Feature, profileItems?: Feature.ProfileItems) => void,
  onUpdate?: (feature: Feature) => void,
  onClose?: (feature: Feature) => void,
}> = (props) => {
  const { container, feature, onClick, onUpdate, onClose } = props;
  const { feature_id } = feature.properties;
  const id = `${PREFIX_CLASSNAME}__${feature_id}`;
  const ref = useRef<HTMLDivElement>(null);
  const handleClick = (type: Promotion.ClickTypes, profileItems?: Feature.ProfileItems) => 
    onClick && onClick(type, feature, profileItems);
  useEffect(() => {
    ref.current && observeElementExist(`#${id}`, () => {
      removePromotionSideCardInnerElement && removePromotionSideCardInnerElement(container);
      onClose && onClose(feature);
    });
  }, [ref]);
  return (
    <Card
      id={id}
      classPrefix={PREFIX_CLASSNAME}
      feature={feature}
      onClick={handleClick}
      onUpdate={onUpdate}
      ref={ref}
    />
  );
};
