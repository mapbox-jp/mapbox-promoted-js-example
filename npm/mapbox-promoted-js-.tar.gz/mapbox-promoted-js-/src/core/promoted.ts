import mapboxgl from 'mapbox-gl';
import { Plugin as PromotedMapbox } from 'promoted-mapbox-plugin-js';
import { CONFIG } from 'utils/config';
import PromotionSideCard from './promotionSideCard';
import Event from './event';
import Source from './source';
import Session from './session';
import EventAction from './eventAction';
import Logger from './logger';
import { SESSION_EVENT_TYPES, isFeedback, isCallToAction } from './helpers';
console.log("asas");

class Promoted extends Event implements Promoted.Core {
  private _map: PromotedPlugin.Plugin;
  private _source: Promoted.Source;
  private _session: Promoted.Session;
  private _eventAction: Promoted.EventAction;
  private _logger: Promoted.Logger;
  private _promotionSideCard: Promoted.PromotionSideCard;
  private _enableSideCard: boolean;

  constructor(options: Promoted.Core.Options) {
    super();
    const {
      map,
      accessToken,
      mediaId,
      container,
      baseUrl,
      logUrl,
      baseColor,
      scaleIcon,
      mediaModal,
      debug,
    } = options;

    if ((map as PromotedPlugin.Plugin).isPromotedPlugin) {
      this._map = map as PromotedPlugin.Plugin;
    } else {
      this._map = new PromotedMapbox(map as mapboxgl.Map);
    }

    CONFIG.ACCESS_TOKEN = accessToken;
    if (typeof container === 'string') {
      CONFIG.CONTAINER = document.querySelector<HTMLElement>(container) || undefined;
    } else { 
      CONFIG.CONTAINER = container;
    }

    mediaId && (CONFIG.MEDIA_ID = mediaId);
    baseUrl && (CONFIG.BASE_URL = baseUrl);
    logUrl && (CONFIG.LOG_URL = logUrl);
    baseColor && (CONFIG.BASE_COLOR = baseColor);
    scaleIcon && (CONFIG.SCALE_ICON = scaleIcon);
    mediaModal && (CONFIG.MEDIA_MODAL = mediaModal);
    debug && (CONFIG.DEBUG = debug);

    this._logger = new Logger();
    this._session = new Session(this._logger);
    this._eventAction = new EventAction(this, this._session, this._logger);
    this._source = new Source(this, this._session, this._eventAction, this._logger);
    this._eventAction.source = this._source;

    this._promotionSideCard = new PromotionSideCard(this, this._session, this._logger);

    this._enableSideCard = !!options.sideCard;

    this._session.on(SESSION_EVENT_TYPES.START_SESSION, (_type, data) => this.fire(data));
    this._session.on(SESSION_EVENT_TYPES.UPDATE_SESSION, (_type, data) => this.fire(data));
    this._session.on(SESSION_EVENT_TYPES.END_SESSION, (_type, data) => this.fire(data));
  }

  get map() {
    return this._map.map;
  }

  get plugin() {
    return this._map;
  }

  get tilesets(): { [quadkey: string]: Feature[] } {
    return this._source.tilesets;
  }

  get features(): Feature[] {
    return [];
  }

  get enableSideCard(): boolean {
    return this._enableSideCard;
  }

  get promotionSideCard(): Promoted.PromotionSideCard {
    return this._promotionSideCard;
  }

  public show(feature: Feature) {
    this._enableSideCard && this._promotionSideCard.show(feature);
  }

  public visibleLayer() {
    this._map.visibleLayer();
  }

  public hideLayer() {
    this._map.hideLayer();
  }

  public selectFeature(feature: Feature) {
    this._map.selectFeature(feature);
  }

  public deselectLayer() {
    this._map.deselectLayer();
  }

  public reload() {
    this._source.reload();
  }

  public sendAction(feature: Feature, clickType: Promotion.ClickTypes) {
    try {
      if (isFeedback(clickType)) {
        this._logger.feedback(
          this._session.sessionId,
          feature,
          Math.floor(this.plugin.zoomLevel),
          clickType as Promoted.Logger.FeedbackTypes,
        );
      } else if (isCallToAction(clickType)) {
        this._logger.callToAction(
          this._session.sessionId,
          feature,
          Math.floor(this.plugin.zoomLevel),
          clickType as Promoted.Logger.ActionTypes,
        );
      }
    } catch (error: any) {
      console.error(error);
      this._logger.log('error_internal', error);
    }
  }

  public renderPromotionSideCardInnerElement(container: string | HTMLElement, feature: Feature): HTMLElement | undefined {
    return this._promotionSideCard.render(container, feature);
  }
}

export default Promoted;
