/// <reference types="mapbox-gl" />
declare module 'mapbox-promoted-js' {
  namespace Promoted {
    type Options = {
      baseUrl?: string;
      sourceUrl?: string;
      telemetryUrl?: string;
      layerSourceId?: string;
      mobileMaxWidth?: number;
      enablePromotionCard?: boolean;
      enablePromotionSideCard?: boolean;
      isDarkMode?: boolean;
      debug?: boolean;
    };
  
    class Event {
      type: EventTypes;
      data: Object;
      constructor(type: EventTypes, data?: Object);
    }
  
    const EVENT_TYPES: {
      readonly LOAD: 'load';
      readonly MOVE: 'move';
      readonly CLICK_PIN: 'click_pin';
      readonly CLICK_CARD: 'click_card';
      readonly SHOW_CARD: 'show_card';
      readonly UPDATE_CARD: 'update_card';
      readonly CLOSE_CARD: 'close_card';
      readonly CLICK_SIDE_CARD: 'click_side_card';
      readonly SHOW_SIDE_CARD: 'show_side_card';
      readonly UPDATE_SIDE_CARD: 'update_side_card';
      readonly OPEN_SIDE_CARD: 'open_side_card';
      readonly HIDE_SIDE_CARD: 'hide_side_card';
      readonly CLOSE_SIDE_CARD: 'close_side_card';
      readonly CLICK_POPUP: 'click_popup';
      readonly SHOW_POPUP: 'show_popup';
      readonly CLOSE_POPUP: 'close_popup';
    }

    type EventTypes = typeof EVENT_TYPES[keyof typeof EVENT_TYPES];
    type Listener = (type: EventTypes, event: any) => any;
  }

  export class Promoted {
    constructor(map: mapboxgl.Map, token: string, options?: Promoted.Options);
    get map(): mapboxgl.Map;
    get mobileMaxWidth(): number;
    set mobileMaxWidth(mobileMaxWidth: number);
    get isDarkMode(): boolean;
    set isDarkMode(isDarkMode: boolean);
    get debug(): boolean;
    set debug(debug: boolean);
    get layer(): mapboxgl.AnyLayer;
    get enablePromotionPopup(): boolean;
    set enablePromotionPopup(enablePromotionPopup: boolean);
    get enablePromotionCard(): boolean;
    set enablePromotionCard(enablePromotionCard: boolean);
    get enablePromotionSideCard(): boolean;
    set enablePromotionSideCard(enablePromotionSideCard: boolean);
    on(type: Promoted.EventTypes, listener: Promoted.Listener): void;
    off(type: Promoted.EventTypes, listener: Promoted.Listener): void;
    reload(): void;
    promotionFeatures(): Feature[];
    deselectLayer(): void;
  }

  namespace Feature {
    interface Properties {
      adid: string;
      icon?: string;
      advertizer?: string;
      category?: string;
      addressJa?: string;
      addressEn?: string;
      nameJa?: string;
      nameEn?: string;
      subtitle?: string;
      phoneNumber?: string;
      promotionBanner?: string;
      promotionBannerWidth?: number;
      promotionBannerHeight?: number;
      promotionCard?: string;
      promotionUrl?: string;
      displayPromotionInternal?: boolean;
      directions?: string;
      lat?: string;
      lng?: string;
      minZoom?: string;
      satOpen?: string;
      satClose?: string;
      sunOpen?: string;
      sunClose?: string;
      weekOpen?: string;
      weekClose?: string;
      holidayOpen?: string;
      holidayClose?: string;
    }
  }
  interface Feature extends mapboxgl.MapboxGeoJSONFeature {
    properties: Feature.Properties;
  }
}
