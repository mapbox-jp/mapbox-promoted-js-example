import { CONFIG } from 'utils/config';

export const getImageUrl = (imageId: string) => (
  `${CONFIG.BASE_URL}/ads/v1/campaign/resources/creatives/${imageId}?access_token=${CONFIG.ACCESS_TOKEN}`
);
