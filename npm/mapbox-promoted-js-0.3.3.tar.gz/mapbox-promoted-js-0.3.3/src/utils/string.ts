export const randomString = (length: number = 8) => (
  Math.random().toString(length).substring(2)
);

export const isUrl = (string: string) => !!string.match(/https?:\/\//);
