import { isUrl } from 'utils/string';

describe('utils/string.isUrl', () => {
  const httpsGeojsonUrl = 'https://test.co.jp/test.json';
  const httpGeojsonUrl = 'http://test.co.jp/test.json';
  const mapboxSourceUrl = 'mapbox://mapbox-ads.abcdefg';

  it('is http geojson', () => (
    expect(true).toEqual(isUrl(httpsGeojsonUrl))
  ));

  it('is https geojson', () => (
    expect(true).toEqual(isUrl(httpGeojsonUrl))
  ));

  it('is mapbox source url', () => (
    expect(false).toEqual(isUrl(mapboxSourceUrl))
  ));
});
