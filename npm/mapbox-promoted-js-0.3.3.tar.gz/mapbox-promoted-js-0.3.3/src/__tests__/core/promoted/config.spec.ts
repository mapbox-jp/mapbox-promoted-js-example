import mapboxgl from 'mapbox-gl';
import Promoted from 'core/promoted';
import { ACCESS_TOKEN, OPTIONS } from 'mock/config';
import { CONFIG } from 'utils/config';

jest.mock('mapbox-gl/dist/mapbox-gl', () => ({
  Map: jest.fn(() => ({
    on: jest.fn(),
    remove: jest.fn(),
  })),
  Popup: jest.fn()
}));

describe('core/promoted config', () => {
  let map: mapboxgl.Map;
  let promoted: Promoted;

  beforeEach(() => {
    map = new mapboxgl.Map();
    promoted = new Promoted(map, ACCESS_TOKEN, {
      baseUrl: OPTIONS.BASE_URL,
      sourceUrl: OPTIONS.SOURCE_URL,
      telemetryUrl: OPTIONS.TELEMETRY_URL,
      layerSourceId: OPTIONS.LAYER_SOURCE_ID,
      debug: OPTIONS.DEBUG,
      mobileMaxWidth: OPTIONS.MOBILE_MAX_WIDTH,
    });
  });

  describe('initial config', () => {
    it('get initial access token', () => (
      expect(ACCESS_TOKEN).toEqual(promoted.accessToken)
    ));
  
    it('get initial base url', () => (
      expect(CONFIG.BASE_URL).toEqual(promoted.baseUrl)
    ));
  
    it('get initial source url', () => (
      expect(CONFIG.SOURCE_URL).toEqual(promoted.sourceUrl)
    ));
  
    it('get initial telemetry url', () => (
      expect(CONFIG.TELEMETRY_URL).toEqual(promoted.telemetryUrl)
    ));
  
    it('get initial layer source id', () => (
      expect(CONFIG.LAYER_SOURCE_ID).toEqual(promoted.layerSourceId)
    ));

    it('get initial mobile max width', () => (
      expect(CONFIG.MOBILE_MAX_WIDTH).toEqual(promoted.mobileMaxWidth)
    ));

    it('get initial debug flag', () => (
      expect(CONFIG.DEBUG).toEqual(promoted.debug)
    ));
  });

  describe('update config', () => {
    it('get updated access token', () => (
      expect(ACCESS_TOKEN).toEqual(promoted.accessToken)
    ));
  
    it('get updated base url', () => (
      expect(OPTIONS.BASE_URL).toEqual(promoted.baseUrl)
    ));
  
    it('get updated source url', () => (
      expect(OPTIONS.SOURCE_URL).toEqual(promoted.sourceUrl)
    ));
  
    it('get updated telemetry url', () => (
      expect(OPTIONS.TELEMETRY_URL).toEqual(promoted.telemetryUrl)
    ));
  
    it('get updated layer source id', () => (
      expect(OPTIONS.LAYER_SOURCE_ID).toEqual(promoted.layerSourceId)
    ));

    it('get updated mobile max width', () => (
      expect(OPTIONS.MOBILE_MAX_WIDTH).toEqual(promoted.mobileMaxWidth)
    ));

    it('get updated debug flag', () => (
      expect(OPTIONS.DEBUG).toEqual(promoted.debug)
    ));
  });
});
