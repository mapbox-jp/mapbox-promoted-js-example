import Promoted from './promoted';
import PromotionPopup from './promotionPopup';
import PromotionCard from './promotionCard';
import PromotionSideCard from './promotionSideCard';

import '@babel/polyfill';

export {
  Promoted,
  PromotionPopup,
  PromotionCard,
  PromotionSideCard
};
