import mapboxgl, { Map } from 'mapbox-gl';
import { isUrl } from 'utils/string';
import { CONFIG } from 'utils/config';
import { COLORS } from 'utils/color';
import { getImageUrl } from 'utils/urls';
import { randomString } from 'utils/string';
import {
  createLayer,
  createSelectedTextColor,
  createSelectedTextHaloColor,
} from 'utils/layer';
import PromotionPopup from './promotionPopup';
import PromotionCard from './promotionCard';
import PromotionSideCard from './promotionSideCard';
import { Event } from './event';
import { FEATURE_TYPES, EVENT_TYPES } from './helpers';

import * as telemetryAPIs from 'apis/telemetry';

class Promoted implements Promoted {
  private _map: mapboxgl.Map;
  private _sourceUrl?: string;
  private _layerSourceId?: string;
  private _sources: { [key: string]: mapboxgl.AnySourceData } = {};
  private _layers: { [key: string]: mapboxgl.SymbolLayer } = {};
  private _isDarkMode: boolean;
  private _enablePromotionPopup: boolean;
  private _enablePromotionCard: boolean;
  private _enablePromotionSideCard: boolean;
  private _promotionCard: PromotionCard;
  private _promotionPopup: PromotionPopup;
  private _promotionSideCard: PromotionSideCard;
  private _listeners: Promoted.Listeners = {};
  private _renderedFeatures: Feature[] = [];

  constructor(map: mapboxgl.Map, token: string, options: Promoted.Options = {}) {
    CONFIG.ACCESS_TOKEN = token;

    const {
      baseUrl,
      telemetryUrl,
      sourceUrl,
      layerSourceId,
      mobileMaxWidth,
      enablePromotionPopup,
      enablePromotionCard,
      enablePromotionSideCard,
      isDarkMode,
      debug,
    } = options;

    // FIXME: This will be removed by implement getting geojson
    sourceUrl && (this._sourceUrl = sourceUrl);
    layerSourceId && (this._layerSourceId = layerSourceId);
    
    baseUrl && (CONFIG.BASE_URL = baseUrl);
    telemetryUrl && (CONFIG.TELEMETRY_URL = telemetryUrl);
    debug && (this.debug = debug);
    mobileMaxWidth && (this.mobileMaxWidth = mobileMaxWidth);

    this._map = map;
    this._enablePromotionPopup = enablePromotionPopup || false;
    this._enablePromotionCard = enablePromotionCard || false;
    this._enablePromotionSideCard = enablePromotionSideCard || false;
    this._isDarkMode = isDarkMode || false;

    this._promotionPopup = new PromotionPopup(this);
    this._promotionCard = new PromotionCard(this);
    this._promotionSideCard = new PromotionSideCard(this);

    this._map.on('load', this.load.bind(this));
    this._map.on('render', this.render.bind(this));
    this._map.on('move', this.move.bind(this));
    this._map.on('styleimagemissing', this.styleImageMissing.bind(this));

    window.addEventListener('load', () => this.activate());
    document.readyState === 'complete' && this.activate();
  }

  get map() {
    return this._map;
  }

  get mobileMaxWidth(): number {
    return CONFIG.MOBILE_MAX_WIDTH;
  }

  set mobileMaxWidth(mobileMaxWidth: number) {
    CONFIG.MOBILE_MAX_WIDTH = mobileMaxWidth;
  }

  get isDarkMode(): boolean {
    return this._isDarkMode;
  }

  set isDarkMode(isDarkMode: boolean) {
    this._isDarkMode = isDarkMode;
  }

  get debug() {
    return CONFIG.DEBUG;
  }

  set debug(debug: boolean) {
    CONFIG.DEBUG = debug;
  }

  get enablePromotionPopup(): boolean {
    return !this._enablePromotionCard && !this._enablePromotionSideCard;
  }

  set enablePromotionPopup(value: boolean) {
    if (value) {
      this._enablePromotionCard = false;
      this._enablePromotionSideCard = false;
    }
    this._enablePromotionPopup = value;
  }

  get enablePromotionCard(): boolean {
    return this._enablePromotionCard;
  }

  set enablePromotionCard(value: boolean) {
    if (value) {
      this._enablePromotionPopup = false;
      this._enablePromotionSideCard = false;
    }
    this._enablePromotionCard = value;
  }

  get enablePromotionSideCard(): boolean {
    return this._enablePromotionSideCard;
  }

  set enablePromotionSideCard(value: boolean) {
    if (value) {
      this._enablePromotionPopup = false;
      this._enablePromotionCard = false;
    }
    this._enablePromotionSideCard = value;
  }

  private get sourceIds(): string[] {
    return Object.keys(this._sources).filter(id => this._map.getSource(id));
  }

  private get layerIds(): string[] {
    return Object.keys(this._sources).filter(id => this._map.getLayer(`layer-${id}`)).map(id => `layer-${id}`);
  }

  private activate() {
    window.renderApp && window.renderApp(CONFIG);
    telemetryAPIs.sessionStart();
  }
  
  private load(event: { target: Map }) {
    this.fire(new Event(EVENT_TYPES.LOAD, { map: event.target }));
    this._sourceUrl && this.addSource(this._sourceUrl, undefined, this._layerSourceId);
  }

  private render(_event: { target: Map }) {
    this.updateRenderedFeatures();
  }

  private move(event: mapboxgl.MapboxEvent<any> & mapboxgl.EventData) {
    const features = this._map.queryRenderedFeatures(undefined, { layers: this.layerIds });
    const promotionFeatures: Feature[] = [];
    for (const feature of features) {
      feature.properties && feature.properties['adid'] && promotionFeatures.push(feature as Feature);
    }
    this.fire(
      new Event(EVENT_TYPES.MOVE, {
        map: event.target,
        originalEvent: event.originalEvent,
        features: promotionFeatures
      })
    );
  }

  private show(feature: Feature) {
    switch (feature.properties.type) {
      case FEATURE_TYPES.CARD:
        if (this._enablePromotionPopup) {
          this._promotionPopup.show(feature);
          return;
        } else if (this._enablePromotionSideCard) {
          this._promotionSideCard.show(feature);
          return;
        }
        this._promotionCard.show(feature);
        return;
      case FEATURE_TYPES.SIDE_CARD:
        if (this._enablePromotionPopup) {
          this._promotionPopup.show(feature);
          return;
        } else if (this._enablePromotionCard) {
          this._promotionCard.show(feature);
          return;
        }
        this._promotionSideCard.show(feature);
        return;
      case FEATURE_TYPES.POPUP:
      default:
        if (this._enablePromotionSideCard) {
          this._promotionSideCard.show(feature);
          return;
        } else if (this._enablePromotionCard) {
          this._promotionCard.show(feature);
          return;
        }
        this._promotionPopup.show(feature);
        return;
    }
  }

  private click(event: mapboxgl.MapMouseEvent & { features?: mapboxgl.MapboxGeoJSONFeature[] | undefined; } & mapboxgl.EventData) {
    try {
      const feature = event.features && event.features[0] as Feature;
      if (!feature) { return; }
      const { properties } = feature;
      const { adid } = properties;
      if (!adid) { return; }

      telemetryAPIs.sendSelection(adid, this._map.getZoom());
      this.fire(new Event(EVENT_TYPES.CLICK_PIN, {
        map: event.target,
        originalEvent: event.originalEvent,
        feature,
      }));
      this.show(feature);
    } catch (error: any) {
      console.error(error);
    }
  }

  public on(type: Promoted.EventTypes, listener: Promoted.Listener) {
    const listenerExists = this._listeners[type] && this._listeners[type].indexOf(listener) !== -1;
    if (!listenerExists) {
      this._listeners[type] = this._listeners[type] || [];
      this._listeners[type].push(listener);
    }
  }

  public off(type: Promoted.EventTypes, listener: Promoted.Listener) {
    if (this._listeners && this._listeners[type]) {
      const index = this._listeners[type].indexOf(listener);
      if (index !== -1) {
        this._listeners[type].splice(index, 1);
      }
    }
  }

  public fire(event: Event) {
    const { type, data } = event;
    const listeners = this._listeners && this._listeners[type] ? this._listeners[type].slice() : [];
    for (const listener of listeners) {
      listener.call(this, type, data);
    }
  }

  private styleImageMissing(event: any) {
    try {
      const imageId: string = event.id;
      if (!imageId || this._map.hasImage(imageId)) {
        return;
      }
      let url = '';
      if (imageId.match(/^([a-zA-Z0-9]{21,22})$/)) {
        url = getImageUrl(imageId);
      } else if (isUrl(imageId)) {
        url = imageId;
      }
      this._map.loadImage(url, (error?: Error, image?: HTMLImageElement | ImageBitmap) => {
        if (error) { throw error; }
        if (!image) { throw new Error('getting image failed.'); }
        this._map.addImage(imageId, image);
      });
    } catch (error: any) {
      console.error(error);
    }
  }

  private addSource(url: string, id?: string, layerSourceId?: string) {
    id = id || randomString();
    if (this._sources[id]) {
      throw Error('This source id is existed already.');
    }
    const isGeojson = isUrl(url);
    let source: mapboxgl.AnySourceData | undefined;
    if (isGeojson) {
      source = {
        type: 'geojson',
        data: url,
      };
    } else {
      source = {
        type: 'vector',
        url,
      };
    }
    const layerId = `layer-${id}`;
    const layer = createLayer(layerId, id, layerSourceId);
    this._sources[id] = source;
    this._layers[id] = layer;
    this._map.addSource(id, source);
    this._map.addLayer(layer);
    this._map.on('click', layerId, this.click.bind(this));
  }

  // private removeSource(id: string) {
  //   if (!this._sources[id]) {
  //     throw Error('This source id is not existed');
  //   }
  //   this._map.removeLayer(`layer-${id}`);
  //   this._map.removeSource(id);
  // }

  public reload() {
    for (const id of this.sourceIds) {
      const layerId = `layer-${id}`;
      const currentSource = this._map.getSource(id);
      const currentLayer = this._map.getLayer(layerId);
      currentSource && this._map.removeSource(id);
      currentLayer && this._map.removeLayer(layerId);
      this._map.addSource(id, currentSource);
      this._map.addLayer(currentLayer);
      this._map.on('click', layerId, this.click.bind(this));
    }
  }

  private updateRenderedFeatures() {
    const features = this.promotionFeatures();
    const appearedFeatures: Feature[] = [];
    const disappearedFeatures: Feature[] = [];
    
    // disappeared feature objects that was rendered before
    this._renderedFeatures = this._renderedFeatures.filter(renderedFeature => {
      const isExist = !!features.find(feature => renderedFeature.properties.adid === feature.properties.adid);
      if (!isExist) {
        renderedFeature.visibleEndTime = Date.now();
        disappearedFeatures.push(renderedFeature);
        return false;
      }
      return true;
    });

    // adding appeared new feature objects
    for (const feature of features) {
      const isExisted = !!this._renderedFeatures.find(renderedFeature => renderedFeature.properties.adid === feature.properties.adid);
      if (!isExisted && feature.properties.adid) {
        feature.visibleStartTime = Date.now();
        appearedFeatures.push(feature);
      }
    };

    this._renderedFeatures = this._renderedFeatures.concat(appearedFeatures);

    disappearedFeatures.length && (
      telemetryAPIs.sendVisibilities(disappearedFeatures)
    );
  }

  // private hasListener(type: EventTypes) {
  //   return !!this._listeners && this._listeners[type] && this._listeners[type].length > 0;
  // }

  public promotionFeatures(): Feature[] {
    const features = this._map.queryRenderedFeatures(undefined, { layers: this.layerIds });
    const promotionFeatures: Feature[] = [];
    for (const feature of features) {
      feature.properties && feature.properties['adid'] && (
        promotionFeatures.push(feature as Feature)
      );
    }
    return promotionFeatures;
  }

  public selectPin(feature: Feature) {
    const { adid } = feature.properties as Feature.Properties;
    if (!adid) { return; }
    const textColor = createSelectedTextColor(adid);
    const textHaloColor = createSelectedTextHaloColor(adid);
    for (const layerId of this.layerIds) {
      this._map.setPaintProperty(layerId, 'text-color', textColor);
      this._map.setPaintProperty(layerId, 'text-halo-color', textHaloColor);
    }
  }

  public deselectPin() {
    for (const layerId of this.layerIds) {
      this._map.setPaintProperty(
        layerId,
        'text-color',
        this.isDarkMode ? COLORS.FONT_COLOR_LIGHT : COLORS.FONT_COLOR_DARK,
      );
      this._map.setPaintProperty(
        layerId,
        'text-halo-color',
        this.isDarkMode ? COLORS.FONT_HALO_COLOR_LIGHT : COLORS.FONT_HALO_COLOR_DARK,
      );
    }
  }

  public deselectLayer() {
    this.deselectPin();
  }
}

export default Promoted;
