import { Popup } from 'mapbox-gl';
import { Promoted } from '.';
import { formatProperties } from 'utils/feature';
import { Event } from './event';
import { EVENT_TYPES, TELEMETRY_ACTIONS } from './helpers';

import * as telemetryAPIs from 'apis/telemetry';

class PromotionPopup {
  private _promoted: Promoted;
  private _popup?: Popup;

  constructor(promoted: Promoted) {
    this._promoted = promoted;
  }

  public get id() {
    return 'PromotionPopup';
  }

  private sendAction(adid: string, clickType: PromotionPopup.ClickTypes) {
    const action = TELEMETRY_ACTIONS[clickType];
    action && telemetryAPIs.sendAction(adid, action as TelemetryAPI.Actions);
  }

  public show(feature: Feature) {
    this.remove();

    const properties = formatProperties(feature.properties);
    const coordinates = (feature.geometry as any).coordinates.slice();
    const adidClass = `mapbox-promoted-popup-adid__${properties.adid}`;
    const popup = document.querySelector(`.${adidClass}`);
    if (popup) { return; }

    this._promoted.fire(new Event(EVENT_TYPES.SHOW_POPUP, { feature }));

    this._popup = new Popup({
      closeOnClick: false,
      closeButton: false,
      className: `mapbox-promoted-popup ${adidClass}`,
    }).setLngLat(coordinates)
      .setHTML(`<div class="mapbox-promoted-popup-content-adid__${properties.adid}" />`)
      .addTo(this._promoted.map);

    showPromotionPopup && showPromotionPopup(
      properties,
      (clickType: PromotionPopup.ClickTypes, adid: string) => {
        this._promoted.fire(new Event(EVENT_TYPES.CLICK_POPUP, { clickType, feature }));
        this.sendAction(adid, clickType); 
      },
      (adid: string) => {
        this._promoted.fire(new Event(EVENT_TYPES.CLOSE_POPUP, { feature }));
        this._promoted.deselectLayer();
        this.remove();
        telemetryAPIs.sendDeselection(adid);
      }
    );
    this._promoted.selectPin(feature);
  }

  public remove() {
    if (!this._popup) { return; }
    this._popup.remove.bind(this);
    this._popup = undefined;
  }
}

export default PromotionPopup;
