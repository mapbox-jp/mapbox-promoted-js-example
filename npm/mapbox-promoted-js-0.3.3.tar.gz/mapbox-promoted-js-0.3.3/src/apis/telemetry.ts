import ajax from './ajax';
import { differenceInSeconds } from 'date-fns';
import { randomString } from 'utils/string';
import { CONFIG } from 'utils/config';
import { ACTIONS, FEEDBACK_ACTIONS, FEEDBACK_TYPES } from './telemetry.helper';

export {
  ACTIONS,
  FEEDBACK_ACTIONS,
  FEEDBACK_TYPES
};

let lastSessionTime = new Date();
let sessionIdentifier = randomString();

export const isSessionExpired = () => (
  !lastSessionTime || differenceInSeconds(new Date(), lastSessionTime) > 60
);

export const verifySession = (): Promise<any> | undefined => {
  if (CONFIG.DEBUG) { return; }
  lastSessionTime = new Date();
  sessionIdentifier = randomString();
  return sessionStart();
};

function sendEvent(params: Object): Promise<Object> {
  return new Promise((resolve, reject) => {
    const url = `/events/v2?access_token=${CONFIG.ACCESS_TOKEN}`;
    return new ajax().post(url, params).then((response: any) => {
      resolve(response);
    }).catch((error: Error) => {
      console.error(error);
      reject(error);
    });
  });
};

export function sessionStart(): Promise<any> {
  const params = {
    sessionIdentifier,
    event: 'adMetrics.sessionStart',
    bucket: 'undefined',
    created: new Date().toISOString(),
  };
  return sendEvent([params]);
}

export function sendSelection(adid: string, zoomLevel: number): Promise<any> {
  const promises = [];
  const params = {
    sessionIdentifier,
    event: 'adMetrics.select',
    adid,
    zoomLevel,
    created: new Date().toISOString(),
  };
  isSessionExpired() && promises.push(verifySession());
  promises.push(sendEvent([params]))
  return Promise.all(promises);
}

export function sendDeselection(adid: string): Promise<any> {
  const promises = [];
  const params = {
    sessionIdentifier,
    event: 'adMetrics.deselect',
    adid,
    created: new Date().toISOString(),
  };
  isSessionExpired() && promises.push(verifySession());
  promises.push(sendEvent([params]))
  return Promise.all(promises);
}

export function sendVisibilities(
  features: Feature[]
): Promise<any> {
  const promises = [];
  const params = features.map(({
    properties,
    visibleStartTime,
    visibleEndTime
  }) => ({
    sessionIdentifier,
    event: 'adMetrics.visible',
    adid: properties.adid,
    visibleStartTime,
    visibleEndTime,
    created: new Date().toISOString(),
  }));
  isSessionExpired() && promises.push(verifySession());
  promises.push(sendEvent([params]))
  return Promise.all(promises);
}

export function sendAction(
  adid: string,
  action: TelemetryAPI.Actions
): Promise<any> {
  const promises = [];
  const params = {
    sessionIdentifier,
    event: 'adMetrics.callToAction',
    adid,
    action,
    created: new Date().toISOString(),
  };
  isSessionExpired() && promises.push(verifySession());
  promises.push(sendEvent([params]))
  return Promise.all(promises);
}

export function sendFeedback(
  adid: string,
  action: TelemetryAPI.FeedbackActions,
  type: TelemetryAPI.FeedbackTypes
): Promise<any> {
  const promises = [];
  const params = {
    sessionIdentifier,
    event: 'adMetrics.feedback',
    adid,
    action,
    type,
    description: '',
    created: new Date().toISOString(),
  };
  promises.push(sendEvent([params]))
  return Promise.all(promises);
}
