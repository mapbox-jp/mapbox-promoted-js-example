import { CONFIG } from 'utils/config';

type Options = {
  isAsync?: boolean;
};

class Ajax {
  private _request: XMLHttpRequest;
  private _baseUrl: string;

  constructor(baseUrl?: string) {
    this._request = new XMLHttpRequest();
    this._baseUrl = baseUrl || CONFIG.BASE_URL;
  }

  public get isSuccess() {
    return (
      (this._request.status >= 200 && this._request.status < 300) || this._request.status === 0
    ) && this._request.response !== null;
  }

  public createRequest(resolve: (value: any) => void, reject: (value: any) => void, method: string, url: string, isAsync: boolean) {
    this._request.open(method, `${this._baseUrl}${url}`, isAsync);
    this._request.setRequestHeader('Content-Type', 'application/json');
    this._request.onload = () => {
      if (this.isSuccess) {
        resolve({});
      } else {
        reject(new Error(`${this._request.statusText}${this._request.status}: ${url}`));
      }
    };
    this._request.onerror = () => {
      reject(new Error(this._request.statusText));
    };
  }

  public post(url: string, data?: Object, options: Options = { isAsync: true }) {
    const { isAsync } = options;
    return new Promise((resolve, reject) => {
      try {
        const dataString = JSON.stringify(data);
        this.createRequest(resolve, reject, 'POST', url, !!isAsync);
        this._request.send(dataString);
      } catch (error) {
        reject(error);
      }
    });
  }

  public get(url: string, options: Options = { isAsync: true }) {
    const { isAsync } = options;
    return new Promise((resolve, reject) => {
      try {
        this.createRequest(resolve, reject, 'GET', url, !!isAsync);
        this._request.send();
      } catch (error) {
        reject(error);
      }
    });
  }
}

export default Ajax;
