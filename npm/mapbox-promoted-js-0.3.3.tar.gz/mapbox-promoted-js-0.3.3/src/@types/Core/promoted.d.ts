declare namespace Promoted {
  type Options = {
    baseUrl?: string;
    telemetryUrl?: string;
    sourceUrl?: string;
    layerSourceId?: string;
    mobileMaxWidth?: number;
    enablePromotionPopup?: boolean;
    enablePromotionCard?: boolean;
    enablePromotionSideCard?: boolean;
    isDarkMode?: boolean;
    debug?: boolean;
  };

  class Event {
    type: EventTypes;
    data: Object;
    constructor(type: EventTypes, data?: Object);
  }

  const EVENT_TYPES: {
    readonly LOAD: 'load';
    readonly MOVE: 'move';
    readonly CLICK_PIN: 'click_pin';
    readonly CLICK_CARD: 'click_card';
    readonly SHOW_CARD: 'show_card';
    readonly UPDATE_CARD: 'update_card';
    readonly CLOSE_CARD: 'close_card';
    readonly CLICK_SIDE_CARD: 'click_side_card';
    readonly SHOW_SIDE_CARD: 'show_side_card';
    readonly UPDATE_SIDE_CARD: 'update_side_card';
    readonly OPEN_SIDE_CARD: 'open_side_card';
    readonly HIDE_SIDE_CARD: 'hide_side_card';
    readonly CLOSE_SIDE_CARD: 'close_side_card';
    readonly CLICK_POPUP: 'click_popup';
    readonly SHOW_POPUP: 'show_popup';
    readonly CLOSE_POPUP: 'close_popup';
  }
  
  type EventTypes = typeof EVENT_TYPES[keyof typeof EVENT_TYPES];
  type Listener = (type: EventTypes, event: any) => any;
  type Listeners = { [key: string]: Array<Listener> };
}

declare class Promoted {
  private _map: mapboxgl.Map;
  private _sourceUrl?: string;
  private _layerSourceId?: string;
  private _sources: { [key: string]: mapboxgl.AnySourceData };
  private _layers: { [key: string]: mapboxgl.SymbolLayer };
  private _isDarkMode: boolean;
  private _enablePromotionPopup: boolean;
  private _enablePromotionCard: boolean;
  private _enablePromotionSideCard: boolean;
  private _promotionCard?: PromotionCard;
  private _promotionPopup?: PromotionPopup;
  private _promotionSideCard?: PromotionSideCard;
  private _listeners: Promoted.Listeners;
  private _renderedFeatures: Feature[];
  constructor(map: mapboxgl.Map, token: string, options?: Promoted.Options);
  get map(): mapboxgl.Map;
  get mobileMaxWidth(): number;
  set mobileMaxWidth(mobileMaxWidth: number);
  get isDarkMode(): boolean;
  set isDarkMode(isDarkMode: boolean);
  get layer(): mapboxgl.AnyLayer;
  get debug(): boolean;
  set debug(debug: boolean);
  get enablePromotionPopup(): boolean;
  set enablePromotionPopup(enablePromotionPopup: boolean);
  get enablePromotionCard(): boolean;
  set enablePromotionCard(enablePromotionCard: boolean);
  get enablePromotionSideCard(): boolean;
  set enablePromotionSideCard(enablePromotionSideCard: boolean);
  private sourceIds;
  private layerIds;
  private activate;
  private load;
  private render;
  private move;
  private show;
  private click;
  on(type: Promoted.EventTypes, listener: Promoted.Listener): void;
  off(type: Promoted.EventTypes, listener: Promoted.Listener): void;
  fire(event: Event): void;
  private styleImageMissing;
  private addSource;
  private reloadPromotionLalyer;
  private updateRenderedFeatures;
  promotionFeatures(): Feature[];
  selectPin(feature: Feature): void;
  deselectPin(): void;
  deselectLayer(): void;
}
