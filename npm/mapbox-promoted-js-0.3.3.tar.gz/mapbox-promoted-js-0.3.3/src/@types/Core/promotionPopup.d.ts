declare class PromotionPopup {
  private _promoted;
  private _popup?;
  constructor(promoted: Promoted);
  get id(): string;
  private sendAction;
  show(feature: Feature): void;
  remove(): void;
}
