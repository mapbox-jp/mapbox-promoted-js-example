declare class PromotionCard {
  private _promoted;
  constructor(promoted: Promoted);
  get id(): string;
  private sendAction;
  show(feature: Feature): void;
  private remove;
}
