declare namespace Feature {
  interface Properties {
    adid: string;
    type?: Types;
    icon?: string;
    advertizer?: string;
    category?: string;
    addressJa?: string;
    addressEn?: string;
    nameJa?: string;
    nameEn?: string;
    subtitle?: string;
    phoneNumber?: string;
    promotionBanner?: string;
    promotionBannerWidth?: number;
    promotionBannerHeight?: number;
    promotionCard?: string;
    promotionUrl?: string;
    displayPromotionInternal?: boolean;
    directions?: string;
    lat?: string;
    lng?: string;
    minZoom?: string;
    satOpen?: string;
    satClose?: string;
    sunOpen?: string;
    sunClose?: string;
    weekOpen?: string;
    weekClose?: string;
    holidayOpen?: string;
    holidayClose?: string;
  }
  const TYPES: {
    readonly POPUP: 'popup';
    readonly CARD: 'card';
    readonly SIDE_CARD: 'side_card';
  }
  type Types = typeof TYPES[keyof typeof TYPES];
}
declare interface Feature extends mapboxgl.MapboxGeoJSONFeature {
  properties: Feature.Properties;
  geometry: GeoJSON.Geometry;
  visibleStartTime?: number;
  visibleEndTime?: number;
}
