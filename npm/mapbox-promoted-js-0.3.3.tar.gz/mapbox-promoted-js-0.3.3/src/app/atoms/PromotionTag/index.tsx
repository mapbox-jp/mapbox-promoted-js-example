import React from 'react';
import { Container } from './styles';

type Props = {
  classPrefix?: string;
};

const PromotionTag: React.FC<Props> = props => {
  const { classPrefix } = props;
  return (
    <Container className={`${classPrefix ? `${classPrefix}__` : ''}promotion-tag`}>
      広告
    </Container>
  );
};

export default PromotionTag;
