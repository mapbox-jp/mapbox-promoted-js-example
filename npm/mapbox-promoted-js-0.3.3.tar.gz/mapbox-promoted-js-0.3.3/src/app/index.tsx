import { CONFIG } from 'utils/config';
import PromotionPopup from './promotions/Popup';
import PromotionCard from './promotions/Card';
import PromotionSideCard from './promotions/SideCard';

window.addEventListener('DOMContentLoaded', () => {
  window.renderApp = (updateConfig: Config) => {
    CONFIG.ACCESS_TOKEN     = updateConfig.ACCESS_TOKEN;
    CONFIG.BASE_URL         = updateConfig.BASE_URL;
    CONFIG.SOURCE_URL       = updateConfig.SOURCE_URL;
    CONFIG.MOBILE_MAX_WIDTH = updateConfig.MOBILE_MAX_WIDTH;
  };
});

export {
  PromotionPopup,
  PromotionCard,
  PromotionSideCard,
};
