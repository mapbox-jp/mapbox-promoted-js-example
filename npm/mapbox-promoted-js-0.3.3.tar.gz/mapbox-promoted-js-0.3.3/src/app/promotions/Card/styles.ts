import styled, { keyframes } from 'styled-components';
import { CONFIG } from 'utils/config';

type Container = {
  isFadeout?: boolean;
  isRendered?: boolean;
};
type MenuContainer = {
  height?: number;
  isShowing?: boolean;
};
type ToggleButtonIcon = {
  isShowing?: boolean;
};

const bounceIn = keyframes`
  from {
    opacity: 0.0;
    transform: translate3d(0, 100%, 0);
    -ms-transform: translate3d(0, 100%, 0);
  }
  to {
    opacity: 1.0;
    transform: translate3d(0, 0, 0);
    -ms-transform: translate3d(0, 0, 0);
  }
`;
const bounceOut = keyframes`
  0% {
    opacity: 1.0;
    transform: translate3d(0, 0, 0);
    -ms-transform: translate3d(0, 0, 0);
  }
  to {
    opacity: 0.0;
    transform: translate3d(0, 100%, 0);
    -ms-transform: translate3d(0, 100%, 0);
  }
`;

export const Container = styled.div`
  position: absolute;
  margin: 0 auto;
  bottom: 30px;
  left: 0;
  right: 0;
  box-shadow: 0 0 8px rgba(0, 0, 0, 0.3);
  overflow: hidden;
  z-index: 1;
  animation-duration: 0.25s;
  animation-name: ${({ isFadeout }: Container) => isFadeout ? bounceOut : bounceIn};
  @media screen and (min-width: ${CONFIG.MOBILE_MAX_WIDTH}px) {
    width: 80%;
    min-width: 500px;
    max-width: 800px;
    height: 150px;
  }
  @media screen and (max-width: ${CONFIG.MOBILE_MAX_WIDTH}px) {
    width: 90%;
    border-radius: 5px;
  }
`;
export const Wrapper = styled.div`
  background: rgb(255, 255, 255);
  @media screen and (min-width: ${CONFIG.MOBILE_MAX_WIDTH}px) {
    display: flex;
  }
`;
export const Banner = styled.div`
  background-color: rgb(142, 142, 142);
  @media screen and (min-width: ${CONFIG.MOBILE_MAX_WIDTH}px) {
    width: 150px;
    height: 150px;
  }
  @media screen and (max-width: ${CONFIG.MOBILE_MAX_WIDTH}px) {
    width: 100%;
  }
`;
export const BannerImg = styled.img`
  @media screen and (min-width: ${CONFIG.MOBILE_MAX_WIDTH}px) {
    width: 150px;
    height: 150px;
  }
  @media screen and (max-width: ${CONFIG.MOBILE_MAX_WIDTH}px) {
    width: 100%;
  }
`;
export const Content = styled.div`
  padding: 16px 16px;
  @media screen and (min-width: ${CONFIG.MOBILE_MAX_WIDTH}px) {
    display: flex;
    width: calc(100% - 150px);
  }
`;
export const LeftContent = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  @media screen and (min-width: ${CONFIG.MOBILE_MAX_WIDTH}px) {
    padding: 0 16px 0 0;
    width: 50%;
    max-width: 50%;
    border-right: 1px solid rgba(0, 0, 0, 0.05);
  }
`;
export const RightContent = styled.div`
  @media screen and (min-width: ${CONFIG.MOBILE_MAX_WIDTH}px) {
    padding: 0 0 0 16px;
    width: 50%;
    max-width: 50%;
  }
  @media screen and (max-width: ${CONFIG.MOBILE_MAX_WIDTH}px) {
    margin-top: 12px;
  }
`;
export const Header = styled.div``;
export const HeaderTitle = styled.div`
  display: flex;
  position: relative;
`;
export const HeaderTitleLabel = styled.h1`
  display: -webkit-box;
  margin: 0;
  width: calc(100% - 36px - 10px);
  font-size: 15px;
  overflow: hidden;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
`;
export const HeaderPromotionTag = styled.div`
  position: absolute;
  top: 0;
  right: 0;
`;
export const HeaderSubtitle = styled.div`
  margin-top: 5px;
  font-size: 13px;
`;
export const HeaderSubtitleLabel = styled.span``;
export const Toggle = styled.div``;
export const ToggleButton = styled.button`
  display: block;
  padding: 0;
  margin: auto;
  width: 100%;
  border: none;
  background-color: transparent;
  font-size: 15px;
  color: rgb(26,115,232);
  cursor: pointer;
`;
export const ToggleButtonIcon = styled.span`
  display: block;
  transform: rotate(${({ isShowing }: ToggleButtonIcon) => isShowing ? '0deg' : '180deg'});
  transition-property: -webkit-transform, transform, opacity;
  transition-duration: 0.2s;
  transition-timing-function: cubic-bezier(0.0, 0.0, 0.2, 1);
`;
export const MenuContainer = styled.div`
  height: ${({ height, isShowing }: MenuContainer) => isShowing ? `${height}px` : '0'};
  overflow: hidden;
  @media screen and (min-width: ${CONFIG.MOBILE_MAX_WIDTH}px) {

  }
  @media screen and (max-width: ${CONFIG.MOBILE_MAX_WIDTH}px) {
    margin-top: ${({ isShowing }: MenuContainer) => isShowing ? '5px' : '0'};
    transition: height 0.1s;
    will-change: height;
  }
`;
export const Menu = styled.ul`
  margin: 0;
  padding: 0;
  list-style: none;
`;
export const ActionsContainer = styled.div`
  overflow-x: auto;
  scrollbar-width: none;
  &::-webkit-scrollbar {
    display:none;
  }
  @media screen and (min-width: ${CONFIG.MOBILE_MAX_WIDTH}px) {

  }
  @media screen and (max-width: ${CONFIG.MOBILE_MAX_WIDTH}px) {
    margin-top: 14px;
  }
`;
export const Actions = styled.ul`
  display: flex;
  margin: 0;
  padding: 0;
  list-style: none;
`;
