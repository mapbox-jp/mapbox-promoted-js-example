import ReactDOM from 'react-dom';
import React, { useRef, useEffect, useState, useMemo } from 'react';
import { getImageUrl } from 'utils/urls';
import { isUrl } from 'utils/string';
import * as browser from 'utils/browser';
import Icon, { ICON_TYPE } from 'atoms/Icon';
import PromotionTag from 'atoms/PromotionTag';
import ActionItems from './ActionItems';
import MenuItems from './MenuItems';
import {
  Container,
  Wrapper,
  Banner,
  BannerImg,
  Content,
  LeftContent,
  RightContent,
  Header,
  HeaderTitle,
  HeaderTitleLabel,
  HeaderPromotionTag,
  HeaderSubtitle,
  HeaderSubtitleLabel,
  ActionsContainer,
  Actions,
  Toggle,
  ToggleButton,
  ToggleButtonIcon,
  MenuContainer,
  Menu,
} from './styles';
import { CLICK_TYPES } from './helpers';

window.showPromotionCard = (
  properties: Feature.Properties,
  onClick?: (type: PromotionCard.ClickTypes, adid: string) => void,
  onClose?: (adid: string) => void
) => {
  ReactDOM.render(
    <Card
      properties={properties}
      onClick={onClick}
      onClose={onClose}
    />,
    document.querySelector('.mapbox-promoted-card')
  );
};

type Props = {
  properties: Feature.Properties;
  onClick?: (type: PromotionCard.ClickTypes, adid: string) => void;
  onClose?: (adid: string) => void;
};

const Card: React.FC<Props> = props => {
  const { onClick, onClose } = props;

  const ref = useRef<HTMLDivElement>(null);
  const menuContainerRef = useRef<HTMLDivElement>(null);
  const isUpdated = useRef<boolean>(false);
  const [properties, setProperties] = useState(props.properties);
  const [isSp, setIsSp] = useState(browser.isSp());
  const [isShowing, setIsShowing] = useState(false);
  const [isFadeout, setIsFadeout] = useState(false);
  const [isRendered, setIsRendered] = useState(false);

  const { adid, nameJa, subtitle } = properties;

  const promotionBanner = useMemo(() => {
    if (!properties.promotionBanner) { return ''; }
    return isUrl(properties.promotionBanner) ? properties.promotionBanner : getImageUrl(properties.promotionBanner);
  }, [])
  const promotionCard = useMemo(() => {
    if (!properties.promotionCard) { return ''; }
    return isUrl(properties.promotionCard) ? properties.promotionCard : getImageUrl(properties.promotionCard);
  }, [])

  window.updatePromotionCard = (updateProperties: Feature.Properties) => {
    isUpdated.current = true;
    setProperties(updateProperties);
  };
  window.closePromotionCard = () => {
    close();
  };

  const close = () => {
    if (!isUpdated.current) {
      setIsFadeout(true);
      setTimeout(() => {
        removeEventListeners();
        onClose && onClose(adid);
      }, 200);
    }
    isUpdated.current = false;
  };
  const removeEventListeners = () => {
    document.removeEventListener('click', handleClickOutside);
    window.removeEventListener('resize', handleResize);
  };

  const handleToggle = () => {
    setIsShowing(!isShowing);
  }
  const handleClick = (type: PromotionCard.ClickTypes) => {
    onClick && onClick(type, adid);
  };
  const handleClickOutside = (event: MouseEvent) => {
    if (ref.current && !ref.current.contains(event.target as Node)) {
      close();
    }
  };
  const handleResize = () => {
    setIsSp(browser.isSp());
  };

  useEffect(() => {
    document.addEventListener('click', handleClickOutside);
    window.addEventListener('resize', handleResize);
    return () => removeEventListeners();
  }, []);
  useEffect(() => {
    if (ref.current) {
      setIsRendered(true);
    }
  }, [ref]);

  return (
    <Container
      className='promotion-card'
      isFadeout={isFadeout}
      isRendered={isRendered}
      onClick={() => handleClick(CLICK_TYPES.CARD)}
      ref={ref}
    >
      <Wrapper className='promotion-card__wrapper'>
        <Banner
          className='promotion-card__banner-img'
          onClick={() => handleClick(CLICK_TYPES.BANNER)}
        >
          <BannerImg
            className='promotion-card__banner-img'
            src={isSp ? promotionBanner : promotionCard}
          />
        </Banner>
        <Content className='promotion-card__content'>
          <LeftContent className='promotion-card__content-left'>
            <Header className='promotion-card__header'>
              <HeaderTitle className='promotion-card__header__title'>
                <HeaderTitleLabel className='promotion-card__header__title-label'>
                  {nameJa || ''}
                </HeaderTitleLabel>
                <HeaderPromotionTag className='promotion-card__promotion-tag__wrapper'>
                  <PromotionTag classPrefix='promotion-card' />
                </HeaderPromotionTag>
              </HeaderTitle>
              {subtitle && (
                <HeaderSubtitle className='promotion-card__header__subtitle'>
                  <HeaderSubtitleLabel className='promotion-card__header__subtitle-label'>
                    {subtitle}
                  </HeaderSubtitleLabel>
                </HeaderSubtitle>
              )}
            </Header>
            {properties && (
              <ActionsContainer className='promotion-card__actions__container'>
                <Actions className='promotion-card__actions'>
                  <ActionItems
                    properties={properties}
                    onClick={handleClick}
                  />
                </Actions>
              </ActionsContainer>
            )}
          </LeftContent>
          <RightContent className='promotion-card__content-right'>
            {isSp && properties && (
              <Toggle className='promotion-card__toggle'>
                <ToggleButton
                  className='promotion-card__toggle-button'
                  onClick={handleToggle}
                >
                  <ToggleButtonIcon
                    className='promotion-card__toggle-button__icon'
                    isShowing={isShowing}
                  >
                    <Icon type={ICON_TYPE.CHEVRON_UP} />
                  </ToggleButtonIcon>
                </ToggleButton>
              </Toggle>
            )}
            {properties && (
              <MenuContainer
                className='promotion-card__menus__container'
                height={menuContainerRef.current?.scrollHeight}
                isShowing={!isSp || isShowing}
                ref={menuContainerRef}  
              >
                <Menu className='promotion-card__menu'>
                  <MenuItems
                    properties={properties}
                    onClick={handleClick}
                  />
                </Menu>
              </MenuContainer>
            )}
          </RightContent>
        </Content>
      </Wrapper>
    </Container>
  );
};

export default Card;
