export const CLICK_TYPES = {
  CARD: 'card',
  BANNER: 'banner',
  PHONE: 'phone',
  DIRECTIONS: 'directions',
  DETAIL: 'detail',
} as const;
