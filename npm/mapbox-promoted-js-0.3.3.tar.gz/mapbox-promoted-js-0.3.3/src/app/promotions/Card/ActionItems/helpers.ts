import { ICON_TYPE } from 'atoms/Icon';
import { CLICK_TYPES } from '../helpers';

export const ACTION_TYPES = {
  DIRECTIONS: 'action-type-directions',
  PHONE_NUMBER: 'action-type-phone-number',
  PROMOTION_URL: 'action-type-promotion-url',
} as const;

export type ActionTypes = typeof ACTION_TYPES[keyof typeof ACTION_TYPES];

type Actions = {
  [key in ActionTypes]: {
    key: string;
    iconType: string;
    clickType?: PromotionCard.ClickTypes;
    label: string;
    isRequired?: boolean;
  };
};

export const ACTIONS: Actions = {
  [ACTION_TYPES.DIRECTIONS]: {
    key: 'directions',
    iconType: ICON_TYPE.ROUTE,
    clickType: CLICK_TYPES.DIRECTIONS,
    label: '行き方',
    isRequired: true,
  },
  [ACTION_TYPES.PHONE_NUMBER]: {
    key: 'phoneNumber',
    iconType: ICON_TYPE.PHONE,
    clickType: CLICK_TYPES.PHONE,
    label: '電話番号',
  },
  [ACTION_TYPES.PROMOTION_URL]: {
    key: 'promotionUrl',
    iconType: ICON_TYPE.EARTH,
    clickType: CLICK_TYPES.DETAIL,
    label: '関連サイト',
  }
};
