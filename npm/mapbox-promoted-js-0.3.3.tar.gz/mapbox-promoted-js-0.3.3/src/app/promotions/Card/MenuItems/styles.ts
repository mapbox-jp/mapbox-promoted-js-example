import styled from 'styled-components';

type MenuItem = {
  isAction?: boolean;
};
type MenuItemLabel = {
  lineClamp?: number;
};

export const MenuItem = styled.li`
  display: flex;
  align-items: center;
  padding: 6px 0;
  margin-left: 0 !important;
  overflow-wrap: break-word;
  transition: background-color 0.1s;
  cursor: ${({ isAction }: MenuItem) => isAction && 'pointer'};
  &:last-child {
    padding-bottom: 0;
  }
`;
export const MenuItemIcon = styled.span`
  display: flex;
  justify-content: center;
  align-items: center;
  margin-right: 10px;
  padding: 2px;
  width: 19px;
  min-width: 19px;
  height: 19px;
  min-height: 19px;
  font-size: 15px;
  color: #1a73e8;
`;
export const MenuItemLabel = styled.span`
  display: -webkit-box;
  font-size: 13px;
  line-height: 1.5;
  overflow: hidden;
  -webkit-line-clamp: ${({ lineClamp }: MenuItemLabel) => lineClamp || 1};
  -webkit-box-orient: vertical;
`;
