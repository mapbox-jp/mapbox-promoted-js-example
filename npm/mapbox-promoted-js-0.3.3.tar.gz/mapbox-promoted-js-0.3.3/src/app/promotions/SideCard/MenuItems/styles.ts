import styled, { css } from 'styled-components';

type MenuItem = {
  isAction?: boolean;
};
type MenuItemLabel = {
  lineClamp?: number;
};

const hover = css`
  cursor: pointer;
  transition: background-color 0.1s;
  &:hover {
    background-color: #f1f3f4;
  }
`;

export const MenuItem = styled.li`
  display: flex;
  align-items: center;
  padding: 8px 22px 8px 16px;
  line-height: 1;
  overflow-wrap: break-word;
  ${({ isAction }: MenuItem) => isAction && hover}
`;
export const MenuItemIcon = styled.span`
  display: flex;
  justify-content: center;
  align-items: center;
  margin-right: 10px;
  padding: 2px;
  width: 19px;
  min-width: 19px;
  height: 19px;
  min-height: 19px;
  font-size: 15px;
  color: #1a73e8;
`;
export const MenuItemLabel = styled.span`
  display: -webkit-box;
  font-size: 13px;
  line-height: 1.5;
  overflow: hidden;
  -webkit-line-clamp: ${({ lineClamp }: MenuItemLabel) => lineClamp || 1};
  -webkit-box-orient: vertical;
`;
