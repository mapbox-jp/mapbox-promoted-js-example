import { ICON_TYPE } from 'atoms/Icon';
import { getOpenCloseLabel } from 'utils/feature';
import { CLICK_TYPES } from '../helpers';

export const MENU_TYPES = {
  ADDRESS_JA: 'menu-type-address-ja',
  ADDRESS_EN: 'menu-type-address-en',
  PHONE_NUMBER: 'menu-type-phone-number',
  OPEN_AND_CLOSE: 'menu-type-open-and-close',
} as const;

export type MenuTypes = typeof MENU_TYPES[keyof typeof MENU_TYPES];

type Menu = {
  [key in MenuTypes]: {
    key: string;
    iconType: string;
    clickType?: PromotionSideCard.ClickTypes;
    isRequired?: boolean;
    isAction?: boolean;
    label?: (properties: Feature.Properties) => (string | undefined);
    lineClamp?: number;
  };
};

export const MENUS: Menu = {
  [MENU_TYPES.ADDRESS_JA]: {
    key: 'addressJa',
    iconType: ICON_TYPE.MAP_MARKER_ALT,
    lineClamp: 2,
  },
  [MENU_TYPES.ADDRESS_EN]: {
    key: 'addressEn',
    iconType: ICON_TYPE.MAP_MARKER_ALT,
  },
  [MENU_TYPES.PHONE_NUMBER]: {
    key: 'phoneNumber',
    iconType: ICON_TYPE.PHONE,
    clickType: CLICK_TYPES.PHONE,
    isAction: true,
  },
  [MENU_TYPES.OPEN_AND_CLOSE]: {
    key: '',
    iconType: ICON_TYPE.CLOCK,
    isRequired: true,
    label: properties => {
      const label = getOpenCloseLabel(properties);
      return label && `本日の営業時間: ${label}<br />詳細はお問い合わせください。`;
    }
  },
};
