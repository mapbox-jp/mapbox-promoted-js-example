import ReactDOM from 'react-dom';
import React, { useRef, useEffect, useState, useMemo } from 'react';
import { getImageUrl } from 'utils/urls';
import { isUrl } from 'utils/string';
import Icon, { ICON_TYPE } from 'atoms/Icon';
import PromotionTag from 'atoms/PromotionTag';
import ActionItems from './ActionItems';
import MenuItems from './MenuItems';
import {
  Container,
  Wrapper,
  ContentWrapper,
  Toggle,
  ToggleButton,
  ToggleButtonIcon,
  Banner,
  BannerImg,
  Content,
  Header,
  HeaderTitle,
  HeaderTitleLabel,
  HeaderPromotionTag,
  HeaderSubtitle,
  HeaderSubtitleLabel,
  ActionsContainer,
  Actions,
  ActionSpace,
  MenuContainer,
  Menu,
} from './styles';
import { CLICK_TYPES } from './helpers';

window.showPromotionSideCard = (
  properties: Feature.Properties,
  onClick?: (type: PromotionSideCard.ClickTypes, adid: string) => void,
  onClose?: (adid: string) => void,
  onOpen?: (adid: string) => void,
  onHide?: (adid: string) => void,
) => {
  ReactDOM.render(
    <SideCard
      properties={properties}
      onClick={onClick}
      onClose={onClose}
      onOpen={onOpen}
      onHide={onHide}
    />,
    document.querySelector('.mapbox-promoted-side-card')
  );
};

type Props = {
  properties: Feature.Properties;
  onClick?: (type: PromotionSideCard.ClickTypes, adid: string) => void;
  onClose?: (adid: string) => void;
  onOpen?: (adid: string) => void;
  onHide?: (adid: string) => void;
};

const SideCard: React.FC<Props> = props => {
  const { onClick, onClose, onOpen, onHide } = props;

  const ref = useRef<HTMLDivElement>(null);
  const isUpdated = useRef<boolean>(false);
  const [properties, setProperties] = useState(props.properties);
  const [isShowing, setIsShowing] = useState(false);
  const [isFadeout, setIsFadeout] = useState(false);
  const [isRendered, setIsRendered] = useState(false);

  const { adid, nameJa, subtitle, promotionBannerWidth, promotionBannerHeight } = properties;

  const promotionBanner = useMemo(() => {
    if (!properties.promotionBanner) { return ''; }
    return isUrl(properties.promotionBanner) ? properties.promotionBanner : getImageUrl(properties.promotionBanner);
  }, [])

  window.updatePromotionSideCard = (updateProperties: Feature.Properties) => {
    isUpdated.current = true;
    updateProperties && setProperties(updateProperties);
    setIsShowing(true);
  };
  window.openPromotionSideCard = () => {
    setIsShowing(true);
  };
  window.hidePromotionSideCard = () => {
    setIsShowing(false);
  };
  window.closePromotionSideCard = () => {
    close();
  };

  const close = () => {
    if (!isUpdated.current) {
      setIsShowing(false);
      setIsFadeout(true);
      setTimeout(() => {
        removeEventListeners();
        onClose && onClose(adid);
      }, 200);
    }
    isUpdated.current = false;
  };
  const removeEventListeners = () => {
    document.removeEventListener('click', handleClickOutside);
  };

  const handleClick = (type: PromotionSideCard.ClickTypes) => {
    onClick && onClick(type, adid);
  };
  const handleToggle = () => {
    onClick && onClick(CLICK_TYPES.TOGGLE, adid);
    if (isShowing) {
      onHide && onHide(adid);
    } else {
      onOpen && onOpen(adid);
    }
    setIsShowing(!isShowing);
  };
  const handleClickOutside = (event: MouseEvent) => {
    if (ref.current && !ref.current.contains(event.target as Node)) {
      close();
    }
  };

  useEffect(() => {
    document.addEventListener('click', handleClickOutside);
    setIsShowing(true);
    return () => removeEventListeners();
  }, []);
  useEffect(() => {
    if (ref.current) {
      setIsRendered(true);
    }
  }, [ref]);

  return (
    <Container
      className='promotion-side-card'
      isShowing={isShowing && !!properties}
      onClick={() => handleClick(CLICK_TYPES.CARD)}
      ref={ref}
    >
      <Wrapper className='promotion-side-card__wrapper'>
        {properties && (
          <Toggle className='promotion-side-card__toggle'>
            <ToggleButton
              className='promotion-side-card__toggle-button'
              isFadeout={isFadeout}
              isRendered={isRendered}
              onClick={handleToggle}
            >
              <ToggleButtonIcon
                className='promotion-side-card__toggle-button__icon'
                isShowing={isShowing && !!properties}
              >
                <Icon type={ICON_TYPE.CHEVRON_LEFT} />
              </ToggleButtonIcon>
            </ToggleButton>
          </Toggle>        
        )}
        <ContentWrapper className='promotion-side-card__content-wrapper'>
          <Banner
            className='promotion-side-card__banner'
            onClick={() => handleClick(CLICK_TYPES.BANNER)}
          >
            <BannerImg
              className='promotion-side-card__banner-img'
              src={promotionBanner}
              width={promotionBannerWidth || ''}
              height={promotionBannerHeight || ''}
            />
          </Banner>
          <Content className='promotion-side-card__content'>
            <Header className='promotion-side-card__header'>
              <HeaderTitle className='promotion-side-card__header__title'>
                <HeaderTitleLabel className='promotion-side-card__header__title-label'>
                  {nameJa || ''}
                </HeaderTitleLabel>
                <HeaderPromotionTag className='promotion-side-card__promotion-tag__wrapper'>
                  <PromotionTag classPrefix='promotion-side-card' />
                </HeaderPromotionTag>
              </HeaderTitle>
              {subtitle && (
                <HeaderSubtitle className='promotion-side-card__header__subtitle'>
                  <HeaderSubtitleLabel className='promotion-side-card__header__subtitle-label'>
                    {subtitle}
                  </HeaderSubtitleLabel>
                </HeaderSubtitle>
              )}
            </Header>
            {properties && (
              <ActionsContainer className='promotion-side-card__actions__container'>
                <Actions className='promotion-side-card__actions'>
                  <ActionSpace />
                  <ActionItems
                    properties={properties}
                    onClick={handleClick} />
                  <ActionSpace />
                </Actions>
              </ActionsContainer>
            )}
            {properties && (
              <MenuContainer className='promotion-side-card__menus__container'>
                <Menu className='promotion-side-card__menu'>
                  <MenuItems
                    properties={properties}
                    onClick={handleClick}
                  />
                </Menu>
              </MenuContainer>
            )}
          </Content>
        </ContentWrapper>
      </Wrapper>
    </Container>
  );
};

export default SideCard;
