export const CLICK_TYPES = {
  CARD: 'card',
  TOGGLE: 'toggle',
  BANNER: 'banner',
  PHONE: 'phone',
  DIRECTIONS: 'directions',
  DETAIL: 'detail',
} as const;
