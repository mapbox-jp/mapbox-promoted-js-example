import React from 'react';
import Icon from 'atoms/Icon';
import { MENU_TYPES, MENUS, MenuTypes } from './helpers';
import {
  MenuItem,
  MenuItemIcon,
  MenuItemLabel,
} from './styles';

type Props = {
  properties: Feature.Properties;
  onClick: (type: PromotionPopup.ClickTypes) => void;
};

const MenuItems: React.FC<Props> = props => {
  const { properties, onClick } = props;
  const keys = Object.keys(MENU_TYPES) as MenuTypes[];
  const handleClick = (type: PromotionPopup.ClickTypes) => {
    onClick(type);
  };
  return (
    <>
      {keys.map(key => {
        const actionType: MenuTypes = (MENU_TYPES as any)[key];
        const action = MENUS[actionType];
        const value = (properties as any)[action.key] as string;
        const label = action.label ? action.label(properties) : value;
        const { iconType, clickType, isAction, lineClamp } = action;
        return label && (
          <MenuItem
            className='promotion-popup__menu-item'
            isAction={isAction}
            onClick={() => clickType && handleClick(clickType)}
            key={`promotion-popup__menu-items__${key}`}
          >
            <MenuItemIcon className='promotion-popup__menu-item__icon'>
              <Icon type={iconType} />
            </MenuItemIcon>
            <MenuItemLabel
              className='promotion-popup__menu-item__label'
              lineClamp={lineClamp}
            >
              {label}
            </MenuItemLabel>
          </MenuItem>
        );
      })}
    </>
  );
};

export default MenuItems;
