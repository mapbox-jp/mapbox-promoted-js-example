import React from 'react';
import Icon from 'atoms/Icon';
import { ACTION_TYPES, ACTIONS, ActionTypes } from './helpers';
import {
  ActionItem,
  ActionItemAnchor,
  ActionItemButton,
  ActionItemButtonIcon,
  ActionItemLabel,
} from './styles';

type Props = {
  properties: Feature.Properties;
  onClick: (type: PromotionPopup.ClickTypes) => void;
};

const ActionItems: React.FC<Props> = props => {
  const { properties, onClick } = props;
  const keys = Object.keys(ACTION_TYPES) as ActionTypes[];
  const handleClick = (type: PromotionPopup.ClickTypes) => {
    onClick(type);
  };
  const renderContent = (iconType: string, label: string) => (
    <>
      <ActionItemButton className='promotion-popup__actions-item__button'>
        <ActionItemButtonIcon className='promotion-popup__actions-item__button-icon'>
          <Icon type={iconType} />
        </ActionItemButtonIcon>
      </ActionItemButton>
      <ActionItemLabel className='promotion-popup__actions-item__label'>
        {label}
      </ActionItemLabel>
    </>
  );
  return (
    <>
      {keys.map((key: ActionTypes) => {
        const actionType: ActionTypes = (ACTION_TYPES as any)[key];
        const action = ACTIONS[actionType];
        const value = (properties as any)[action.key] as string;
        const { iconType, clickType, label, isRequired } = action;
        return value || isRequired ? (
          <ActionItem
            className='promotion-popup__actions-item'
            onClick={() => clickType && handleClick(clickType)}
            key={`promotion-popup__action-items__${key}`}
          >
            {actionType === ACTION_TYPES.PROMOTION_URL ? (
              <ActionItemAnchor
                href={value}
                target='_break'
                className='promotion-popup__actions-item__anchor'
              >
                {renderContent(iconType, label)}
              </ActionItemAnchor>
            ) : renderContent(iconType, label)}
          </ActionItem>
        ) : null;
      })}
    </>
  );
};

export default ActionItems;
