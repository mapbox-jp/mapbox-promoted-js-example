import styled, { keyframes } from 'styled-components';

type Container = {
  isFadeout?: boolean;
  isRendered?: boolean;
};
type Wrapper = {
  isRendered?: boolean;
};

const bounceIn = keyframes`
  from {
    opacity: 0.0;
    transform: scale3d(0.3, 0.3, 0.3);
    -ms-transform: scale3d(0.3, 0.3, 0.3);
  }
  to {
    opacity: 1.0;
    transform: scale3d(1.0, 1.0, 1.0);
    -ms-transform: scale3d(1.0, 1.0, 1.0);
  }
`;
const bounceOut = keyframes`
  from {
    opacity: 1.0;
    transform: scale3d(1.0, 1.0, 1.0);
    -ms-transform: scale3d(1.0, 1.0, 1.0);
  }
  to {
    opacity: 0.0;
    transform: scale3d(0.3, 0.3, 0.3);
    -ms-transform: scale3d(0.3, 0.3, 0.3);
  }
`;

export const Container = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  border-radius: 5px;
  box-shadow: 0 0 8px rgba(0, 0, 0, 0.3);
  overflow: hidden;
  animation-duration: 0.2s;
  animation-name: ${({ isFadeout }: Container) => isFadeout ? bounceOut : bounceIn};
`;
export const Wrapper = styled.div`
  visibility: ${({ isRendered }: Wrapper) => isRendered ? 'visible' : 'hidden'};
  width: 280px;
  background: rgb(255, 255, 255);
  z-index: 1;
`;
export const Banner = styled.div`
  width: 280px;
  background-color: rgb(142, 142, 142);
`;
export const BannerImg = styled.img`
  width: 100%;
  height: auto;
  object-fit: cover;
`;
export const Content = styled.div`
  padding: 16px;
`;
export const Header = styled.div`
  position: relative;
`;
export const HeaderTitle = styled.div``;
export const HeaderTitleLabel = styled.h1`
  display: -webkit-box;
  margin: 0;
  width: calc(100% - 36px - 10px);
  font-size: 14px;
  overflow: hidden;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
`;
export const HeaderPromotionTag = styled.div`
  position: absolute;
  top: 0;
  right: 0;
`;
export const HeaderSubtitle = styled.div`
  margin-top: 5px;
  font-size: 13px;
`;
export const HeaderSubtitleLabel = styled.span``;
export const MenuContainer = styled.div`
  margin: 10px -16px 0 -16px;
`;
export const Menu = styled.ul`
  margin: 0;
  padding: 0;
  list-style: none;
`;
export const ActionsContainer = styled.div`
  margin: 14px -16px 0 -16px;
  overflow-x: auto;
  scrollbar-width: none;
  &::-webkit-scrollbar {
    display:none;
  }
`;
export const Actions = styled.ul`
  display: flex;
  margin: 0;
  padding: 0;
  list-style: none;
`;
export const ActionSpace = styled.li`
  width: 16px;
  min-width: 16px;
  height: auto;
`;
