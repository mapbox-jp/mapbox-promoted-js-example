import ReactDOM from 'react-dom';
import React, { useRef, useEffect, useState, useMemo } from 'react';
import { getImageUrl } from 'utils/urls';
import { isUrl } from 'utils/string';
import PromotionTag from 'atoms/PromotionTag';
import ActionItems from './ActionItems';
import MenuItems from './MenuItems';
import {
  Container,
  Wrapper,
  Banner,
  BannerImg,
  Content,
  Header,
  HeaderTitle,
  HeaderTitleLabel,
  HeaderPromotionTag,
  HeaderSubtitle,
  HeaderSubtitleLabel,
  ActionsContainer,
  Actions,
  ActionSpace,
  MenuContainer,
  Menu,
} from './styles';
import './styles.css';
import { CLICK_TYPES } from './helpers';

window.showPromotionPopup = (
  properties: Feature.Properties,
  onClick?: (type: PromotionPopup.ClickTypes, adid: string) => void,
  onClose?: (adid: string) => void
) => {
  const element = document.querySelector(`.mapbox-promoted-popup-content-adid__${properties.adid}`);
  if (!element) { return; }
  const content = element.querySelector('.mapbox-promoted-popup-content');
  !content && ReactDOM.render(
    <Popup
      properties={properties}
      onClick={onClick}
      onClose={onClose}
    />,
    element
  );
};

type Props = {
  properties: Feature.Properties;
  onClick?: (type: PromotionPopup.ClickTypes, adid: string) => void;
  onClose?: (adid: string) => void;
};

const Popup: React.FC<Props> = props => {
  const { properties, onClick, onClose } = props;
  const { adid, nameJa, subtitle, promotionBannerWidth, promotionBannerHeight } = properties;

  const ref = useRef<HTMLDivElement>(null);
  const [isFadeout, setIsFadeout] = useState(false);
  const [isRendered, setIsRendered] = useState(false);
  const promotionBanner = useMemo(() => {
    if (!properties.promotionBanner) { return ''; }
    return isUrl(properties.promotionBanner) ? properties.promotionBanner : getImageUrl(properties.promotionBanner);
  }, [])

  window.closePromotionPopup = () => {
    close();
  };

  const close = () => {
    setIsFadeout(true);
    setTimeout(() => {
      const popup = document.querySelector(`.mapbox-promoted-popup-adid__${adid}`);
      if (!popup || !popup.parentNode) { return; }
      popup.parentNode.removeChild(popup);
    }, 150);
    onClose && onClose(adid);
    removeEventListeners();
  };
  const removeEventListeners = () => {
    document.removeEventListener('click', handleClickOutside);
  };

  const handleClick = (type: PromotionPopup.ClickTypes) => {
    onClick && onClick(type, adid);
  };
  const handleClickOutside = (event: MouseEvent) => {
    if (ref.current && !ref.current.contains(event.target as Node)) {
      close();
    }
  };

  useEffect(() => {
    document.addEventListener('click', handleClickOutside);
    return () => removeEventListeners();
  }, []);
  useEffect(() => {
    if (ref.current) {
      const popupContent = document.querySelector(`.mapbox-promoted-popup-content-adid__${adid}`) as HTMLElement;
      if (popupContent) {
        popupContent.style.width = `${ref.current.clientWidth}px`;
        popupContent.style.height = `${ref.current.clientHeight}px`;
      }
      const popup = document.querySelector(`.mapbox-promoted-popup-adid__${adid}`) as HTMLElement;
      if (popup) {
        popup.style.width = `${ref.current.clientWidth}px`;
        popup.style.height = `${ref.current.clientHeight}px`;
      }
      setIsRendered(true);
    }
  }, [ref]);

  return (
    <Container
      className='promotion-popup'
      isFadeout={isFadeout}
      isRendered={isRendered}
      onClick={() => handleClick(CLICK_TYPES.POPUP)}
      ref={ref}
    >
      <Wrapper
        className='promotion-popup__content-wrapper'
        isRendered={isRendered}
      >
        <Banner
          className='promotion-popup__banner'
          onClick={() => handleClick(CLICK_TYPES.BANNER)}
        >
          <BannerImg
            className='promotion-popup__banner-img'
            src={promotionBanner}
            width={promotionBannerWidth || ''}
            height={promotionBannerHeight || ''}
          />
        </Banner>
        <Content className='promotion-popup__content'>
          <Header className='promotion-popup__header'>
            <HeaderTitle className='promotion-popup__header__title'>
              <HeaderTitleLabel className='promotion-popup__header__title-label'>
                {nameJa || ''}
              </HeaderTitleLabel>
              <HeaderPromotionTag className='promotion-popup__promotion-tag__wrapper'>
                <PromotionTag classPrefix='promotion-popup' />
              </HeaderPromotionTag>
            </HeaderTitle>
            {subtitle && (
              <HeaderSubtitle className='promotion-popup__header__subtitle'>
                <HeaderSubtitleLabel className='promotion-popup__header__subtitle-label'>
                  {subtitle}
                </HeaderSubtitleLabel>
              </HeaderSubtitle>
            )}
          </Header>
          {properties && (
            <MenuContainer className='promotion-popup__menus__container'>
              <Menu className='promotion-popup__menu'>
                <MenuItems properties={properties} onClick={handleClick} />
              </Menu>
            </MenuContainer>
          )}
          {properties && (
            <ActionsContainer className='promotion-popup__actions__container'>
              <Actions className='promotion-popup__actions'>
                <ActionSpace className='promotion-popup__actions__space' />
                <ActionItems properties={properties} onClick={handleClick} />
                <ActionSpace className='promotion-popup__actions__space' />
              </Actions>
            </ActionsContainer>
          )}
        </Content>
      </Wrapper>
    </Container>
  );
};

export default Popup;
