export const CLICK_TYPES = {
  POPUP: 'popup',
  BANNER: 'banner',
  PHONE: 'phone',
  DIRECTIONS: 'directions',
  DETAIL: 'detail',
} as const;
