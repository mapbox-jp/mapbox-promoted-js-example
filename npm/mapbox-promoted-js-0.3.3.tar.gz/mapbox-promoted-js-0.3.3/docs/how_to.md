# Web Promoted SDK 

## exampleプロジェクト

下記のリポジトリにexampleプロジェクトを用意しています。<br />
https://github.com/mapbox-jp/mapbox-promoted-js-example


1. Web Promoted SDKではと、二つのJavaScriptファイルで導入の手続きが必要になります
* プロモーションのロジックを担当する**lib/core/commonjs/index.js**の導入
* map上にプロモーションを描画するweb componentとなる**lib/app/es/index.js**の導入

### npmを利用した導入

#### core/commonjs/index.jsの導入

1. package.jsonに配布された**mapbox-promoted-js-VERSION.tar.gz**へのパスを追記する

```
"dependencies": {
  ...
  "mapbox-gl": "1.13.0",
  "mapbox-promoted-js": "file:FILE_PATH/mapbox-promoted-js-0.3.2.tar.gz",
  "@types/mapbox-promoted-js": "file:FILE_PATH/mapbox-promoted-js-0.3.2.tar.gz",
},
```

#### app/es/index.jsの導入

1. **mapbox-promoted-js-VERSION.tar.gz**を解凍し、**lib/app/es/index.js**をプロジェクト配下に配置する（下記の例では**mapbox-promoted-js/app.js**に配置）
2. htmlにscriptを埋め込む

```
<html lang='en'>
  <head>
    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link href='https://api.tiles.mapbox.com/mapbox-gl-js/v2.3.0/mapbox-gl.css' rel='stylesheet'/>
    <script src='/mapbox-promoted-js/app.js'></script>
    <title>
      <%= title %>
    </title>
  </head>
  <body>
    <div id='app'></div>
  </body>
</html>
```

### cdnを利用した導入

#### core/commonjs/index.jsとapp/es/index.jsの導入

1. **mapbox-promoted-js-VERSION.tar.gz**を解凍し、**lib/app/es/index.js**と**lib/core/browser/index.js**のそれぞれをプロジェクト配下に配置する（下記の例では**lib/app/es/index.js**は**mapbox-promoted-js/app.js**に、**lib/core/browser/index.js**は**mapbox-promoted-js/core.js**に配置）
2. htmlにscriptを埋め込む

```
<html lang='en'>
  <head>
    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link href='https://api.tiles.mapbox.com/mapbox-gl-js/v2.3.0/mapbox-gl.css' rel='stylesheet'/>
    <script src='/mapbox-promoted-js/app.js'></script>
    <script src='/mapbox-promoted-js/core.js'></script>
    <title>
      <%= title %>
    </title>
  </head>
  <body>
    <div id='app'></div>
  </body>
</html>
```


# Documentation on Specification / 仕様ドキュメント

## Hello World

### npmを利用した方法

以下のコードを導入する事により広告が自動で配信されます。
Mapbox Studioで作成したTokenをMapboxPromotedの初期化時に第二引数に設定してください。

```
import mapboxgl from 'mapbox-gl';
import { Promoted } from 'mapbox-promoted-js';

const token = 'xxxxxxxxxxxxxxxxxxxxxxxxxxx';
mapboxgl.accessToken = token;

const map = new MapboxGL.Map({
  container: 'app',
  style: 'mapbox://styles/mapbox/streets-v11',
  center: [139.7746987, 35.6272648],
  zoom: 13
});
const promoted = new Promoted(map, token);
```

### cdnを利用した方法
```
const token = 'xxxxxxxxxxxxxxxxxxxxxxxxxxx';
window.mapboxgl.accessToken = token;
const map = new window.mapboxgl.Map({
  container: 'app',
  style: 'mapbox://styles/mapbox/streets-v11',
  center: [139.7746987, 35.6272648],
  zoom: 13
});
const promoted = new window.PromotedCore.Promoted(map, token);
```


## Promotion Type / プロモーションタイプ

プロモーションピンのクリックにより表示できるプロモーションには3つのタイプが存在するため、パラメタによりこれらを切り替えることができます。
第三引数のoptionsに"enablePromotionCard: true"を設定すると画面下部に表示されるプロモーションカードを、"enablePromotionSideCard: true"を設定すると画面左サイドに表示されるプロモーションサイドメニューを表示します。
何も設定しない場合、クリックされたピン上部に表示されるプロモーションポップアップが表示されます。

```
const promoted = new MapboxPromoted(
  map,
  MAPBOX_TOKEN,
  {
    enablePromotionCard: true,
  }
);
```


## Mapbox Promoted API / メソッド

### Promotion Popup
```
// プロモーションポップアップを表示するメソッドです。
//（mapbox-promoted-js側で利用するためのメソッドになります）
window.showPromotionPopup(
  properties: Feature.Properties,
  onClick?: (type: PromotionPopup.ClickTypes, adid: string) => void,
  onClose?: (adid: string) => void
)

// プロモーションポップアップをクローズするメソッドです。
window.closePromotionPopup()
```

### Promotion SideCard
```
// プロモーションサイドメニューを表示するメソッドです。
window.showPromotionSideCard(
  properties: Feature.Properties,
  onClick?: (type: PromotionSideCard.ClickTypes, adid: string) => void,
  onClose?: (adid: string) => void
)

// プロモーションサイドメニューの表示内容を更新するメソッドです。
// ※このメソッドの実行にはプロモーションサイドメニューが表示されている状態である必要があります。
window.updatePromotionSideCard(properties: Feature.Properties) => void

// プロモーションサイドメニューを開くためのメソッドです。
// ※このメソッドの実行にはプロモーションサイドメニューが表示されている状態である必要があります。
window.openPromotionSideCard()

// プロモーションサイドメニューを非表示にし、開閉ボタンは画面左端に表示させたままになります。
window.hidePromotionSideCard()

// プロモーションサイドメニューをクローズするメソッドです。
window.closePromotionSideCard()
```

### Promotion Card
```
// プロモーションカードを表示するメソッドです。
window.showPromotionCard(
  properties: Feature.Properties,
  onClick?: (type: PromotionCard.ClickTypes, adid: string) => void,
  onClose?: (adid: string) => void
)

// プロモーションカードの表示内容を更新するメソッドです。
// ※このメソッドの実行にはプロモーションカードが表示されている状態である必要があります。
window.updatePromotionCard(properties: Feature.Properties) => void

// プロモーションカードをクローズするメソッドです。
window.closePromotionCard()
```


## Mapbox Promoted Event Callback API / コールバックメソッド

以下のコードを導入する事により各種コールバックイベントを発火させることができます。

```
promoted.on('load', (type: string, event: any) => console.log(type, event));
```

### Common Event

以下はイベントのタイプ、及びオブジェクトになります。

```
promoted.on('load', (type: string, event: {
  map: mapboxgl.Map
}) => void);

promoted.on('move', (type: string, event: {
  map: mapboxgl.Map,
  feature: Feature,
  originEvent: mapboxgl.MapboxEvent<any>.originalEvent
}) => void);

promoted.on('click_pin', (type: string, event: {
  map: mapboxgl.Map,
  features: Feature[],
  originEvent: mapboxgl.MapboxEvent<any>.originalEvent
}) => void);
```

### Promotion Popup Event

```
promoted.on('click_popup', (type: string, event: {
  clickType: 'popup' | 'banner' | 'phone' | 'directions' | 'detail',
  feature: Feature,
}) => void);
promoted.on('show_popup', event: { feature: Feature }) => void);
promoted.on('close_popup', event: { feature: Feature }) => void);
```

### Promotion SideCard Event

```
promoted.on('click_side_card', (type: string, event: {
  clickType: 'popup' | 'banner' | 'phone' | 'directions' | 'detail',
  feature: Feature,
}) => void);
promoted.on('show_side_card', event: { feature: Feature }) => void);
promoted.on('update_side_card', event: { feature: Feature }) => void);
promoted.on('open_side_card', event: { feature: Feature }) => void);
promoted.on('hide_side_card', event: { feature: Feature }) => void);
promoted.on('close_side_card', event: { feature: Feature }) => void);
```

### Promotion Card Event

```
promoted.on('click_card', (type: string, event: {
  clickType: 'popup' | 'banner' | 'phone' | 'directions' | 'detail',
  feature: Feature,
}) => void);
promoted.on('show_card', event: { feature: Feature }) => void);
promoted.on('update_card', event: { feature: Feature }) => void);
promoted.on('close_card', event: { feature: Feature }) => void);
```


## デバッグモードで実行

デバッグモードで実行することで、プロモーションのクリックやピンの表示によるイベントログを発火を防ぎます。
本番環境以外の環境では"debug: true"を追記するようにしてください。

```
const promoted = new MapboxPromoted(
  map,
  MAPBOX_TOKEN,
  {
    debug: true,
  }
);
```


## テスト環境に接続

以下のコードを導入する事により環境を変更することができます。
各種パラメタについては配布されたものを利用してください。

```
const promoted = new MapboxPromoted(
  map,
  MAPBOX_TOKEN,
  {
    baseUrl: MAPBOX_BASE_URL,
    sourceUrl: MAPBOX_SOURCE_URL,
    telemetryUrl: MAPBOX_TELEMETRY_URL,
    layerSourceId: MAPBOX_LAYER_SOURCE_ID,
  }
);
```
