module.exports = {
  clearMocks: true,
  collectCoverage: false,
  errorOnDeprecated: false,
  globals: {
    'ts-jest': {
      tsConfig: 'tsconfig.json'
    }
  },
  moduleFileExtensions: [
    'js',
    'jsx',
    'ts',
    'tsx',
    'json',
    'node'
  ],
  moduleNameMapper: {
    '^apis/(.+)': '<rootDir>/src/apis/$1',
    '^app/(.+)': '<rootDir>/src/app/$1',
    '^atoms/(.+)': '<rootDir>/src/app/atoms/$1',
    '^assets/(.+)': '<rootDir>/src/assets/$1',
    '^core/(.+)': '<rootDir>/src/core/$1',
    '^src/(.+)': '<rootDir>/src/$1',
    '^mock/(.+)': '<rootDir>/src/__tests__/mock/$1',
    '^utils/(.+)': '<rootDir>/src/utils/$1'
  },
  preset: 'ts-jest',
  roots: [
    '<rootDir>'
  ],
  testEnvironment: 'jsdom',
  testMatch: [
    '**/__tests__/**/*.spec.+(ts|tsx)',
  ],
  testPathIgnorePatterns: [
    '/node_modules/',
    '/example/'
  ],
  transform: {
    '^.+\\.(ts|tsx)$': 'babel-jest',
  }
};
