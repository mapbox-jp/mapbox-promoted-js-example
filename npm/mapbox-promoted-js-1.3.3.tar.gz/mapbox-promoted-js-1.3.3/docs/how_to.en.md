# Mapbox Promoted JS

## Usage
The Promoted SDK supports both NPM and CDN versions. We will explain how to integrate and implement each version.

### NPM Version Integration
#### Package Installation
Place the distributed package `mapbox-promoted-js-VERSION.tar.gz` in the appropriate path, add it to the package.json, and then install with npm install.

```bash
"dependencies": {
  "mapbox-gl": "2.12.1",
  "mapbox-promoted-js": "file:FILE_PATH/mapbox-promoted-js-1.3.3.tar.gz",
  ...
},
"devDependencies": {
  "@types/mapbox-promoted-js": "file:FILE_PATH/mapbox-promoted-js-1.3.3.tar.gz",
  ...
}
```

#### Implementing the Promoted SDK
When creating a Promoted instance, specify the mapboxgl.Map instance and other necessary information.
Just this will display ads on the map.

```bash
import mapboxgl from 'mapbox-gl';
import Promoted from 'mapbox-promoted-js';

const map = new mapboxgl.Map({
  container: document.querySelector('#map'),
  style: 'mapbox://styles/mapbox/streets-v11',
  center: [139.7671687688049, 35.68116566710953],
  zoom: 15,
});
const promoted = new Promoted({
  map,
  accessToken: 'xxxxxxxxxxxxxx',
  container: document.querySelector('#map'),
  baseUrl: 'https://xxxxx.xxxx.info',
  logUrl: 'https://xxxxx.xxxx.info',
});
```

* After obtaining the accessToken from Mapbox Studio, you need to register it with the ad delivery server. Please contact the person in charge for assistance.
* baseUrl and logUrl are separated for production, staging, and development environments.
* Please inquire with the person in charge for the necessary environment URLs.

### CDN Version Integration
#### Embedding the Script
Extract `mapbox-promoted-js-VERSION.tar.gz` and place `lib/browser/index.js` under the project directory.
Then embed it on HTML using a <script /> tag.

```bash
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <script src="./static/js/index.js"></script>
</head>
```

#### Implementing the Promoted SDK
Like the NPM version, specify the mapboxgl.Map instance and other necessary information when creating a Promoted instance.

```bash
const map = new mapboxgl.Map({
  container: document.querySelector('#map'),
  style: 'mapbox://styles/mapbox/streets-v11',
  center: [139.7671687688049, 35.68116566710953],
  zoom: 15,
});
const promoted = new Promoted({
  map,
  accessToken: 'xxxxxxxxxxxxxx',
  container: ref.current as any,
  baseUrl: 'https://xxxxx.xxxx.info',
  logUrl: 'https://xxxxx.xxxx.info',
});
```

* After obtaining the accessToken from Mapbox Studio, you need to register it with the ad delivery server. Please contact the person in charge for assistance.
* baseUrl and logUrl are separated for production, staging, and development environments.
* Please inquire with the person in charge for the necessary environment URLs.

## Implementation
### Callbacks, Ad Card Embedding, and Rendering
Ad card embedding requires an implementation triggered by clicking on an ad pin.

```bash
promoted.on('click_pin', (_type: any, event: any) => {
  const feature = (event.data as any).features[0] as Feature;
  const targetElement = document.querySelector('#target');
  if (!targetElement) { return; }
  promoted.render(
    targetElement as HTMLElement,
    feature,
    (type: string, feature: Feature, profileItems?: Feature.ProfileItems) => {
      console.log('onclcik', type, feature, profileItems);
    },
  );
});
```

### Options
There are options to control the operation of the Promoted SDK. For example, the base color of ad cards, icon size, debug mode, and more.

baseColor: Select the base color for the ad cards.
scaleIcon: Choose the ad icon size from 1, 2, or 3. The default is 1.
mediaModal: When set to true, a modal view will be displayed when selecting a photo from the photo list on the MBP card.
clickMode: Specify either 'click' or 'touch' for the Mapbox Map SDK click event. The default is 'click'.
debug: When set to true, debug mode is enabled. Running in debug mode will stop the event log from being sent.

```bash
const promoted = new Promoted({
  map,
  accessToken: 'xxxxxxxxxxxxxx',
  container: document.querySelector('#map'),
  baseUrl: 'https://xxxxx.xxxx.info',
  logUrl: 'https://xxxxx.xxxx.info',
  baseColor: '#1a75ff',
  scaleIcon: 1,
  mediaModal: false,
  debug: true,
});
```

## Callbacks
There are types and return values for callback events, such as map loading completion, zoom end, pin click, and more.

```
promoted.on('load', (type: string, event: {
  map: mapboxgl.Map
}) => void);

promoted.on('moveend', (type: string, event: {
  map: mapboxgl.Map,
  originEvent: mapboxgl.MapboxEvent<any>.originalEvent
}) => void);

promoted.on('zoomend', (type: string, event: {
  map: mapboxgl.Map,
  originEvent: mapboxgl.MapboxEvent<any>.originalEvent
}) => void);

promoted.on('sourcedata', (type: string, event: {
  map: mapboxgl.Map,
  originEvent: mapboxgl.MapboxEvent<any>.originalEvent
  tiles: Tile[]
}) => void);

promoted.on('sourcedataend', (type: string, event: {
  map: mapboxgl.Map,
  originEvent: mapboxgl.MapboxEvent<any>.originalEvent
  visibledFeatures: Feature[],
  unvisibledFeatures: Feature[]
}) => void);

promoted.on('click_pin', (type: string, event: {
  map: mapboxgl.Map,
  originEvent: mapboxgl.MapboxEvent<any>.originalEvent
  feature: Feature
}) => void);

promoted.on('start_session', (type: string, event: {
  start: Date
}) => void);

promoted.on('update_session', (type: string, event: {
  start: Date
}) => void);

promoted.on('end_session', (type: string, event: {
  start: Date
}) => void);

promoted.on('click_side_card', (type: string, event: {
  start: Date
}) => void);

promoted.on('close_side_card', (type: string, event: {
  start: Date
}) => void);
```
