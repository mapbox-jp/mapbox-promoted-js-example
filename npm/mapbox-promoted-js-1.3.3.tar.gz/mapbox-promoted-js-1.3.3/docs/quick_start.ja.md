# Mapbox Promoted JS

## インストール
開発に必要なライブラリをインストールするには、以下のコマンドを実行してください。

```bash
npm install
```

## ビルドコマンド
プロジェクトのファイルをビルドするには、以下のコマンドを実行してください。

```bash
npm run build
```

## ビルドファイル
ビルドコマンドを実行すると、NPM用のファイルとCDN用のファイルが生成されます。

NPM用のビルドファイル: `lib/commonjs/index.js`
CDN用のビルドファイル: `lib/browser/index.js`

## 型定義ファイル
型定義ファイルは、JavaScriptライブラリの型情報を提供します。ソースコードを変更する場合は、この型定義ファイルも適切に修正してください。

型定義ファイルのパス: `lib/commonjs/index.d.ts`

## パッケージ化
tar.gz形式のパッケージを作成するには、以下のスクリプトを実行し、末尾にバージョン情報を指定してください。

```bash
scripts/generate_package.sh バージョン
例)
scripts/generate_package.sh 1.0.0
```

## テスト
全単体テストを実行するには、以下のコマンドを実行してください。

```bash
jest --config ./jest.config.js
```

特定の単体テストを実行するには、以下のコマンドを実行し、テストファイル名を指定してください。

```bash
jest --config ./jest.config.js src/__tests__/utils/businessHours.spec.ts
```
