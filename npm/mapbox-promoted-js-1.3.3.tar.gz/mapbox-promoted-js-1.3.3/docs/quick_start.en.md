# Mapbox Promoted JS

## Install
To install the necessary libraries for development, run the following command:

```bash
npm install
```

## Build
To build the project files, run the following command:

```bash
npm run build
```

## Build Files
Executing the build command will generate files for both NPM and CDN usage.

NPM build file: `lib/commonjs/index.js`
CDN build file: `lib/browser/index.js`

## Type Definition File
The type definition file provides type information for the JavaScript library. If you modify the source code, make sure to update this type definition file accordingly.

Type definition file path: `lib/commonjs/index.d.ts`

## Package Creation
To create a package in tar.gz format, run the following script and specify the version information at the end:

```bash
scripts/generate_package.sh VERSION
Ex)
scripts/generate_package.sh 1.0.0
```

## Testing
To run all unit tests, execute the following command:

```bash
jest --config ./jest.config.js
```

To run a specific unit test, execute the following command and specify the test file name:

```bash
jest --config ./jest.config.js src/__tests__/utils/businessHours.spec.ts
```
