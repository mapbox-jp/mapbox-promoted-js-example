# Mapbox Promoted JS

## 導入方法
Promoted SDKはNPM版とCDN版の両方に対応しています。
それぞれの導入方法と実装方法を説明します。

### NPM版の導入
#### パッケージのインストール
配布されたパッケージ mapbox-promoted-js-VERSION.tar.gz を適切なパスに配置し、package.jsonに追記してから、npm installでインストールを行います。

```bash
"dependencies": {
  "mapbox-gl": "2.12.1",
  "mapbox-promoted-js": "file:FILE_PATH/mapbox-promoted-js-1.3.3.tar.gz",
  ...
},
"devDependencies": {
  "@types/mapbox-promoted-js": "file:FILE_PATH/mapbox-promoted-js-1.3.3.tar.gz",
  ...
}
```

#### Promoted SDKを使った実装
Promotedインスタンス生成時に、mapboxgl.Mapインスタンスやその他必要な情報を指定します。
下記のコードのみで広告がマップ上に表示されます。

```bash
import mapboxgl from 'mapbox-gl';
import Promoted from 'mapbox-promoted-js';

const map = new mapboxgl.Map({
  container: document.querySelector('#map'),
  style: 'mapbox://styles/mapbox/streets-v11',
  center: [139.7671687688049, 35.68116566710953],
  zoom: 15,
});
const promoted = new Promoted({
  map,
  accessToken: 'xxxxxxxxxxxxxx',
  container: document.querySelector('#map'),
  baseUrl: 'https://xxxxx.xxxx.info',
  logUrl: 'https://xxxxx.xxxx.info',
});
```

* accessTokenはMapboxStudioで発行した後、広告配信サーバに登録する必要があるため担当者にお問合せください
* baseUrlとlogURLは本番、ステージング、開発環境用に分かれています
* 必要な環境のurlを担当者にお問合せください

### CDN版の導入
#### スクリプトの埋め込み
`mapbox-promoted-js-VERSION.tar.gz`を解凍し、`lib/browser/index.js`をプロジェクト配下に配置し（下記の例では`static/js/index.js`に配置）、HTML上で<script />タグで埋め込みを行います。

```bash
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <script src="./static/js/index.js"></script>
</head>
```

#### Promoted SDKを使った実装
NPM版と同様に、Promotedインスタンス生成時にmapboxgl.Mapインスタンスやその他必要な情報を指定します。

```bash
const map = new mapboxgl.Map({
  container: document.querySelector('#map'),
  style: 'mapbox://styles/mapbox/streets-v11',
  center: [139.7671687688049, 35.68116566710953],
  zoom: 15,
});
const promoted = new Promoted({
  map,
  accessToken: 'xxxxxxxxxxxxxx',
  container: ref.current as any,
  baseUrl: 'https://xxxxx.xxxx.info',
  logUrl: 'https://xxxxx.xxxx.info',
});
```

* accessTokenはMapboxStudioで発行した後、広告配信サーバに登録する必要があるため担当者にお問合せください
* baseUrlとlogURLは本番、ステージング、開発環境用に分かれています
* 必要な環境のurlを担当者にお問合せください

## 実装方法
### コールバックと広告カードの埋め込みと描画
広告カードの埋め込みは広告ピンのクリックをトリガーとした実装が必要です。

```bash
promoted.on('click_pin', (_type: any, event: any) => {
  const feature = (event.data as any).features[0] as Feature;
  const targetElement = document.querySelector('#target');
  if (!targetElement) { return; }
  promoted.render(
    targetElement as HTMLElement,
    feature,
    (type: string, feature: Feature, profileItems?: Feature.ProfileItems) => {
      console.log('onclcik', type, feature, profileItems);
    },
  );
});
```

### オプション
Promoted SDKの動作を制御するオプションがあります。例えば、広告カードのベースカラーやアイコンのサイズ、デバッグモードなど。

baseColor: 広告カードのベースカラーを選択します
scaleIcon: 広告アイコンのサイズ1,2,3のいずれかから選択します。デフォルトでは1になります。
mediaModal: trueのときにはMBPカードで写真一覧から写真を選択したときに、モーダルビューを表示します。
clickMode: Mapbox Map SDKのクリックイベントを'click'と'touch'いずれかを指定します。デフォルトでは'click'になります。
debug: trueのときにDEBUGモードを有効化します。デバッグモードで実行することで、イベントログの転送を停止します。

```bash
const promoted = new Promoted({
  map,
  accessToken: 'xxxxxxxxxxxxxx',
  container: document.querySelector('#map'),
  baseUrl: 'https://xxxxx.xxxx.info',
  logUrl: 'https://xxxxx.xxxx.info',
  baseColor: '#1a75ff',
  scaleIcon: 1,
  mediaModal: false,
  debug: true,
});
```

## 各種コールバックについて
コールバックイベントのタイプと戻り値があります。例えば、マップの読み込み完了、ズーム終了、ピンのクリックなど。

```
promoted.on('load', (type: string, event: {
  map: mapboxgl.Map
}) => void);

promoted.on('moveend', (type: string, event: {
  map: mapboxgl.Map,
  originEvent: mapboxgl.MapboxEvent<any>.originalEvent
}) => void);

promoted.on('zoomend', (type: string, event: {
  map: mapboxgl.Map,
  originEvent: mapboxgl.MapboxEvent<any>.originalEvent
}) => void);

promoted.on('sourcedata', (type: string, event: {
  map: mapboxgl.Map,
  originEvent: mapboxgl.MapboxEvent<any>.originalEvent
  tiles: Tile[]
}) => void);

promoted.on('sourcedataend', (type: string, event: {
  map: mapboxgl.Map,
  originEvent: mapboxgl.MapboxEvent<any>.originalEvent
  visibledFeatures: Feature[],
  unvisibledFeatures: Feature[]
}) => void);

promoted.on('click_pin', (type: string, event: {
  map: mapboxgl.Map,
  originEvent: mapboxgl.MapboxEvent<any>.originalEvent
  feature: Feature
}) => void);

promoted.on('start_session', (type: string, event: {
  start: Date
}) => void);

promoted.on('update_session', (type: string, event: {
  start: Date
}) => void);

promoted.on('end_session', (type: string, event: {
  start: Date
}) => void);

promoted.on('click_side_card', (type: string, event: {
  start: Date
}) => void);

promoted.on('close_side_card', (type: string, event: {
  start: Date
}) => void);
```