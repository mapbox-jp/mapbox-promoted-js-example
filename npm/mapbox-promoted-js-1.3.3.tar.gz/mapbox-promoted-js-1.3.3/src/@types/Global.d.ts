type Config = {
  BASE_URL: string;
  LOG_URL: string;
  ACCESS_TOKEN: string;
  MEDIA_ID?: string;
  SESSION_ID?: string;
  BASE_COLOR: string;
  MEDIA_MODAL?: boolean;
  DEBUG?: boolean;
};
declare var updateConfig: (config: Config) => void;
