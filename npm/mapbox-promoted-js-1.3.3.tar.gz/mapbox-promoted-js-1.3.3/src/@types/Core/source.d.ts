declare namespace Promoted {
  class Source {
    constructor(map: mapboxgl.Map, token: string);
    get tilesets(): { [quadkey: string]: Feature[] };
    get features(): Feature[];
    public convertToFeaturesMap(features: Feature[]): { [key: string]: Feature };
    public addSource(quadkeys: string[]): void;
    public updateFeatureVisibles(): {
      visibledFeatures: Feature[];
      unvisibledFeatures: Feature[];
    };
    public reload(): void;
    public reset(): void;
  }
}
