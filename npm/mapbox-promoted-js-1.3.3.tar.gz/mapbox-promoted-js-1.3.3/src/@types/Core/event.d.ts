declare namespace Promoted {
  namespace Event {
    type Listener = (type: EventTypes, event: Promoted.EventData) => any;
    type Listeners = { [key: string]: Array<Listener> };
  }

  const EVENT_TYPES: {
    readonly LOAD: 'load';
    readonly MOVEEND: 'moveend';
    readonly ZOOMEND: 'zoomend';
    readonly SOURCEDATA: 'sourcedata';
    readonly SOURCEDATAEND: 'sourcedataend';
    readonly CLICK_PIN: 'click_pin';

    readonly START_SESSION: 'start_session';
    readonly UPDATE_SESSION: 'update_session';
    readonly END_SESSION: 'end_session';
  
    readonly CLICK_SIDE_CARD: 'click_side_card';
    readonly CLOSE_SIDE_CARD: 'close_side_card';
  };
  type EventTypes = typeof EVENT_TYPES[keyof typeof EVENT_TYPES];

  class Event {
    public on(type: EventTypes, listener: Event.Listener): void;
    public off(type: EventTypes, listener: Event.Listener): void;
    public fire(event: EventData): void;
  }  
}
