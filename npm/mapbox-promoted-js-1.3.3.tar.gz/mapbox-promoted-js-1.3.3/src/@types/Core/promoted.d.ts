declare namespace Promoted {
  namespace Core {
    type Options = {
      map: PromotedPlugin.Plugin | mapboxgl.Map;
      accessToken: string;
      mediaId?: string;
      container: HTMLElement | string;
      baseUrl?: string;
      logUrl?: string;
      baseColor?: string;
      scaleIcon?: number;
      sideCard?: boolean;
      mediaModal?: boolean;
      debug?: boolean;
      clickMode?: PromotedPlugin.ClickMode;
    };
  }
  class Core implements Promoted.Event {
    constructor(map: mapboxgl.Map, token: string, options?: Promoted.Core.Options);
    get map(): any;
    get plugin(): PromotedPlugin.Plugin;
    get tilesets(): { [quadkey: string]: Feature[] };
    get features(): Feature[];
    get promotionSideCard(): PromotionSideCard;
    get enableSideCard(): boolean;

    public visibleLayer(): void;
    public hideLayer(): void;
    public selectFeature(feature: Feature): void;
    public deselectLayer(): void;
    public reload(): void;
    public sendAction(feature: Feature, clickType: Promotion.ClickTypes): void;
    public render(container: string | HTMLElement, feature: Feature): void;

    // Promoted.Event
    public on(type: Promoted.EventTypes, listener: Promoted.Event.Listener): void;
    public off(type: Promoted.EventTypes, listener: Promoted.Event.Listener): void;
    public fire(event: Promoted.EventData): void;
  }
}
