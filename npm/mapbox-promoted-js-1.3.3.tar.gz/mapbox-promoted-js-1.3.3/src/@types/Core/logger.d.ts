declare namespace Promoted {
  namespace Logger {
    const ACTION_TYPES: {
      readonly BANNER: 'BannerDetail';
      readonly CALL: 'Call';
      readonly NAVIGATION: 'Navigation';
      readonly LINE: 'Line';
      readonly INSTAGRAM: 'Instagram';
      readonly FACEBOOK: 'Facebook';
      readonly TWITTER: 'Twitter';
      readonly APP_STORE: 'Twitter';
      readonly PLAY_STORE: 'Twitter';
      readonly DETAIL: 'Detail';
      readonly NEWS: 'News';
      readonly PRODUCT: 'Product';
      readonly MEDIA: 'Media';
    };
    export type ActionTypes = typeof ACTION_TYPES[keyof typeof ACTION_TYPES];
    const FEEDBACK_TYPES: {
      readonly ATTRIBUTION: 'attribution';
      readonly QUOTE: 'quote';
    };
    export type FeedbackTypes = typeof FEEDBACK_TYPES[keyof typeof FEEDBACK_TYPES];

    type Session = {
      session_id: string;
      created?: string | number;
    };
    type Visible = {
      session_id: string;
      auction_id: string;
      cps: string;
      start_action_type?: string;
      end_action_type?: string;
      start_zoom_level?: number;
      end_zoom_level?: number;
      visible_start_time?: number;
      visible_end_time?: number;
      created?: string | number;
    };
    type Select = {
      session_id: string;
      auction_id: string;
      cps: string;
      zoom_level: number;
      promotion_type: string;
      created?: string | number;
    };
    type Deselect = {
      session_id: string;
      auction_id: string;
      cps: string;
      zoom_level: number;
      created?: string | number;
    };
    type CallToAction = {
      session_id: string;
      auction_id: string;
      cps: string;
      zoom_level: number;
      type: Promoted.Logger.ActionTypes;
      created?: string | number;
    };
    type Feedback = {
      session_id: string;
      auction_id: string;
      cps: string;
      zoom_level: number;
      type: Promoted.Logger.FeedbackTypes;
      action: Promoted.Logger.FeedbackTypes;
      description?: string;
      created?: string | number;
    };
    type Log = {
      session_id?: string;
      auction_id?: string;
      cps?: string;
      type: string;
      description?: string;
      created?: string | number;
    };
  }

  class Logger {
    constructor(session: Promoted.Session);
    public startObserving(): void;
    public stopObserving(): void;
    public session(sessionId: string): void;
    public visibles(sessionId: string, featureLogs: FeatureLog[]): void;
    public select(
      sessionId: string,
      feature: Feature,
      zoomLevel: number,
    ): void;
    public deselect(
      sessionId: string,
      feature: Feature,
      zoomLevel: number
    ): void;
    public callToAction(
      sessionId: string,
      feature: Feature,
      zoomLevel: number,
      type: Promoted.Logger.ActionTypes,
    ): void;
    public feedback(
      sessionId: string,
      feature: Feature,
      zoomLevel: number,
      type: Promoted.Logger.FeedbackTypes,
    ): void;
    public log(
      type: string,
      description: string,
      sessionId?: string,
      feature?: Feature,
    ): void;
  }
}
