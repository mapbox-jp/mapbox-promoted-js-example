declare namespace Promoted {
  class Session implements Promoted.Session.Event {
    constructor(logger: Promoted.Logger);
    get startDate(): Date;
    get sessionId(): string;
    public start(): void;
    public update(): void;

    // Promoted.Session.Event
    public on(type: Promoted.Session.EventTypes, listener: Promoted.Session.Event.Listener): void;
    public off(type: Promoted.Session.EventTypes, listener: Promoted.Session.Event.Listener): void;
    public fire(event: Promoted.EventData): void;
  }
}
