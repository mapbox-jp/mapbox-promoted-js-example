declare namespace Promoted {
  class PromotionSideCard {
    constructor(promoted: Promoted.Core, source: Promoted.Source);
    get feature(): Feature | undefined;
    public render(
      container: string | HTMLElement,
      feature: Feature,
      onClick?: (type: Promotion.ClickTypes, feature: Feature, profileItems?: Feature.ProfileItems) => void,
      onUpdate?: (feature: Feature) => void,
      onClose?: (feature: Feature) => void,
    ): void;
    public remove(container: string | HTMLElement): void;
  }
}
