export const isUrl = (string: string): boolean => !!string.match(/https?:\/\//);
