import ajax from './ajax';
import { CONFIG } from 'utils/config';

class LoggerAPI {
  private _ajax;

  constructor() {
    const headers = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${CONFIG.ACCESS_TOKEN}`,
    };
    this._ajax = new ajax(CONFIG.LOG_URL, { headers });
  }

  public sessions(sessions: Promoted.Logger.Session[]): Promise<{}> {
    return new Promise((resolve, reject) => {
      return this._ajax
        .post(`/out/v1/sessions${CONFIG.MEDIA_ID ? `?media_id=${CONFIG.MEDIA_ID}` : ''}`, sessions)
        .then((response: any) => {
          resolve(response[0]);
        }).catch((error: Error) => {
          reject(error);
        });
    });
  }

  public visibles(visibles: Promoted.Logger.Visible[]): Promise<{}> {
    return new Promise((resolve, reject) => {
      return this._ajax
        .post(`/out/v1/loc/visibles${CONFIG.MEDIA_ID ? `?media_id=${CONFIG.MEDIA_ID}` : ''}`, visibles)
        .then((response: any) => {
          resolve(response[0]);
        }).catch((error: Error) => {
          reject(error);
        });
    });
  }

  public selects(selects: Promoted.Logger.Select[]): Promise<{}> {
    return new Promise((resolve, reject) => {
      return this._ajax
        .post(`/out/v1/loc/selects${CONFIG.MEDIA_ID ? `?media_id=${CONFIG.MEDIA_ID}` : ''}`, selects)
        .then((response: any) => {
          resolve(response[0]);
        }).catch((error: Error) => {
          reject(error);
        });
    });
  }

  public deselects(deselects: Promoted.Logger.Deselect[]): Promise<{}> {
    return new Promise((resolve, reject) => {
      return this._ajax
        .post(`/out/v1/loc/deselects${CONFIG.MEDIA_ID ? `?media_id=${CONFIG.MEDIA_ID}` : ''}`, deselects)
        .then((response: any) => {
          resolve(response[0]);
        }).catch((error: Error) => {
          reject(error);
        });
    });
  }

  public callToAction(callToActions: Promoted.Logger.CallToAction[]): Promise<{}> {
    return new Promise((resolve, reject) => {
      return this._ajax
        .post(`/out/v1/loc/calltoactions${CONFIG.MEDIA_ID ? `?media_id=${CONFIG.MEDIA_ID}` : ''}`, callToActions)
        .then((response: any) => {
          resolve(response[0]);
        }).catch((error: Error) => {
          reject(error);
        });
    });
  }

  public feedbacks(feedbacks: Promoted.Logger.Feedback[]): Promise<{}> {
    return new Promise((resolve, reject) => {
      return this._ajax
        .post(`/out/v1/loc/feedbacks${CONFIG.MEDIA_ID ? `?media_id=${CONFIG.MEDIA_ID}` : ''}`, feedbacks)
        .then((response: any) => {
          resolve(response[0]);
        }).catch((error: Error) => {
          reject(error);
        });
    });
  }

  public logs(logs: Promoted.Logger.Log[]): Promise<{}> {
    return new Promise((resolve, reject) => {
      return this._ajax
        .post('/out/v1/loc/logs', logs)
        .then((response: any) => {
          resolve(response[0]);
        }).catch((error: Error) => {
          reject(error);
        });
    });
  }
};

export default LoggerAPI;
