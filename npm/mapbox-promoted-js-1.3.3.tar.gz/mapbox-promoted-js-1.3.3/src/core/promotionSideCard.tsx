import React from 'react';
import ReactDOM from 'react-dom';
import Card from 'organisms/Card';
import EventData from './eventData';
import { EVENT_TYPES } from './helpers';

class PromotionSideCard implements Promoted.PromotionSideCard {
  private _promoted: Promoted.Core;
  private _session: Promoted.Session;
  private _logger: Promoted.Logger;
  private _feature: Feature | undefined;

  constructor(promoted: Promoted.Core, session: Promoted.Session, logger: Promoted.Logger) {
    this._promoted = promoted;
    this._session = session;
    this._logger = logger;
  }

  get feature() {
    return this._feature;
  }

  private clickEvent(clickType: Promotion.ClickTypes, feature: Feature, profileItems?: Feature.ProfileItems) {
    let eventData: any = {
      clickType,
      feature,
    };
    if (profileItems && profileItems.news) {
      eventData['news'] = profileItems.news;
    }
    if (profileItems && profileItems.product) {
      eventData['product'] = profileItems.product;
    }
    if (profileItems && profileItems.media) {
      eventData['media'] = profileItems.media;
    }
    this._promoted.fire(new EventData(EVENT_TYPES.CLICK_SIDE_CARD, eventData));
    this._promoted.sendAction(feature, clickType);
    this._session.update();
  }

  private updateEvent(feature: Feature) {
    this._promoted.fire(new EventData(
      EVENT_TYPES.CLOSE_SIDE_CARD, {
        feature 
      }
    ));
    this._promoted.plugin.selectFeature(feature);
    this._logger.select(
      this._session.sessionId,
      feature,
      Math.floor(this._promoted.plugin.zoomLevel)
    );
  }

  private closeEvent(feature: Feature) {
    this._promoted.fire(new EventData(
      EVENT_TYPES.CLOSE_SIDE_CARD, {
        feature
      }
    ));
    this._promoted.plugin.deselectLayer();
    this._logger.deselect(
      this._session.sessionId,
      feature,
      Math.floor(this._promoted.plugin.zoomLevel)
    );
  }

  public render(
    container: string | HTMLElement,
    feature: Feature,
    onClick?: (type: Promotion.ClickTypes, feature: Feature, profileItems?: Feature.ProfileItems) => void,
    onUpdate?: (feature: Feature) => void,
    onClose?: (feature: Feature) => void,
  ) {
    const containerElement = typeof container === 'string' ? document.querySelector(container) as HTMLElement : container;
    containerElement && ReactDOM.render(
      <Card
        feature={feature}
        onClick={(clickType: Promotion.ClickTypes, profileItems?: Feature.ProfileItems) => {
          onClick && onClick(clickType, feature, profileItems);
          this.clickEvent(clickType, feature, profileItems);
        }}
        onUpdate={(targetFeature: Feature) => {
          onUpdate && onUpdate(targetFeature);
          this.updateEvent(targetFeature);
        }}
        onClose={(targetFeature: Feature) => {
          onClose && onClose(targetFeature);
          this.closeEvent(targetFeature);
        }}
      />,
      containerElement
    );
  }

  public remove(container: string | HTMLElement) {
    const containerElement = typeof container === 'string' ? document.querySelector(container) : container;
    containerElement && ReactDOM.unmountComponentAtNode(containerElement);
  }
}

export default PromotionSideCard;
