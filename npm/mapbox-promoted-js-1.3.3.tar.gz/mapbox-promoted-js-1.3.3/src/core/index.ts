import Promoted from './promoted';

export default Promoted;
