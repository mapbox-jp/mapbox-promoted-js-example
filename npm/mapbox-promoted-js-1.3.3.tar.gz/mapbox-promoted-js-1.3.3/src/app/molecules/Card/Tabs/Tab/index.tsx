import React from 'react';
import { Container } from './styles';

type Props = {
  classPrefix: string;
  label?: string;
  isSelected?: boolean;
  onClick: () => void;
};

const Tab: React.FC<Props> = props => {
  const { classPrefix, label, isSelected, onClick } = props;
  const handleClick = () => onClick();
  return (
    <Container
      className={`${classPrefix}__tabs-item ${isSelected ? `${classPrefix}__tabs-item__selected` : ''}`}
      isSelected={isSelected}
      onClick={handleClick}
    >
      {label}
    </Container>
  );
};

export default Tab;