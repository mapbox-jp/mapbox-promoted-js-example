import styled from 'styled-components';

export const Container = styled.ul`
  position: relative;
  display: flex;
  flex-shrink: 0;
  width: 100%;
  background-color: #ffffff;
  list-style: none;
  z-index: 3;
  &:before {
    content: "";
    position: absolute;
    display: block;
    bottom: 0px;
    width: 100%;
    border-top: 2px solid #f4f4f5;
  }
`;
