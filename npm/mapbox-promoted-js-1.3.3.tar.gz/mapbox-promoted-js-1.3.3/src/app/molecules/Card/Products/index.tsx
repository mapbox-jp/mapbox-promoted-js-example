import React, { useContext, useEffect, useRef, useMemo, useState } from 'react';
import { ProfileContext } from 'molecules/Card/hooks';
// Components
import ScrollButton from 'atoms/ScrollButton';
import Categories from './Categories';
import Item from './Item';
import {
  Container,
  Items,
  ScrollButtonLeft,
  ScrollButtonRight,
  EmptyColumn,
} from './styles';

type Props = {
  classPrefix?: string;
  selectedProduct?: Feature.Profile.Product;
  isHorizontal?: boolean;
  onClick?: (product: Feature.Profile.Product) => void;
};

const PRODUCTS_ITEM_WIDTH = 253;

const Products: React.FC<Props> = props => {
  const { classPrefix, selectedProduct, isHorizontal, onClick } = props;
  const {
    productCategories,
    products,
    productCategoryId,
    productIsLasted,
    readmoreProducts
  } = useContext(ProfileContext);
  const PREFIX_CLASSNAME = `${classPrefix}-products`;

  const ref = useRef<HTMLDivElement>(null);
  const productsRef = useRef<HTMLUListElement>(null);
  const itemRef = useRef<HTMLLIElement>(null);
  const [isHovering, setIsHovering] = useState(false);
  const [_, setDate] = useState<Date>();
  const producstWidth = useMemo(
    () => productsRef.current && productsRef.current.scrollWidth - productsRef.current.clientWidth || 0,
    [productsRef.current, productsRef.current && productsRef.current.scrollWidth]
  );
  const itemWidth = useMemo(
    () => itemRef.current && itemRef.current.clientWidth || PRODUCTS_ITEM_WIDTH,
    [itemRef.current]
  );

  const handleReadMore = () => readmoreProducts(productCategoryId);
  const handleMouseEnter = () => setIsHovering(true);
  const handleMouseLeave = () => setIsHovering(false);
  const handleScroll = () => setDate(new Date());
  const handleScrollByButtons = (left: boolean = false) => {
    if (!productsRef.current) { return; }
    productsRef.current.scroll({
      left: productsRef.current.scrollLeft + (
        left ? -1 * itemWidth : itemWidth
      ),
      behavior: 'smooth'
    });
    setTimeout(() => setDate(new Date()), 200);
  };
  const isOverflow = ref.current && productsRef.current && ref.current.clientWidth < productsRef.current.scrollWidth;
  const isLeaningLeft = !!productsRef.current && productsRef.current.scrollLeft > 5;
  const isLeaningRight = !!productsRef.current && productsRef.current.scrollLeft < producstWidth - 5;
  
  useEffect(() => {
    if (selectedProduct) {
      const id = `promotion-profile-products__${selectedProduct.id}`;
      const target = document.getElementById(id);
      target && target.scrollIntoView();
    }
  }, []);
  useEffect(() => {
    setDate(new Date());
  }, [ref]);

  return (
    <>
      {productCategories.length ? (
        <Categories
          classPrefix={PREFIX_CLASSNAME}
          isHorizontal={isHorizontal}
        />
      ) : null}
      <Container
        className={PREFIX_CLASSNAME}
        isHorizontal={isHorizontal}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        ref={ref}
      >
        {isHovering && isOverflow && isLeaningLeft && (
          <ScrollButtonLeft
            className={`${PREFIX_CLASSNAME}__scroll-button-left__wrapper`}
            onClick={() => handleScrollByButtons(true)}
          >
            <ScrollButton
              classPrefix={PREFIX_CLASSNAME}
              type='left'
              size='medium'
            />
          </ScrollButtonLeft>
        )}
        <Items
          className={`${PREFIX_CLASSNAME}__items`}
          isHorizontal={isHorizontal}
          existCategories={!!productCategories.length}
          onScroll={handleScroll}
          ref={productsRef}
        >
          {isHorizontal ? (
            <EmptyColumn className={`${PREFIX_CLASSNAME}__empty-column`} />
          ) : null}
          {products.length ? products.map((row: Feature.Profile.Product, i) => (
            <Item
              classPrefix={PREFIX_CLASSNAME}
              product={row}
              isHorizontal={isHorizontal}
              isLast={i === products.length - 1 && !productIsLasted}
              onReadMore={handleReadMore}
              onClick={onClick}
              ref={i === 0 ? itemRef : null}
              key={`products-row__${row.id}`}
            />
          )) : (
            <Item
              classPrefix={PREFIX_CLASSNAME}
              isHorizontal={isHorizontal}
              onClick={onClick}
              key={`products-row__empty`}
            />
          )}
          {isHorizontal ? (
            <EmptyColumn className={`${PREFIX_CLASSNAME}__empty-column`} />
          ) : null}
        </Items>
        {isHovering && isOverflow && isLeaningRight && (
          <ScrollButtonRight
            className={`${PREFIX_CLASSNAME}__scroll-button-right__wrapper`}
            onClick={() => handleScrollByButtons()}
          >
            <ScrollButton
              classPrefix={PREFIX_CLASSNAME}
              type='right'
              size='medium'
            />
          </ScrollButtonRight>
        )}
      </Container>
    </>
  );
};

export default Products;
