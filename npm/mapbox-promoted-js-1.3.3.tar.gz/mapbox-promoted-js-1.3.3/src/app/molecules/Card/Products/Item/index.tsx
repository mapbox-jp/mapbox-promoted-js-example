import React, { useState } from 'react';
import { Waypoint } from 'react-waypoint';
// Components
import {
  Container,
  HorizontalContainer,
  Thumbnail,
  ThumbnailImg,
  Content,
  Title,
  Price,
} from './styles';

type Props = {
  classPrefix?: string;
  product?: Feature.Profile.Product;
  isHorizontal?: boolean;
  isLast?: boolean;
  onReadMore?: () => void;
  onClick?: (product: Feature.Profile.Product) => void;
};

const Item = React.forwardRef<HTMLLIElement, Props>((props, ref) => {
  const { classPrefix, product, isHorizontal, isLast, onReadMore, onClick } = props;
  const { title, price, image_url } = product || {};
  const id = `promotion-profile-products__${product && product.id || 'empty'}`;
  const [isRead, setIsRead] = useState(false);
  const handleRead = () => {
    onReadMore && onReadMore();
    setIsRead(true);
  };
  const handleClick = () => product && onClick && onClick(product);
  const renderContent = () => (
    <>
      {isLast && !isRead && (
        <Waypoint
          horizontal={isHorizontal}
          onEnter={handleRead}
        />
      )}
      <Thumbnail className={`${classPrefix}__item__thumb`}>
        {image_url && (
          <ThumbnailImg
            className={`${classPrefix}__item__thumb-img`}
            src={image_url}
          />
        )}
      </Thumbnail>
      <Content
        className={`${classPrefix}__item__content`}
        isHorizontal={isHorizontal}
      >
        <Title
          className={`${classPrefix}__item__title`}
          isHorizontal={isHorizontal}
        >
          {title}
        </Title>
        {!!price && (
          <Price className={`${classPrefix}__item__price`}>
            {`${price}円`}
          </Price>
        )}
      </Content>
    </>
  );
  return isHorizontal ? (
    <HorizontalContainer
      id={id}
      className={`${classPrefix}__item`}
      onClick={handleClick}
      ref={ref}
    >
      {renderContent()}
    </HorizontalContainer>
  ) : (
    <Container
      id={id}
      className={`${classPrefix}__item`}
      onClick={handleClick}
      ref={ref}
    >
      {renderContent()}
    </Container>
  );
});

export default Item;
