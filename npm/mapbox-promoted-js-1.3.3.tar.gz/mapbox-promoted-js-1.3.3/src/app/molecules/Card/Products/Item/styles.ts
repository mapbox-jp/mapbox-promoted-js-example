import styled from 'styled-components';

type Content = {
  isHorizontal?: boolean;
};
type Title = {
  isHorizontal?: boolean;
};

export const Container = styled.li`
  display: flex;
  position: relative;
  padding: 12px 0px;
  width: 100%;
  overflow: hidden;
  &:first-child {
    padding-top: 0;
  }
  &:last-child {
    padding-bottom: 0;
  }
  & + & {
    :before {
      content: "";
      position: absolute;
      display: block;
      top: 0;
      width: 100%;
      border-top: 1px solid #e8eaed;
    }
  }
`;
export const HorizontalContainer = styled.li`
  display: flex;
  position: relative;
  padding: 8px;
  width: 253px;
  min-width: 253px;
  border: solid 1px #ebebed;
  border-radius: 4px;
  cursor: pointer;
  & + & {
    margin: 0 0 0 8px;
  }
`;
export const Thumbnail = styled.div`
  position: relative;
  width: 75px;
  min-width: 75px;
  height: 75px;
  min-height: 75px;
  border-radius: 4px;
  overflow: hidden;
  &:before {
    content: "";
    display: block;
    width: 100%;
    height: 100%;
    border: 1px solid rgb(235, 235, 237);
    box-sizing: border-box;
  }
`;
export const ThumbnailImg = styled.img`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background-color: #f4f4f5;
  object-fit: cover;
  border-radius: 4px;
`;
export const Content = styled.div`
  ${({ isHorizontal }: Content) => isHorizontal ? `
    display: flex;
    flex-direction: column;
    justify-content: center;
    padding: 0 0 0 14px;
    width: 160px;
    min-width: 160px;
  ` : `
    padding: 10px 0 10px 18px;
    width: 100%;
  `};
`;
export const Title = styled.h4`
  display: -webkit-box;
  margin: 0 0 6px 0;
  font-size: 14px;
  line-height: 1.5;
  color: #636363;
  overflow: hidden;
  -webkit-box-orient: vertical;
  ${({ isHorizontal }: Title) => isHorizontal ? `
    -webkit-line-clamp: 2;
  ` : `
    -webkit-line-clamp: 1;
  `};
`;
export const Price = styled.div`
  display: -webkit-box;
  font-size: 14px;
  line-height: 1.5;
  color: #636363;
  overflow: hidden;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
`;

