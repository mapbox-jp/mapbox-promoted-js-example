import styled from 'styled-components';

export const Container = styled.div`
  position: relative;
  margin-top: 15px;
`;
export const Title = styled.div`
  position: relative;
  display: flex;
  align-items: center;
`;
export const TitleLabel = styled.h1`
  margin: 0;
  display: -webkit-box;
  width: calc(100% - 36px - 10px);
  font-size: 16px;
  font-weight: 600;
  line-height: 1.5;
  overflow: hidden;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
`;
export const PromotionTagWrapper = styled.div`
  position: absolute;
  right: 0;
`;
export const TooltipWrapper = styled.div`
  position: absolute;
  top: 35px;
  z-index: 5;
`;
export const Category = styled.div`
  display: -webkit-box;
  margin-top: 5px;
  font-size: 14px;
  line-height: 1.8;
  color: #9f9f9f;
  overflow: hidden;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
`;
