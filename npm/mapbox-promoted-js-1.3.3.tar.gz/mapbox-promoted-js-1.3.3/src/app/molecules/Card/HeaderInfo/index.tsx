import React, { useEffect, useState } from 'react';
// Components
import PromotionTag from 'atoms/PromotionTag';
import Tooltip from 'atoms/Tooltip';
import {
  Container,
  Title,
  TitleLabel,
  PromotionTagWrapper,
  TooltipWrapper,
  Category,
} from './styles';
import { CLICK_TYPES } from '../helpers';

type Props = {
  classPrefix?: string;
  feature: Feature;
  onClick: (type: Promotion.ClickTypes) => void;
};

const HeaderInfo: React.FC<Props> = props => {
  const { classPrefix, feature, onClick } = props;
  const { feature_id, name_ja, title, category } = feature.properties;
  const PREFIX_CLASSNAME = `${classPrefix}__header-info`;

  const [isShowingTooltip, setIsShowingTooltip] = useState(false);

  const handleToggleTooltip = () => setIsShowingTooltip(!isShowingTooltip);
  const handleClickTooltipDetail = () => onClick(CLICK_TYPES.QUOTE);
  const handleCloseTooltip = (event?: React.MouseEvent<HTMLButtonElement, MouseEvent>) => {
    if (event) {
      event.preventDefault();
      event.stopPropagation();
    }
    setIsShowingTooltip(false)
  };

  useEffect(() => {
    setIsShowingTooltip(false);
  }, [feature_id]);

  return (
    <Container className={PREFIX_CLASSNAME}>
      <Title className={`${PREFIX_CLASSNAME}__title`}>
        <TitleLabel className={`${PREFIX_CLASSNAME}__title-label`}>
          {title || name_ja || ''}
        </TitleLabel>
        <PromotionTagWrapper className={`${PREFIX_CLASSNAME}__promotion-tag-wrapper`}>
          <PromotionTag
            classPrefix={`${PREFIX_CLASSNAME}__promotion-tag`}
            onClick={() => {
              handleToggleTooltip();
              onClick(CLICK_TYPES.ATTRIBUTION);
            }}
          />
          {isShowingTooltip && (
            <TooltipWrapper className={`${PREFIX_CLASSNAME}__tooltip-wrapper`}>
              <Tooltip
                classPrefix={PREFIX_CLASSNAME}
                onClickDetail={handleClickTooltipDetail}
                onClose={handleCloseTooltip}
              />
            </TooltipWrapper>
          )}
        </PromotionTagWrapper>
      </Title>
      {category ? (
        <Category className={`${PREFIX_CLASSNAME}__category`}>
          {category.split(',').join(', ')}
        </Category>
      ) : null}
    </Container>
  );
};

export default HeaderInfo;
