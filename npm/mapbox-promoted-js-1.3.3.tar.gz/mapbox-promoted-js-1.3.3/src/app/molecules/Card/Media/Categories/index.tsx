import React, { useContext, useRef, useMemo, useState } from 'react';
import { ProfileContext } from 'molecules/Card/hooks';
// Components
import ScrollButton from 'atoms/ScrollButton';
import {
  CategoriesWrapper,
  Categories,
  Category,
  ScrollButtonLeft,
  ScrollButtonRight,
} from './styles';

type Props = {
  classPrefix?: string;
  isHorizontal?: boolean;
};

const CATEGORIES_ITEM_WIDTH = 100;

const Products: React.FC<Props> = props => {
  const { classPrefix, isHorizontal } = props;
  const {
    isMediaFetching,
    mediaCategories,
    mediaCategoryId,
    updateMediaCategory,
  } = useContext(ProfileContext);
  const PREFIX_CLASSNAME = `${classPrefix}__categories`;

  const ref = useRef<HTMLDivElement>(null);
  const categoriesRef = useRef<HTMLDivElement>(null);
  const [isHovering, setIsHovering] = useState(false);
  const [_, setDate] = useState<Date>();
  const categoriesWidth = useMemo(
    () => categoriesRef.current && categoriesRef.current.scrollWidth - categoriesRef.current.clientWidth || 0,
    [categoriesRef.current, categoriesRef.current && categoriesRef.current.scrollWidth]
  );

  const handleSelect = (categoryId?: string) => updateMediaCategory(categoryId);
  const handleMouseEnter = () => setIsHovering(true);
  const handleMouseLeave = () => setIsHovering(false);
  const handleScroll = () => setDate(new Date());
  const handleScrollByButtons = (left: boolean = false) => {
    if (!categoriesRef.current) { return; }
    categoriesRef.current.scroll({
      left: categoriesRef.current.scrollLeft + (
        left ? -1 * CATEGORIES_ITEM_WIDTH : CATEGORIES_ITEM_WIDTH
      ),
      behavior: 'smooth'
    });
    setTimeout(() => setDate(new Date()), 200);
  };
  const isOverflow = ref.current && categoriesRef.current && ref.current.clientWidth < categoriesRef.current.scrollWidth;
  const isLeaningLeft = !!categoriesRef.current && categoriesRef.current.scrollLeft > 5;
  const isLeaningRight = !!categoriesRef.current && categoriesRef.current.scrollLeft < categoriesWidth - 5;

  return (
    <CategoriesWrapper
      className={`${PREFIX_CLASSNAME}-wrapper`}
      isHorizontal={isHorizontal}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      ref={ref}
    >
      {isHovering && isOverflow && isLeaningLeft && (
        <ScrollButtonLeft
          className={`${PREFIX_CLASSNAME}__scroll-button-left__wrapper`}
          onClick={() => handleScrollByButtons(true)}
        >
          <ScrollButton
            classPrefix={`${PREFIX_CLASSNAME}__scroll-button-left`}
            type='left'
            size='medium'
          />
        </ScrollButtonLeft>
      )}
      <Categories
        className={PREFIX_CLASSNAME}
        isHorizontal={isHorizontal}
        onScroll={handleScroll}
        ref={categoriesRef}
      >
        <Category
          className={`${PREFIX_CLASSNAME}-item ${!mediaCategoryId ? `${PREFIX_CLASSNAME}-item__selected` : ''}`}
          isSelected={!mediaCategoryId}
          isFetching={isMediaFetching}
          onClick={() => !isMediaFetching && handleSelect()}
        >
          すべて
        </Category>
        {mediaCategories.map((category) => {
          const isSelected = category.id === mediaCategoryId;
          return (
            <Category
              className={`${PREFIX_CLASSNAME}-item ${isSelected ? `${PREFIX_CLASSNAME}-item__selected` : ''}`}
              isSelected={isSelected}
              isFetching={isMediaFetching}
              onClick={() => !isMediaFetching && handleSelect(category.id)}
              key={`media-categories__${category.id}`}
            >
              {category.name}
            </Category>
          );
        })}
      </Categories>
      {isHovering && isOverflow && isLeaningRight && (
        <ScrollButtonRight
          className={`${PREFIX_CLASSNAME}__scroll-button-right__wrapper`}
          onClick={() => handleScrollByButtons()}
        >
          <ScrollButton
            classPrefix={`${PREFIX_CLASSNAME}__scroll-button-right`}
            type='right'
            size='medium'
          />
        </ScrollButtonRight>
      )}
    </CategoriesWrapper>
  );
};

export default Products;
