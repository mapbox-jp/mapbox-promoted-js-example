import React, { useContext, useEffect, useRef, useMemo, useState } from 'react';
import { ProfileContext } from 'molecules/Card/hooks';
// Components
import ScrollButton from 'atoms/ScrollButton';
import Categories from './Categories';
import Item from './Item';
import {
  Container,
  Items,
  ScrollButtonLeft,
  ScrollButtonRight,
  EmptyColumn,
} from './styles';

type Props = {
  classPrefix?: string;
  isHorizontal?: boolean;
  onClick?: (media: Feature.Profile.Media) => void;
};

const MEDIA_ITEM_WIDTH = 104.5;

const Media: React.FC<Props> = props => {
  const { classPrefix, isHorizontal, onClick } = props;
  const {
    mediaCategories,
    media,
    mediaCategoryId,
    mediaIsLasted,
    readmoreMedia
  } = useContext(ProfileContext);
  const PREFIX_CLASSNAME = `${classPrefix}-media`;

  const ref = useRef<HTMLDivElement>(null);
  const mediaRef = useRef<HTMLUListElement>(null);
  const itemRef = useRef<HTMLLIElement>(null);
  const [isHovering, setIsHovering] = useState(false);
  const [_, setDate] = useState<Date>();
  const mediaWidth = useMemo(
    () => mediaRef.current && mediaRef.current.scrollWidth - mediaRef.current.clientWidth || 0,
    [mediaRef.current, mediaRef.current && mediaRef.current.scrollWidth]
  );
  const itemWidth = useMemo(
    () => itemRef.current && itemRef.current.clientWidth || MEDIA_ITEM_WIDTH,
    [itemRef.current]
  );

  const handleReadMore = () => readmoreMedia(mediaCategoryId);
  const handleMouseEnter = () => setIsHovering(true);
  const handleMouseLeave = () => setIsHovering(false);
  const handleScroll = () => setDate(new Date());
  const handleScrollByButtons = (left: boolean = false) => {
    if (!mediaRef.current) { return; }
    mediaRef.current.scroll({
      left: mediaRef.current.scrollLeft + (
        left ? -1 * itemWidth : itemWidth
      ),
      behavior: 'smooth'
    });
    setTimeout(() => setDate(new Date()), 200);
  };
  const isOverflow = ref.current && mediaRef.current && ref.current.clientWidth < mediaRef.current.scrollWidth;
  const isLeaningLeft = !!mediaRef.current && mediaRef.current.scrollLeft > 5;
  const isLeaningRight = !!mediaRef.current && mediaRef.current.scrollLeft < mediaWidth - 5;

  useEffect(() => {
    setDate(new Date());
  }, [ref]);

  return (
    <>
      {mediaCategories.length ? (
        <Categories
          classPrefix={PREFIX_CLASSNAME}
          isHorizontal={isHorizontal}
        />
      ) : null}
      <Container
        className={PREFIX_CLASSNAME}
        isHorizontal={isHorizontal}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        ref={ref}
      >
        {isHovering && isOverflow && isLeaningLeft && (
          <ScrollButtonLeft
            className={`${PREFIX_CLASSNAME}__scroll-button-left__wrapper`}
            onClick={() => handleScrollByButtons(true)}
          >
            <ScrollButton
              classPrefix={PREFIX_CLASSNAME}
              type='left'
              size='medium'
            />
          </ScrollButtonLeft>
        )}
        <Items
          className={`${PREFIX_CLASSNAME}__items`}
          isHorizontal={isHorizontal}
          existCategories={!!mediaCategories.length}
          onScroll={handleScroll}
          ref={mediaRef}
        >
          {isHorizontal ? (
            <EmptyColumn className={`${PREFIX_CLASSNAME}__empty-column`} />
          ) : null}
          {media.length ? media.map((row: Feature.Profile.Media, i) => (
            <Item
              classPrefix={PREFIX_CLASSNAME}
              media={row}
              isHorizontal={isHorizontal}
              isLast={i === media.length - 1 && !mediaIsLasted}
              onReadMore={handleReadMore}
              onClick={onClick}
              ref={i === 0 ? itemRef : null}
              key={`media-row__${row.id}`}
            />
          )) : (
            <Item
              classPrefix={PREFIX_CLASSNAME}
              isHorizontal={isHorizontal}
              onClick={onClick}
              key='media-row__empty'
            />
          )}
          {isHorizontal ? (
            <EmptyColumn className={`${PREFIX_CLASSNAME}__empty-column`} />
          ) : null}
        </Items>
        {isHovering && isOverflow && isLeaningRight && (
          <ScrollButtonRight
            className={`${PREFIX_CLASSNAME}__scroll-button-right__wrapper`}
            onClick={() => handleScrollByButtons()}
          >
            <ScrollButton
              classPrefix={PREFIX_CLASSNAME}
              type='right'
              size='medium'
            />
          </ScrollButtonRight>
        )}
      </Container>
    </>
  );
};

export default Media;
