import { createContext, useRef, useState, useEffect } from 'react';
// APIs
import {
  getNews,
  getProductCategories,
  getProducts,
  getMediaCategories,
  getMedia,
} from 'apis/profiles';

export type ProfileContext = {
  isNewsFetching: boolean;
  news: Feature.Profile.News[];
  newsIsLasted?: boolean;
  readmoreNews: () => void;

  isProductsFetching: boolean;
  productCategories: Feature.Profile.Category[];
  products: Feature.Profile.Product[];
  productCategoryId?: string;
  productIsLasted?: boolean;
  fetchProductCategories: () => void;
  updateProductCategory: (categoryId?: string) => void;
  readmoreProducts: (categoryId?: string) => void;

  isMediaFetching: boolean;
  mediaCategories: Feature.Profile.Category[];
  media: Feature.Profile.Media[];
  mediaCategoryId?: string;
  mediaIsLasted?: boolean;
  fetchMediaCategories: () => void;
  updateMediaCategory: (categoryId?: string) => void;
  readmoreMedia: (categoryId?: string) => void;
}

export const ProfileContext = createContext<ProfileContext>({
  isNewsFetching: false,
  news: [],
  readmoreNews: () => {},

  isProductsFetching: false,
  productCategories: [],
  products: [],
  fetchProductCategories: () => {},
  updateProductCategory: (_categoryId = '') => {},
  readmoreProducts: (_categoryId = '') => {},

  isMediaFetching: false,
  mediaCategories: [],
  media: [],
  fetchMediaCategories: () => {},
  updateMediaCategory: (_categoryId = '') => {},
  readmoreMedia: (_categoryId = '') => {},
});

export const useProfile = (featureId: string, enableProfile = false) => {
  return {
    ...useNews(featureId, enableProfile),
    ...useProductCategories(featureId, enableProfile),
    ...useProducts(featureId, enableProfile),
    ...useMediaCategories(featureId, enableProfile),
    ...useMedia(featureId, enableProfile),
  };
};

export const useNews = (featureId: string, enableProfile: boolean) => {
  const featureIdRef = useRef<string>();
  const newsRef = useRef<Feature.Profile.News[]>([]);
  const [params, setParams] = useState<{
    nextToken: string;
    isLasted: boolean;
    isRequeted: boolean;
  }>({
    nextToken: '',
    isLasted: false,
    isRequeted: false
  });
  const [isNewsFetching, setIsNewsFetching] = useState(false);
  const [_, setDate] = useState<Date>();
  const { nextToken, isLasted, isRequeted } = params;
  const updateParams = (params = {}) => {
    const updateParams = Object.assign({}, {
      nextToken: '',
      isLasted: false,
      isRequeted: false
    }, params);
    setParams(updateParams);
  };
  const readmore = () => fetchNews();
  const fetchNews = () => {
    setIsNewsFetching(true);
    getNews(featureId, nextToken).then(({ news, token }) => {
      newsRef.current = nextToken ? [...newsRef.current, ...news] : news;
      if (!token) {
        updateParams({ nextToken: '', isLasted: true, isRequeted: true });
      } else {
        updateParams({ nextToken: token, isRequeted: true });
      }
    }).catch((error) => {
      console.error(error);
    }).finally(() => {
      setIsNewsFetching(false);
      setDate(new Date());
    });
  };
  useEffect(() => {
    if (!!featureIdRef.current && featureIdRef.current !== featureId) {
      newsRef.current = [];
      updateParams();
    } else if (enableProfile && !isRequeted) {
      fetchNews();
    }
    featureIdRef.current = featureId;
  }, [params, featureId]);
  return {
    isNewsFetching,
    news: newsRef.current,
    newsIsLasted: isLasted,
    readmoreNews: readmore,
  };
};

export const useProductCategories = (featureId: string, enableProfile: boolean) => {
  const categoriesRef = useRef<Feature.Profile.Category[]>([]);
  const [_, setDate] = useState<Date>();
  const fetchProductCategories = () => {
    getProductCategories(featureId).then((categories) => {
      categoriesRef.current = [...categoriesRef.current, ...categories];
    }).catch((error) => {
      console.error(error);
    }).finally(() => {
      setDate(new Date());
    });
  };
  useEffect(() => {
    categoriesRef.current = [];
    enableProfile && fetchProductCategories();
  }, [featureId]);
  return {
    productCategories: categoriesRef.current,
    fetchProductCategories,
  };
};

export const useProducts = (featureId: string, enableProfile: boolean) => {
  const featureIdRef = useRef<string>();
  const productsRef = useRef<Feature.Profile.Product[]>([]);
  const [params, setParams] = useState<{
    nextToken: string;
    categoryId: string;
    isLasted: boolean;
    isRequeted: boolean;
  }>({
    nextToken: '',
    categoryId: '',
    isLasted: false,
    isRequeted: false
  });
  const [isProductsFetching, setIsProductsFetching] = useState(false);
  const [_, setDate] = useState<Date>();
  const { nextToken, categoryId, isLasted, isRequeted } = params;
  const updateParams = (params = {}) => {
    const updateParams = Object.assign({}, {
      nextToken: '',
      categoryId,
      isLasted: false,
      isRequeted: false
    }, params);
    setParams(updateParams);
  };
  const updateCategory = (updatedCategoryId: string = '') => {
    if (updatedCategoryId !== categoryId || (updatedCategoryId === categoryId && isLasted)) {
      productsRef.current = [];
      updateParams({ categoryId: updatedCategoryId, isRequeted: false });
    }
  };
  const readmore = (updatedCategoryId: string = '') => fetchProducts(updatedCategoryId);
  const fetchProducts = (updatedCategoryId?: string) => {
    setIsProductsFetching(true);
    getProducts(featureId, nextToken, updatedCategoryId).then(({ products, token }) => {
      productsRef.current = [...productsRef.current, ...products];
      if (!token) {
        updateParams({ nextToken: '', isLasted: true, isRequeted: true });
      } else {
        updateParams({ nextToken: token, isRequeted: true });
      }
    }).catch((error) => {
      console.error(error);
    }).finally(() => {
      setIsProductsFetching(false);
      setDate(new Date());
    });
  };
  useEffect(() => {
    if (!!featureIdRef.current && featureIdRef.current !== featureId) {
      productsRef.current = [];
      updateParams();
    } else if (enableProfile && !isRequeted) {
      fetchProducts(categoryId);
    }
    featureIdRef.current = featureId;
  }, [params, featureId]);
  return {
    isProductsFetching,
    products: productsRef.current,
    productCategoryId: categoryId,
    productIsLasted: isLasted,
    updateProductCategory: updateCategory,
    readmoreProducts: readmore,
  };
};

export const useMediaCategories = (featureId: string, enableProfile: boolean) => {
  const categoriesRef = useRef<Feature.Profile.Category[]>([]);
  const [_, setDate] = useState<Date>();
  const fetchMediaCategories = () => {
    getMediaCategories(featureId).then((categories) => {
      categoriesRef.current = [...categoriesRef.current, ...categories];
    }).catch((error) => {
      console.error(error);
    }).finally(() => {
      setDate(new Date());
    });
  };
  useEffect(() => {
    categoriesRef.current = [];
    enableProfile && fetchMediaCategories();
  }, [featureId]);
  return {
    mediaCategories: categoriesRef.current,
    fetchMediaCategories,
  };
};

export const useMedia = (featureId: string, enableProfile: boolean) => {
  const featureIdRef = useRef<string>();
  const mediaRef = useRef<Feature.Profile.Media[]>([]);
  const [params, setParams] = useState<{
    nextToken: string;
    categoryId: string;
    isLasted: boolean;
    isRequeted: boolean;
  }>({
    nextToken: '',
    categoryId: '',
    isLasted: false,
    isRequeted: false
  });
  const [isMediaFetching, setIsMediaFetching] = useState(false);
  const [_, setDate] = useState<Date>();
  const { nextToken, categoryId, isLasted, isRequeted } = params;
  const updateParams = (params = {}) => {
    const updateParams = Object.assign({}, {
      nextToken: '',
      categoryId,
      isLasted: false,
      isRequeted: false
    }, params);
    setParams(updateParams);
  };
  const updateCategory = (updatedCategoryId: string = '') => {
    if (updatedCategoryId !== categoryId || (updatedCategoryId === categoryId && isLasted)) {
      mediaRef.current = [];
      updateParams({ categoryId: updatedCategoryId, isRequeted: false });
    }
  };
  const readmore = (updatedCategoryId?: string) => fetchMedia(updatedCategoryId);
  const fetchMedia = (updatedCategoryId = categoryId) => {
    setIsMediaFetching(true);
    getMedia(featureId, nextToken, updatedCategoryId).then(({ media, token }) => {
      mediaRef.current = [...mediaRef.current, ...media];
      if (!token) {
        updateParams({ nextToken: '', isLasted: true, isRequeted: true });
      } else {
        updateParams({ nextToken: token, isRequeted: true });
      }
    }).catch((error) => {
      console.error(error);
    }).finally(() => {
      setIsMediaFetching(false);
      setDate(new Date());
    });
  };
  useEffect(() => {
    if (!!featureIdRef.current && featureIdRef.current !== featureId) {
      mediaRef.current = [];
      updateParams();
    } else if (enableProfile && !isRequeted) {
      fetchMedia(categoryId);
    }
    featureIdRef.current = featureId;
  }, [params, featureId]);
  return {
    isMediaFetching,
    media: mediaRef.current,
    mediaCategoryId: categoryId,
    mediaIsLasted: isLasted,
    updateMediaCategory: updateCategory,
    readmoreMedia: readmore,
  };
};
