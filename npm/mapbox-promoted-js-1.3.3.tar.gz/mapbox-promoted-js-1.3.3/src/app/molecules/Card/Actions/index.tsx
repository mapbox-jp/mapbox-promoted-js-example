import React, { useRef, useMemo, useState } from 'react';
// Components
import ScrollButton from 'atoms/ScrollButton';
import ActionItem from './Item';
import {
  Container,
  ScrollButtonLeft,
  ScrollButtonRight,
  ActionItems,
} from './styles';
import { ACTION_TYPES, ACTIONS, ActionTypes } from './helpers';

type Props = {
  classPrefix?: string;
  feature: Feature;
  onClick: (type: Promotion.ClickTypes) => void;
};

const ACTION_ITEM_WIDTH = 74;

const Actions: React.FC<Props> = props => {
  const { classPrefix, feature, onClick } = props;
  const { properties } = feature;
  const { feature_id } = properties;
  const PREFIX_CLASSNAME = `${classPrefix}__actions`;

  const ref = useRef<HTMLDivElement>(null);
  const actionRef = useRef<HTMLUListElement>(null);
  const itemRef = useRef<HTMLLIElement>(null);
  const [isHovering, setIsHovering] = useState(false);
  const [_data, setDate] = useState(new Date());
  const actionWidth = useMemo(
    () => actionRef.current && actionRef.current.scrollWidth - actionRef.current.clientWidth || 0,
    [actionRef.current, actionRef.current && actionRef.current.scrollWidth]
  );
  const itemWidth = useMemo(
    () => itemRef.current && itemRef.current.clientWidth || ACTION_ITEM_WIDTH,
    [itemRef.current]
  );
  const externalLinks: Feature.ExternalLink[] = useMemo(
    () => properties.external_links && typeof properties.external_links === 'string' ?
      JSON.parse(properties.external_links) : properties.external_links || [],
    [feature_id]
  );

  const keys = Object.values(ACTION_TYPES) as ActionTypes[];
  const handleClick = (type: Promotion.ClickTypes) => onClick(type);
  const handleMouseEnter = () => setIsHovering(true);
  const handleMouseLeave = () => setIsHovering(false);
  const handleScrollByButtons = (left: boolean = false) => {
    if (!actionRef.current) { return; }
    actionRef.current.scroll({
      left: actionRef.current.scrollLeft + (
        left ? -1 * itemWidth : itemWidth
      ),
      behavior: 'smooth'
    });
    setTimeout(() => setDate(new Date()), 200);
  };
  const handleScroll = () => setDate(new Date());
  const isOverflow = ref.current && actionRef.current && ref.current.clientWidth < actionRef.current.scrollWidth;
  const isLeaningLeft = !!actionRef.current && actionRef.current.scrollLeft > 5;
  const isLeaningRight = !!actionRef.current && actionRef.current.scrollLeft < actionWidth - 5;

  return (
    <Container
      className={PREFIX_CLASSNAME}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      ref={ref}
    >
      {isHovering && isOverflow && isLeaningLeft && (
        <ScrollButtonLeft
          className={`${PREFIX_CLASSNAME}__scroll-button-left__wrapper`}
          onClick={() => handleScrollByButtons(true)}
        >
          <ScrollButton
            classPrefix={`${PREFIX_CLASSNAME}__scroll-button-left`}
            type='left'
          />
        </ScrollButtonLeft>
      )}
      <ActionItems
        className={`${PREFIX_CLASSNAME}-items`}
        onScroll={handleScroll}
        ref={actionRef}
      >
        {keys.map((key, i) => {
          const action = ACTIONS[key];
          let value = (properties as any)[action.key];
          if (action.key.includes('external_links')) {
            const serviceType = action.key.split('.')[1];
            const externalLink = externalLinks.find(externalLink =>
              externalLink.type === serviceType);
            if (!externalLink) { return; }
            value = externalLink.url;
          }
          return !!value || action.isRequired ? (
            <ActionItem
              classPrefix={classPrefix}
              type={key}
              value={value}
              isBlank={action.isBlank}
              onClick={handleClick}
              key={`${PREFIX_CLASSNAME}-${key}`}
              ref={i === 0 ? itemRef : null}
            />
          ) : null;
        })}
      </ActionItems>
      {isHovering && isOverflow && isLeaningRight && (
        <ScrollButtonRight
          className={`${PREFIX_CLASSNAME}__scroll-button-right__wrapper`}
          onClick={() => handleScrollByButtons()}
        >
          <ScrollButton
            classPrefix={`${PREFIX_CLASSNAME}__scroll-button-right`}
            type='right'
          />
        </ScrollButtonRight>
      )}
    </Container>
  );
};

export default Actions;
