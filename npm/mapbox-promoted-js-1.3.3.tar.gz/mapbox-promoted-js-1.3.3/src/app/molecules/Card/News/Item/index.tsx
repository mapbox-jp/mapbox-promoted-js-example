import React, { useState } from 'react';
import { Waypoint } from 'react-waypoint';
// Components
import {
  Container,
  HorizontalContainer,
  Thumbnail,
  ThumbnailImg,
  Content,
  Title,
  Description,
} from './styles';

type Props = {
  classPrefix?: string;
  news?: Feature.Profile.News;
  isHorizontal?: boolean;
  isLast?: boolean;
  onReadMore?: () => void;
  onClick?: (news: Feature.Profile.News) => void;
};

const Item = React.forwardRef<HTMLLIElement, Props>((props, ref) => {
  const { classPrefix, news, isHorizontal, isLast, onReadMore, onClick } = props;
  const { title, text, media_items } = news || {};
  const id = `promotion-profile-news__${news && news.id || 'empty'}`;
  const [isRead, setIsRead] = useState(false);
  const handleRead = () => {
    onReadMore && onReadMore();
    setIsRead(true);
  };
  const handleClick = () => news && onClick && onClick(news);
  const enableImage = media_items && Object.keys(media_items).length;
  const renderContent = () => (
    <>
      {isLast && !isRead && (
        <Waypoint
          horizontal={isHorizontal}
          onEnter={handleRead}
        />
      )}
      {isHorizontal || enableImage ? (
        <Thumbnail className={`${classPrefix}__item__thumb`}>
          {enableImage && (
            <ThumbnailImg
              className={`${classPrefix}__item__thumb-img`}
              src={media_items.small.url}
            />
          )}
        </Thumbnail>
      ) : null}
      <Content className={`${classPrefix}__item__content`}>
        <Title className={`${classPrefix}__item__title`}>
          {title}
        </Title>
        <Description
          className={`${classPrefix}__item__description`}
          isHorizontal={isHorizontal}
        >
          {text}
        </Description>
      </Content>
    </>
  );
  return isHorizontal ? (
    <HorizontalContainer
      id={id}
      className={`${classPrefix}__item`}
      onClick={handleClick}
      ref={ref}
    >
      {renderContent()}
    </HorizontalContainer>
  ) : (
    <Container
      id={id}
      className={`${classPrefix}__item`}
      onClick={handleClick}
      ref={ref}
    >
      {renderContent()}
    </Container>
  );
});

export default Item;
