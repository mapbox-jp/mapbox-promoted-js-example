import React, { useContext, useEffect, useRef, useMemo, useState } from 'react';
import { ProfileContext } from 'molecules/Card/hooks';
// Components
import ScrollButton from 'atoms/ScrollButton';
import Item from './Item';
import {
  Container,
  Items,
  ScrollButtonLeft,
  ScrollButtonRight,
  EmptyColumn,
} from './styles';

type Props = {
  classPrefix?: string;
  selectedNews?: Feature.Profile.News;
  isHorizontal?: boolean;
  onClick?: (news: Feature.Profile.News) => void;
};

const NEWS_ITEM_WIDTH = 140;

const News: React.FC<Props> = props => {
  const { classPrefix, selectedNews, isHorizontal, onClick } = props;
  const {
    news,
    newsIsLasted,
    readmoreNews
  } = useContext(ProfileContext);
  const PREFIX_CLASSNAME = `${classPrefix}-news`;

  const ref = useRef<HTMLDivElement>(null);
  const newsRef = useRef<HTMLUListElement>(null);
  const itemRef = useRef<HTMLLIElement>(null);
  const [isHovering, setIsHovering] = useState(false);
  const [_data, setDate] = useState(new Date());
  const newsWidth = useMemo(
    () => newsRef.current && newsRef.current.scrollWidth - newsRef.current.clientWidth || 0,
    [newsRef.current, newsRef.current && newsRef.current.scrollWidth]
  );
  const itemWidth = useMemo(
    () => itemRef.current && itemRef.current.clientWidth || NEWS_ITEM_WIDTH,
    [itemRef.current]
  );

  const handleReadMore = () => readmoreNews();
  const handleMouseEnter = () => setIsHovering(true);
  const handleMouseLeave = () => setIsHovering(false);
  const handleScroll = () => setDate(new Date());
  const handleScrollByButtons = (left: boolean = false) => {
    if (!newsRef.current) { return; }
    newsRef.current.scroll({
      left: newsRef.current.scrollLeft + (
        left ? -1 * itemWidth : itemWidth
      ),
      behavior: 'smooth'
    });
    setTimeout(() => setDate(new Date()), 200);
  };
  const isOverflow = ref.current && newsRef.current && ref.current.clientWidth < newsRef.current.scrollWidth;
  const isLeaningLeft = !!newsRef.current && newsRef.current.scrollLeft > 5;
  const isLeaningRight = !!newsRef.current && newsRef.current.scrollLeft < newsWidth - 5;

  useEffect(() => {
    if (selectedNews) {
      const id = `promotion-profile-news__${selectedNews.id}`;
      const target = document.getElementById(id);
      target && target.scrollIntoView();
    }
  }, []);

  return (
    <Container
      className={PREFIX_CLASSNAME}
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      ref={ref}
    >
      {isHovering && isOverflow && isLeaningLeft && (
        <ScrollButtonLeft
          className={`${PREFIX_CLASSNAME}__scroll-button-left__wrapper`}
          onClick={() => handleScrollByButtons(true)}
        >
          <ScrollButton
            classPrefix={PREFIX_CLASSNAME}
            type='left'
            size='medium'
          />
        </ScrollButtonLeft>
      )}
      <Items
        className={`${PREFIX_CLASSNAME}__items`}
        isHorizontal={isHorizontal}
        onScroll={handleScroll}
        ref={newsRef}
      >
        {isHorizontal ? (
          <EmptyColumn className={`${PREFIX_CLASSNAME}__empty-column`} />
        ) : null}
        {news.length ? news.map((row: Feature.Profile.News, i) => (
          <Item
            classPrefix={PREFIX_CLASSNAME}
            news={row}
            isLast={i === news.length - 1 && !newsIsLasted}
            isHorizontal={isHorizontal}
            onReadMore={handleReadMore}
            onClick={onClick}
            ref={i === 0 ? itemRef : null}
            key={`news-item__${row.id}`}
          />
        )) : (
          <Item
            classPrefix={PREFIX_CLASSNAME}
            isHorizontal={isHorizontal}
            onClick={onClick}
            key='news-item__empty'
          />          
        )}
        {isHorizontal ? (
          <EmptyColumn className={`${PREFIX_CLASSNAME}__empty-column`} />
        ) : null}
      </Items>
      {isHovering && isOverflow && isLeaningRight && (
        <ScrollButtonRight
          className={`${PREFIX_CLASSNAME}__scroll-button-right__wrapper`}
          onClick={() => handleScrollByButtons()}
        >
          <ScrollButton
            classPrefix={PREFIX_CLASSNAME}
            type='right'
            size='medium'
          />
        </ScrollButtonRight>
      )}
    </Container>
  );
};

export default News;