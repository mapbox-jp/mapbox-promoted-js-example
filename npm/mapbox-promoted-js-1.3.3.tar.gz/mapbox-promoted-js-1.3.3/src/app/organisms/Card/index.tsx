import React, { useEffect, useRef } from 'react';
import { observeElementExist } from 'utils/browser';
import Card from 'molecules/Card';

type Props = {
  feature: Feature;
  onClick?: (type: Promotion.ClickTypes, profileItems?: Feature.ProfileItems) => void;
  onUpdate?: (feature: Feature) => void;
  onClose?: (feature: Feature) => void;
};

export const PREFIX_CLASSNAME = 'promotion-side-card';

const InnerCard = React.forwardRef<HTMLDivElement, Props>((props) => {
  const { feature, onClick, onUpdate, onClose } = props;
  const { feature_id } = feature.properties;
  const id = `${PREFIX_CLASSNAME}__${feature_id}`;
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    ref.current && observeElementExist(`#${id}`, () => {
      onClose && onClose(feature);
    });
  }, [ref]);

  return (
    <Card
      id={id}
      classPrefix={PREFIX_CLASSNAME}
      feature={feature}
      onClick={(clickType: Promotion.ClickTypes, profileItems?: Feature.ProfileItems) => {
        onClick && onClick(clickType, profileItems);
      }}
      onUpdate={(targetFeature: Feature) => {
        onUpdate && onUpdate(targetFeature);
      }}
      ref={ref}
    />
  );
});

export default InnerCard;
