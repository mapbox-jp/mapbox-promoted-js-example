import styled from 'styled-components';

type Container = {
  size?: string
  width?: string
  height?: string
  color?: string
  margin?: string
}

export const Container = styled.i`
  display: flex;
  justify-content: center;
  align-items: center;
  margin: ${({ margin }: Container) => margin || '0'};
  width: ${({ width }: Container) => width || 'auto'};
  min-width: ${({ width }: Container) => width || 'auto'};
  height: ${({ height }: Container) => height || 'auto'};
  min-height: ${({ height }: Container) => height || 'auto'};
  font-size: ${({ size }: Container) => size || null};
  color: ${({ color }: Container) => color || null};
`;
