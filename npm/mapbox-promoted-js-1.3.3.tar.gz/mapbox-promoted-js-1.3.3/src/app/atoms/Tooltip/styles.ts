import styled from 'styled-components';

export const Container = styled.div`
  display: inline-block;
  padding: 15px;
  width: 280px;
  background-color: #ffffff;
  border-radius: 5px;
  box-shadow: 0 0 8px rgb(0, 0, 0, 0.15);
  &:before {
    content: "";
    position: absolute;
    top: -10px;
    left: 8px;
    width: 0px;
    height: 0px;
    margin: auto;
    border-left: 10px solid transparent;
    border-right: 10px solid transparent;
    border-bottom: 10px solid rgb(255, 255, 255);
    -webkit-filter: drop-shadow(0 -7px 7px rgb(0, 0, 0, 0.15));
  }
`;
export const Title = styled.h4`
  position: relative;
  margin: 0;
  padding: 0 0 4px 0;
  font-size: 14px;
  white-space: nowrap;
  &:before {
    content: "";
    position: absolute;
    display: block;
    bottom: 0px;
    width: 100%;
    border-top: 1px solid rgb(232, 234, 237);
  }
`;
export const Description = styled.p`
  margin: 12px 0px;
  font-size: 14px;
  line-height: 1.5;
`;
export const Actions = styled.div`
  display: flex;
  justify-content: flex-end;
  align-items: center;
`;
export const AboutButton = styled.a`
  padding: 2px 5px;
  font-size: 14px;
  font-weight: 600;
  color: #1a73e8;
  cursor: pointer;
`;
export const CloseButton = styled.button`
  margin: 0 0 0 10px;
  padding: 0 4px;
  border: none;
  font-size: 14px;
  font-weight: 600;
  color: #1a73e8;
  background-color: transparent;
  cursor: pointer;
`;
