import OpeningHours, {
  getBusinessHoursLabel,
} from 'utils/businessHours';

describe('utils/openingHours.OpeningHours.getTable', () => {
  it('Valid converting from 24/7', () => {
    expect(new OpeningHours('24/7').getTable()).toMatchObject({
      su: ['00:00-23:59'],
      mo: ['00:00-23:59'],
      tu: ['00:00-23:59'],
      we: ['00:00-23:59'],
      th: ['00:00-23:59'],
      fr: ['00:00-23:59'],
      sa: ['00:00-23:59'],
    });
  });
  it('Valid converting from Su 0:00-23:59; Mo 0:00-23:59; Tu 0:00-23:59; We 0:00-23:59; Th 0:00-23:59; Fr 0:00-23:59; Sa 0:00-23:59', () => {
    expect(new OpeningHours('Su 0:00-23:59; Mo 0:00-23:59; Tu 0:00-23:59; We 0:00-23:59; Th 0:00-23:59; Fr 0:00-23:59; Sa 0:00-23:59').getTable()).toMatchObject({
      su: ['00:00-23:59'],
      mo: ['00:00-23:59'],
      tu: ['00:00-23:59'],
      we: ['00:00-23:59'],
      th: ['00:00-23:59'],
      fr: ['00:00-23:59'],
      sa: ['00:00-23:59'],
    });
  });
  it('Valid converting from Mo 09:00-13:00', () => {
    expect(new OpeningHours('Mo 09:00-13:00').getTable()).toMatchObject({
      su: [],
      mo: ['09:00-13:00'],
      tu: [],
      we: [],
      th: [],
      fr: [],
      sa: [],
    });
  });
  it('Valid converting from Mo 09:00-13:00; 17:00-22:00', () => {
    expect(new OpeningHours('Mo 09:00-13:00, 17:00-22:00').getTable()).toMatchObject({
      su: [],
      mo: ['09:00-13:00', '17:00-22:00'],
      tu: [],
      we: [],
      th: [],
      fr: [],
      sa: [],
    });
  });
  it('Valid converting from Mo 09:00-13:00; 17:00-22:00; Sa 10:00-19:00', () => {
    expect(new OpeningHours('Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00').getTable()).toMatchObject({
      su: [],
      mo: ['09:00-13:00', '17:00-22:00'],
      tu: [],
      we: [],
      th: [],
      fr: [],
      sa: ['10:00-19:00'],
    });
  });
  it('Valid converting from Mo-Sa 10:00-23:00', () => {
    expect(new OpeningHours('Mo-Sa 10:00-23:00').getTable()).toMatchObject({
      su: [],
      mo: ['10:00-23:00'],
      tu: ['10:00-23:00'],
      we: ['10:00-23:00'],
      th: ['10:00-23:00'],
      fr: ['10:00-23:00'],
      sa: ['10:00-23:00'],
    });
  });
  it('Valid converting from Mo-Sa 10:00-15:00; 17:00-23:00', () => {
    expect(new OpeningHours('Mo-Sa 10:00-15:00, 17:00-23:00').getTable()).toMatchObject({
      su: [],
      mo: ['10:00-15:00', '17:00-23:00'],
      tu: ['10:00-15:00', '17:00-23:00'],
      we: ['10:00-15:00', '17:00-23:00'],
      th: ['10:00-15:00', '17:00-23:00'],
      fr: ['10:00-15:00', '17:00-23:00'],
      sa: ['10:00-15:00', '17:00-23:00'],
    });
  });
  it('Valid converting from Mo-Th 10:00-14:00; 15:00-20:00; Fr 10:00-14:00; 15:00-18:00', () => {
    expect(new OpeningHours('Mo-Th 10:00-14:00, 15:00-20:00; Fr 10:00-14:00, 15:00-18:00').getTable()).toMatchObject({
      su: [],
      mo: ['10:00-14:00', '15:00-20:00'],
      tu: ['10:00-14:00', '15:00-20:00'],
      we: ['10:00-14:00', '15:00-20:00'],
      th: ['10:00-14:00', '15:00-20:00'],
      fr: ['10:00-14:00', '15:00-18:00'],
      sa: [],
    });
  });
  it('Valid converting from Mo-Fr 10:00-20:00; PH off', () => {
    expect(new OpeningHours('Mo-Fr 10:00-20:00; PH off').getTable()).toMatchObject({
      su: [],
      mo: ['10:00-20:00'],
      tu: ['10:00-20:00'],
      we: ['10:00-20:00'],
      th: ['10:00-20:00'],
      fr: ['10:00-20:00'],
      sa: [],
    });
  });
  it('Valid converting from Mo-Fr 10:00-20:00; PH 10:00-12:00', () => {
    expect(new OpeningHours('Mo-Fr 10:00-20:00; PH 10:00-12:00').getTable()).toMatchObject({
      su: [],
      mo: ['10:00-20:00'],
      tu: ['10:00-20:00'],
      we: ['10:00-20:00'],
      th: ['10:00-20:00'],
      fr: ['10:00-20:00'],
      sa: [],
    });
  });
});

describe('utils/openingHours.getBusinessHoursLabel', () => {
  // 24 hours
  const twentyForHoursOHShortForm = '24/7';
  describe(`Business hours notation by the opening_hours '${twentyForHoursOHShortForm}'`, () => {
    const twentyFourHoursLabel = '24時間営業';
    it(`Valid business hours notation must be '${twentyFourHoursLabel}', when datetime is '2022/12/18 10:00:00'`, () => {
      expect(getBusinessHoursLabel(
        twentyForHoursOHShortForm,
        new Date('2022/12/18 10:00:00') // Wednesday
      )).toEqual(twentyFourHoursLabel);
    });
    it(`Valid business hours notation must be '${twentyFourHoursLabel}', when datetime is '2022/12/18 23:59:59' which is 1 sec before midnight`, () => {
      expect(getBusinessHoursLabel(
        twentyForHoursOHShortForm,
        new Date('2022/12/18 23:59:00') // Sunday
      )).toEqual(twentyFourHoursLabel);
    });
    it(`Valid business hours notation must be '${twentyFourHoursLabel}', when datetime is '2022/12/19 00:00:00' which is just midnight`, () => {
      expect(getBusinessHoursLabel(
        twentyForHoursOHShortForm,
        new Date('2022/12/19 00:00:00') // Monday
      )).toEqual(twentyFourHoursLabel);
    });
    it(`Valid business hours notation must be '${twentyFourHoursLabel}', when datetime is '2022/12/19 00:00:01' which is 1 sec after midnight`, () => {
      expect(getBusinessHoursLabel(
        twentyForHoursOHShortForm,
        new Date('2022/12/19 00:00:01') // Monday
      )).toEqual(twentyFourHoursLabel);
    });
  });

  const twentyForHoursOH = 'Su 0:00-23:59; Mo 0:00-23:59; Tu 0:00-23:59; We 0:00-23:59; Th 0:00-23:59; Fr 0:00-23:59; Sa 0:00-23:59';
  describe(`Business hours notation by the opening_hours '${twentyForHoursOH}'`, () => {
    const twentyFourHoursLabel = '24時間営業';
    it(`Valid business hours notation must be '${twentyFourHoursLabel}', when datetime is '2022/12/18 10:00:00'`, () => {
      expect(getBusinessHoursLabel(
        twentyForHoursOH,
        new Date('2022/12/18 10:00:00') // Wednesday
      )).toEqual(twentyFourHoursLabel);
    });
    it(`Valid business hours notation must be '${twentyFourHoursLabel}', when datetime is '2022/12/18 23:59:59' which is 1 sec before midnight`, () => {
      expect(getBusinessHoursLabel(
        twentyForHoursOH,
        new Date('2022/12/18 23:59:00') // Sunday
      )).toEqual(twentyFourHoursLabel);
    });
    it(`Valid business hours notation must be '${twentyFourHoursLabel}', when datetime is '2022/12/19 00:00:00' which is just midnight`, () => {
      expect(getBusinessHoursLabel(
        twentyForHoursOH,
        new Date('2022/12/19 00:00:00') // Monday
      )).toEqual(twentyFourHoursLabel);
    });
    it(`Valid business hours notation must be '${twentyFourHoursLabel}', when datetime is '2022/12/19 00:00:01' which is 1 sec after midnight`, () => {
      expect(getBusinessHoursLabel(
        twentyForHoursOH,
        new Date('2022/12/19 00:00:01') // Monday
      )).toEqual(twentyFourHoursLabel);
    });
  });

  const twentyForHoursBetweenOH = 'Su-Sa 0:00-24:00';
  describe(`Business hours notation by the opening_hours '${twentyForHoursBetweenOH}'`, () => {
    const twentyFourHoursLabel = '24時間営業';
    it(`Valid business hours notation must be '${twentyFourHoursLabel}', when datetime is '2022/12/18 10:00:00'`, () => {
      expect(getBusinessHoursLabel(
        twentyForHoursBetweenOH,
        new Date('2022/12/18 10:00:00') // Wednesday
      )).toEqual(twentyFourHoursLabel);
    });
    it(`Valid business hours notation must be '${twentyFourHoursLabel}', when datetime is '2022/12/18 23:59:59' which is 1 sec before midnight`, () => {
      expect(getBusinessHoursLabel(
        twentyForHoursBetweenOH,
        new Date('2022/12/18 23:59:00') // Sunday
      )).toEqual(twentyFourHoursLabel);
    });
    it(`Valid business hours notation must be '${twentyFourHoursLabel}', when datetime is '2022/12/19 00:00:00' which is just midnight`, () => {
      expect(getBusinessHoursLabel(
        twentyForHoursBetweenOH,
        new Date('2022/12/19 00:00:00') // Monday
      )).toEqual(twentyFourHoursLabel);
    });
    it(`Valid business hours notation must be '${twentyFourHoursLabel}', when datetime is '2022/12/19 00:00:01' which is 1 sec after midnight`, () => {
      expect(getBusinessHoursLabel(
        twentyForHoursBetweenOH,
        new Date('2022/12/19 00:00:01') // Monday
      )).toEqual(twentyFourHoursLabel);
    });
  });

  // Mo 09:00-13:00
  const mondayOH = 'Mo 09:00-13:00';
  describe(`Business hours notation by the opening_hours '${mondayOH}'`, () => {
    const openingSoonLabel  = 'まもなく開店： 09:00 〜 13:00';
    const closingSoonLabel  = 'まもなく閉店： 09:00 〜 13:00';
    const openingLabel      = '営業中： 09:00 〜 13:00';
    const closingTodayLabel = '営業時間外： 営業開始 09:00 〜 13:00';
    const closingLabel      = '営業時間外： 営業開始 月 09:00 〜 13:00';

    // 「営業時間外（当日）」の1秒前
    it(`Valid business hours notation must be '${closingLabel}', when datetime is '2022/12/12 08:40:00' which is 1 sec before midnight on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondayOH,
        new Date('2022/12/11 23:59:59') // Sunday
      )).toEqual(closingLabel);
    });    
    // 「営業時間外（当日）」
    it(`Valid business hours notation must be '${closingTodayLabel}', when datetime is '2022/12/12 08:40:00' which is just midnight on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondayOH,
        new Date('2022/12/12 00:00:00') // Monday
      )).toEqual(closingTodayLabel);
    });
    // 「営業時間外（当日）」の1秒後
    it(`Valid business hours notation must be '${closingTodayLabel}', when datetime is '2022/12/12 08:40:00' which is 1 sec after midnight on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondayOH,
        new Date('2022/12/12 00:00:01') // Monday
      )).toEqual(closingTodayLabel);
    });
    // 「まもなく開店」の1秒前
    it(`Valid business hours notation must be '${closingTodayLabel}', when datetime is '2022/12/12 08:40:00' which is 1 sec before start of opening_soon on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondayOH,
        new Date('2022/12/12 08:39:59') // Monday
      )).toEqual(closingTodayLabel);
    });
    // 「まもなく開店」
    it(`Valid business hours notation must be '${openingSoonLabel}', when datetime is '2022/12/12 08:40:00' which is just opening_soon on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondayOH,
        new Date('2022/12/12 08:40:00') // Monday
      )).toEqual(openingSoonLabel);
    });
    // 「まもなく開店」の1秒後
    it(`Valid business hours notation must be '${openingSoonLabel}', when datetime is '2022/12/12 08:40:01' which is 1 sec after of opening_soon on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondayOH,
        new Date('2022/12/12 08:40:01') // Monday
      )).toEqual(openingSoonLabel);
    });
    // 「まもなく開店」から「営業中」へ切り替えの1秒前
    it(`Valid business hours notation must be '${openingSoonLabel}', when datetime is '2022/12/12 08:40:01' which is 1 sec before end of opening_soon on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondayOH,
        new Date('2022/12/12 08:59:59') // Monday
      )).toEqual(openingSoonLabel);
    });
    // 「まもなく開店」から「営業中」へ切り替え
    it(`Valid business hours notation must be '${openingLabel}', when datetime is '2022/12/12 09:00:00' which is just end of opening_soon, and start of opening on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondayOH,
        new Date('2022/12/12 09:00:00') // Monday
      )).toEqual(openingLabel);
    });
    // 「営業中」の1秒後
    it(`Valid business hours notation must be '${openingLabel}', when datetime is '2022/12/12 09:00:00' which is 1 sec after opening on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondayOH,
        new Date('2022/12/12 09:00:01') // Monday
      )).toEqual(openingLabel);
    });
    // 「営業中」から「まもなく閉店」へ切り替えの1秒前
    it(`Valid business hours notation must be '${openingLabel}', when datetime is '2022/12/12 12:39:59' which is 1 sec before closing_soon on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondayOH,
        new Date('2022/12/12 12:39:59') // Monday
      )).toEqual(openingLabel);
    });
    // 「営業中」から「まもなく閉店」へ切り替え
    it(`Valid business hours notation must be '${closingSoonLabel}', when datetime is '2022/12/12 12:40:00' which is just start of closing_soon on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondayOH,
        new Date('2022/12/12 12:40:00') // Monday
      )).toEqual(closingSoonLabel);
    });    
    // 「まもなく閉店」の1秒後
    it(`Valid business hours notation must be '${closingSoonLabel}', when datetime is '2022/12/12 12:40:01' which is 1 sec after start of closing_soon on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondayOH,
        new Date('2022/12/12 12:40:01') // Monday
      )).toEqual(closingSoonLabel);
    });    
    // 「まもなく閉店」から「営業時間外（当日）」の切り替え1秒前
    it(`Valid business hours notation must be '${closingSoonLabel}', when datetime is '2022/12/12 13:00:00' which is just end of closing_soon on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondayOH,
        new Date('2022/12/12 13:00:00') // Monday
      )).toEqual(closingSoonLabel);
    });      
    // 「まもなく閉店」から「営業時間外（当日）」の切り替え
    it(`Valid business hours notation must be '${closingLabel}', when datetime is '2022/12/12 13:00:01' which is 1 sec after end of closing_soon on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondayOH,
        new Date('2022/12/12 13:00:01') // Monday
      )).toEqual(closingLabel);
    });          
  });

  // Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00
  const mondaySaturdayOH = 'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00';
  describe(`Business hours notation by the opening_hours '${mondaySaturdayOH}'`, () => {
    const openingSoonAtMondayLabel    = 'まもなく開店： 09:00 〜 13:00, 17:00 〜 22:00';
    const openingSoonAtSaturdayLabel  = 'まもなく開店： 10:00 〜 19:00';
    const closingSoonAtMondayLabel    = 'まもなく閉店： 09:00 〜 13:00, 17:00 〜 22:00';
    const closingSoonAtSaturdayLabel  = 'まもなく閉店： 10:00 〜 19:00';
    const openingAtMondayLabel        = '営業中： 09:00 〜 13:00, 17:00 〜 22:00';
    const openingAtSaturdayLabel      = '営業中： 10:00 〜 19:00';
    const closingTodayAtMondayLabel   = '営業時間外： 営業開始 09:00 〜 13:00, 17:00 〜 22:00';
    const closingTodayAtSaturdayLabel = '営業時間外： 営業開始 10:00 〜 19:00';
    const closingAtMondayLabel        = '営業時間外： 営業開始 月 09:00 〜 13:00, 17:00 〜 22:00';
    const closingAtSaturdayLabel      = '営業時間外： 営業開始 土 10:00 〜 19:00';

    // 「営業時間外（当日）」の1秒前
    it(`Valid business hours notation must be '${closingAtMondayLabel}', when datetime is '2022/12/11 23:59:59' which is 1 sec before midnight on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/11 23:59:59') // Sunday
      )).toEqual(closingAtMondayLabel);
    });
    // 「営業時間外（当日）」
    it(`Valid business hours notation must be '${closingTodayAtMondayLabel}', when datetime is '2022/12/12 00:00:00' which is just midnight on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/12 00:00:00') // Monday
      )).toEqual(closingTodayAtMondayLabel);
    });
    // 「営業時間外（当日）」の1秒後
    it(`Valid business hours notation must be '${closingTodayAtMondayLabel}', when datetime is '2022/12/12 00:00:01' which is 1 sec after midnight on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/12 00:00:01') // Monday
      )).toEqual(closingTodayAtMondayLabel);
    });

    // 「まもなく開店」の1秒前
    it(`Valid business hours notation must be '${closingTodayAtMondayLabel}', when datetime is '2022/12/12 08:39:59' which is 1 sec before start of opening_soon of the first OH on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/12 08:39:59') // Monday
      )).toEqual(closingTodayAtMondayLabel);
    });
    // 「まもなく開店」
    it(`Valid business hours notation must be '${openingSoonAtMondayLabel}', when datetime is '2022/12/12 08:40:00' which is just opening_soon of the first OH on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/12 08:40:00') // Monday
      )).toEqual(openingSoonAtMondayLabel);
    });
    // 「まもなく開店」の1秒後
    it(`Valid business hours notation must be '${openingSoonAtMondayLabel}', when datetime is '2022/12/12 08:40:01' which is 1 sec after of opening_soon of the first OH on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/12 08:40:01') // Monday
      )).toEqual(openingSoonAtMondayLabel);
    });
    // 「まもなく開店」から「営業中」へ切り替えの1秒前
    it(`Valid business hours notation must be '${openingSoonAtMondayLabel}', when datetime is '2022/12/12 08:59:59' which is 1 sec before end of opening_soon of the first OH on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/12 08:59:59') // Monday
      )).toEqual(openingSoonAtMondayLabel);
    });
    // 「まもなく開店」から「営業中」へ切り替え
    it(`Valid business hours notation must be '${openingAtMondayLabel}', when datetime is '2022/12/12 09:00:00' which is just end of opening_soon, and start of opening of the first OH on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/12 09:00:00') // Monday
      )).toEqual(openingAtMondayLabel);
    });
    // 「営業中」の1秒後
    it(`Valid business hours notation must be '${openingAtMondayLabel}', when datetime is '2022/12/12 09:00:01' which is 1 sec after start of opening of the first OH on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/12 09:00:01') // Monday
      )).toEqual(openingAtMondayLabel);
    });
    // 「営業中」から「まもなく閉店」へ切り替えの1秒前
    it(`Valid business hours notation must be '${openingAtMondayLabel}', when datetime is '2022/12/12 12:39:59' which is 1 sec before closing_soon of the first OH on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/12 12:39:59') // Monday
      )).toEqual(openingAtMondayLabel);
    });
    // 「営業中」から「まもなく閉店」へ切り替え
    it(`Valid business hours notation must be '${closingSoonAtMondayLabel}', when datetime is '2022/12/12 12:40:00' which is just start of closing_soon of the first OH on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/12 12:40:00') // Monday
      )).toEqual(closingSoonAtMondayLabel);
    });
    // 「まもなく閉店」の1秒後
    it(`Valid business hours notation must be '${closingSoonAtMondayLabel}', when datetime is '2022/12/12 12:40:01' which is 1 sec after start of closing_soon of the first OH on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/12 12:40:01') // Monday
      )).toEqual(closingSoonAtMondayLabel);
    });
    // 「まもなく閉店」から「営業時間外（当日）」の切り替え1秒前
    it(`Valid business hours notation must be '${closingSoonAtMondayLabel}', when datetime is '2022/12/12 13:00:00' which is just end of closing_soon of the first OH on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/12 13:00:00') // Monday
      )).toEqual(closingSoonAtMondayLabel);
    });
    // 「まもなく閉店」から「営業時間外（当日）」の切り替え
    it(`Valid business hours notation must be '${closingTodayAtMondayLabel}', when datetime is '2022/12/12 13:00:01' which is 1 sec after end of closing_soon of the first OH on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/12 13:00:01') // Monday
      )).toEqual(closingTodayAtMondayLabel);
    });

    // 「まもなく開店」の1秒前
    it(`Valid business hours notation must be '${closingTodayAtMondayLabel}', when datetime is '2022/12/12 16:39:59' which is 1 sec before start of opening_soon of the second OH on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/12 16:39:59') // Monday
      )).toEqual(closingTodayAtMondayLabel);
    });
    // 「まもなく開店」
    it(`Valid business hours notation must be '${openingSoonAtMondayLabel}', when datetime is '2022/12/12 16:40:00' which is just opening_soon of the second OH on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/12 16:40:00') // Monday
      )).toEqual(openingSoonAtMondayLabel);
    });
    // 「まもなく開店」の1秒後
    it(`Valid business hours notation must be '${openingSoonAtMondayLabel}', when datetime is '2022/12/12 16:40:01' which is 1 sec after of opening_soon of the second OH on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/12 16:40:01') // Monday
      )).toEqual(openingSoonAtMondayLabel);
    });
    // 「まもなく開店」から「営業中」へ切り替えの1秒前
    it(`Valid business hours notation must be '${openingSoonAtMondayLabel}', when datetime is '2022/12/12 16:59:59' which is 1 sec before end of opening_soon of the second OH on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/12 16:59:59') // Monday
      )).toEqual(openingSoonAtMondayLabel);
    });
    // 「まもなく開店」から「営業中」へ切り替え
    it(`Valid business hours notation must be '${openingAtMondayLabel}', when datetime is '2022/12/12 17:00:00' which is just end of opening_soon, and start of opening of the second OH on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/12 17:00:00') // Monday
      )).toEqual(openingAtMondayLabel);
    });
    // 「営業中」の1秒後
    it(`Valid business hours notation must be '${openingAtMondayLabel}', when datetime is '2022/12/12 17:00:01' which is 1 sec after start of opening of the second OH on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/12 17:00:01') // Monday
      )).toEqual(openingAtMondayLabel);
    });
    // 「営業中」から「まもなく閉店」へ切り替えの1秒前
    it(`Valid business hours notation must be '${openingAtMondayLabel}', when datetime is '2022/12/12 21:39:59' which is 1 sec before closing_soon of the second OH on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/12 21:39:59') // Monday
      )).toEqual(openingAtMondayLabel);
    });
    // 「営業中」から「まもなく閉店」へ切り替え
    it(`Valid business hours notation must be '${closingSoonAtMondayLabel}', when datetime is '2022/12/12 21:40:00' which is just start of closing_soon of the second OH on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/12 21:40:00') // Monday
      )).toEqual(closingSoonAtMondayLabel);
    });
    // 「まもなく閉店」の1秒後
    it(`Valid business hours notation must be '${closingSoonAtMondayLabel}', when datetime is '2022/12/12 21:40:01' which is 1 sec after start of closing_soon of the second OH on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/12 21:40:01') // Monday
      )).toEqual(closingSoonAtMondayLabel);
    });
    // 「まもなく閉店」から「営業時間外（当日）」の切り替え1秒前
    it(`Valid business hours notation must be '${closingSoonAtMondayLabel}', when datetime is '2022/12/12 22:00:00' which is just end of closing_soon of the second OH on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/12 22:00:00') // Monday
      )).toEqual(closingSoonAtMondayLabel);
    });
    // 「まもなく閉店」から「営業時間外（当日）」の切り替え
    it(`Valid business hours notation must be '${closingAtSaturdayLabel}', when datetime is '2022/12/12 22:00:01' which is 1 sec after end of closing_soon of the second OH on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/12 22:00:01') // Monday
      )).toEqual(closingAtSaturdayLabel);
    });

    // 「まもなく開店」の1秒前
    it(`Valid business hours notation must be '${closingTodayAtSaturdayLabel}', when datetime is '2022/12/12 08:39:59' which is 1 sec before start of opening_soon of the first OH on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/17 09:39:59') // Saturday
      )).toEqual(closingTodayAtSaturdayLabel);
    });
    // 「まもなく開店」
    it(`Valid business hours notation must be '${openingSoonAtSaturdayLabel}', when datetime is '2022/12/12 08:40:00' which is just opening_soon of the first OH on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/17 09:40:00') // Saturday
      )).toEqual(openingSoonAtSaturdayLabel);
    });
    // 「まもなく開店」の1秒後
    it(`Valid business hours notation must be '${openingSoonAtSaturdayLabel}', when datetime is '2022/12/12 08:40:01' which is 1 sec after of opening_soon of the first OH on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/17 09:40:01') // Saturday
      )).toEqual(openingSoonAtSaturdayLabel);
    });
    // 「まもなく開店」から「営業中」へ切り替えの1秒前
    it(`Valid business hours notation must be '${openingSoonAtSaturdayLabel}', when datetime is '2022/12/12 08:59:59' which is 1 sec before end of opening_soon of the first OH on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/17 09:59:59') // Saturday
      )).toEqual(openingSoonAtSaturdayLabel);
    });
    // 「まもなく開店」から「営業中」へ切り替え
    it(`Valid business hours notation must be '${openingAtSaturdayLabel}', when datetime is '2022/12/12 09:00:00' which is just end of opening_soon, and start of opening of the first OH on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/17 10:00:00') // Saturday
      )).toEqual(openingAtSaturdayLabel);
    });
    // 「営業中」の1秒後
    it(`Valid business hours notation must be '${openingAtSaturdayLabel}', when datetime is '2022/12/12 09:00:01' which is 1 sec after start of opening of the first OH on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/17 10:00:01') // Saturday
      )).toEqual(openingAtSaturdayLabel);
    });
    // 「営業中」から「まもなく閉店」へ切り替えの1秒前
    it(`Valid business hours notation must be '${openingAtSaturdayLabel}', when datetime is '2022/12/12 12:39:59' which is 1 sec before closing_soon of the first OH on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/17 18:39:59') // Saturday
      )).toEqual(openingAtSaturdayLabel);
    });
    // 「営業中」から「まもなく閉店」へ切り替え
    it(`Valid business hours notation must be '${closingSoonAtSaturdayLabel}', when datetime is '2022/12/12 21:40:00' which is just start of closing_soon of the second OH on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/17 18:40:00') // Saturday
      )).toEqual(closingSoonAtSaturdayLabel);
    });
    // 「まもなく閉店」の1秒後
    it(`Valid business hours notation must be '${closingSoonAtSaturdayLabel}', when datetime is '2022/12/12 21:40:01' which is 1 sec after start of closing_soon of the second OH on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/17 18:40:01') // Saturday
      )).toEqual(closingSoonAtSaturdayLabel);
    });
    // 「まもなく閉店」から「営業時間外（当日）」の切り替え1秒前
    it(`Valid business hours notation must be '${closingSoonAtSaturdayLabel}', when datetime is '2022/12/12 19:00:00' which is just end of closing_soon of the second OH on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/17 19:00:00') // Monday
      )).toEqual(closingSoonAtSaturdayLabel);
    });
    // 「まもなく閉店」から「営業時間外（当日）」の切り替え
    it(`Valid business hours notation must be '${closingAtMondayLabel}', when datetime is '2022/12/12 19:00:01' which is 1 sec after end of closing_soon of the second OH on Monday`, () => {
      expect(getBusinessHoursLabel(
        mondaySaturdayOH,
        new Date('2022/12/17 19:00:01') // Monday
      )).toEqual(closingAtMondayLabel);
    });
  });

  // Mo-Th 10:00-14:00; 15:00-20:00; Fr 10:00-14:00; 15:00-18:00
  const weekdayOH = 'Mo-Th 10:00-14:00, 15:00-20:00; Fr 10:00-14:00, 15:00-18:00';
  describe(`Business hours notation by the opening_hours '${weekdayOH}'`, () => {
    const openingSoonAtLabel       = 'まもなく開店： 10:00 〜 14:00, 15:00 〜 20:00';
    const openingSoonAtFridayLabel = 'まもなく開店： 10:00 〜 14:00, 15:00 〜 18:00';
    // 「まもなく開店」
    it(`Valid business hours notation must be '${openingSoonAtLabel}', when datetime is '2022/12/13 09:40:00' which is just start of opening_soon of the first OH on Tuesday`, () => {
      expect(getBusinessHoursLabel(
        weekdayOH,
        new Date('2022/12/13 09:40:00') // Tuesday
      )).toEqual(openingSoonAtLabel);
    });
    // 「まもなく開店」の1秒後
    it(`Valid business hours notation must be '${openingSoonAtLabel}', when datetime is '2022/12/13 09:40:01' which is 1 sec after opening_soon of the first OH on Tuesday`, () => {
      expect(getBusinessHoursLabel(
        weekdayOH,
        new Date('2022/12/13 09:40:01') // Tuesday
      )).toEqual(openingSoonAtLabel);
    });
    // 「まもなく開店」
    it(`Valid business hours notation must be '${openingSoonAtLabel}', when datetime is '2022/12/13 14:40:00' which is just start of opening_soon of the second OH on Tuesday`, () => {
      expect(getBusinessHoursLabel(
        weekdayOH,
        new Date('2022/12/13 14:40:00') // Tuesday
      )).toEqual(openingSoonAtLabel);
    });
    // 「まもなく開店」の1秒後
    it(`Valid business hours notation must be '${openingSoonAtLabel}', when datetime is '2022/12/13 14:40:01' which is 1 sec after opening_soon of the second OH on Tuesday`, () => {
      expect(getBusinessHoursLabel(
        weekdayOH,
        new Date('2022/12/13 14:40:01') // Tuesday
      )).toEqual(openingSoonAtLabel);
    });
    // 「まもなく開店」
    it(`Valid business hours notation must be '${openingSoonAtFridayLabel}', when datetime is '2022/12/16 09:40:00' which is just start of opening_soon of the first OH on Friday`, () => {
      expect(getBusinessHoursLabel(
        weekdayOH,
        new Date('2022/12/16 09:40:00') // Friday
      )).toEqual(openingSoonAtFridayLabel);
    });
    // 「まもなく開店」の1秒後
    it(`Valid business hours notation must be '${openingSoonAtFridayLabel}', when datetime is '2022/12/16 09:40:01' which is 1 sec after opening_soon of the first OH on Friday`, () => {
      expect(getBusinessHoursLabel(
        weekdayOH,
        new Date('2022/12/16 09:40:01') // Friday
      )).toEqual(openingSoonAtFridayLabel);
    });
    // 「まもなく開店」
    it(`Valid business hours notation must be '${openingSoonAtFridayLabel}', when datetime is '2022/12/16 14:40:00' which is just start of opening_soon of the second OH on Friday`, () => {
      expect(getBusinessHoursLabel(
        weekdayOH,
        new Date('2022/12/16 14:40:00') // Friday
      )).toEqual(openingSoonAtFridayLabel);
    });
    // 「まもなく開店」の1秒後
    it(`Valid business hours notation must be '${openingSoonAtFridayLabel}', when datetime is '2022/12/16 14:40:01' which is 1 sec after of opening_soon of the second OH on Friday`, () => {
      expect(getBusinessHoursLabel(
        weekdayOH,
        new Date('2022/12/16 14:40:01') // Friday
      )).toEqual(openingSoonAtFridayLabel);
    });
  });

  const closingAfterMidnight20HoursNotationOH = 'Mo 20:00-26:00; Tu 20:00-26:15';
  describe(`Business hours notation by the opening_hours '${closingAfterMidnight20HoursNotationOH}'`, () => {
    const openingSoonAtMondayLabel   = 'まもなく開店： 20:00 〜 02:00';
    const openingSoonAtTuesdayLabel  = 'まもなく開店： 20:00 〜 02:15';
    const closingSoonAtMondayLabel   = 'まもなく閉店： 20:00 〜 02:00';
    const closingSoonAtTuesdayLabel  = 'まもなく閉店： 20:00 〜 02:15';
    const openingAtMondayLabel       = '営業中： 20:00 〜 02:00';
    const openingAtTuesdayLabel      = '営業中： 20:00 〜 02:15';
    const closingTodayAtMondayLabel  = '営業時間外： 営業開始 20:00 〜 02:00';
    const closingTodayAtTuesdayLabel = '営業時間外： 営業開始 20:00 〜 02:15';
    const closingAtMondayLabel       = '営業時間外： 営業開始 月 20:00 〜 02:00';
    const closingAtTuesdayLabel      = '営業時間外： 営業開始 火 20:00 〜 02:15';

    // 「営業時間外（当日）」の1秒前
    it(`Valid business hours notation must be '${closingAtMondayLabel}', when datetime is '2022/12/11 23:59:59' which is 1 sec before midnight on Monday`, () => {
      expect(getBusinessHoursLabel(
        closingAfterMidnight20HoursNotationOH,
        new Date('2022/12/11 23:59:59') // Sunday
      )).toEqual(closingAtMondayLabel);
    });
    // 「営業時間外（当日）」
    it(`Valid business hours notation must be '${closingTodayAtMondayLabel}', when datetime is '2022/12/12 00:00:00' which is just midnight on Monday`, () => {
      expect(getBusinessHoursLabel(
        closingAfterMidnight20HoursNotationOH,
        new Date('2022/12/12 00:00:00') // Monday
      )).toEqual(closingTodayAtMondayLabel);
    });
    // 「営業時間外（当日）」の1秒後
    it(`Valid business hours notation must be '${closingTodayAtMondayLabel}', when datetime is '2022/12/12 00:00:01' which is 1 sec after midnight on Monday`, () => {
      expect(getBusinessHoursLabel(
        closingAfterMidnight20HoursNotationOH,
        new Date('2022/12/12 00:00:01') // Monday
      )).toEqual(closingTodayAtMondayLabel);
    });  
    // 「まもなく開店」の1秒前
    it(`Valid business hours notation must be '${closingTodayAtMondayLabel}', when datetime is '2022/12/12 19:39:59' which is 1 sec before start of opening_soon on Monday`, () => {
      expect(getBusinessHoursLabel(
        closingAfterMidnight20HoursNotationOH,
        new Date('2022/12/12 19:39:59') // Monday
      )).toEqual(closingTodayAtMondayLabel);
    });
    // 「まもなく開店」
    it(`Valid business hours notation must be '${openingSoonAtMondayLabel}', when datetime is '2022/12/12 19:40:00' which is just start of opening_soon on Monday`, () => {
      expect(getBusinessHoursLabel(
        closingAfterMidnight20HoursNotationOH,
        new Date('2022/12/12 19:40:00') // Monday
      )).toEqual(openingSoonAtMondayLabel);
    });
    // 「まもなく開店」の1秒後
    it(`Valid business hours notation must be '${openingSoonAtMondayLabel}', when datetime is '2022/12/12 19:40:01' which is 1 sec after opening_soon on Monday`, () => {
      expect(getBusinessHoursLabel(
        closingAfterMidnight20HoursNotationOH,
        new Date('2022/12/12 19:40:01') // Monday
      )).toEqual(openingSoonAtMondayLabel);
    });
    // 「まもなく開店」から「営業中」へ切り替えの1秒前
    it(`Valid business hours notation must be '${openingSoonAtMondayLabel}', when datetime is '2022/12/12 20:00:00' which is 1 sec before start of opening on Monday`, () => {
      expect(getBusinessHoursLabel(
        closingAfterMidnight20HoursNotationOH,
        new Date('2022/12/12 19:59:59') // Monday
      )).toEqual(openingSoonAtMondayLabel);
    });
    // 「まもなく開店」から「営業中」へ切り替え
    it(`Valid business hours notation must be '${openingAtMondayLabel}', when datetime is '2022/12/12 20:00:00' which is just end of opening_soon, and start of opening on Monday`, () => {
      expect(getBusinessHoursLabel(
        closingAfterMidnight20HoursNotationOH,
        new Date('2022/12/12 20:00:00') // Monday
      )).toEqual(openingAtMondayLabel);
    });
    // 「営業中」の1秒後
    it(`Valid business hours notation must be '${openingAtMondayLabel}', when datetime is '2022/12/12 20:00:01' which is 1 sec after start of opening on Tuesday`, () => {
      expect(getBusinessHoursLabel(
        closingAfterMidnight20HoursNotationOH,
        new Date('2022/12/12 20:00:01') // Monday
      )).toEqual(openingAtMondayLabel);
    });
    // 「営業中」（日を跨ぐ1秒前）
    it(`Valid business hours notation must be '${openingAtMondayLabel}', when datetime is '2022/12/12 23:59:59' which is 1 sec before midnight on Monday`, () => {
      expect(getBusinessHoursLabel(
        closingAfterMidnight20HoursNotationOH,
        new Date('2022/12/12 23:59:59') // Monday
      )).toEqual(openingAtMondayLabel);
    });
    // 「営業中」（ちょうど0時）
    it(`Valid business hours notation must be '${openingAtMondayLabel}', when datetime is '2022/12/13 00:00:00' which is just midnight on Tuesday`, () => {
      expect(getBusinessHoursLabel(
        closingAfterMidnight20HoursNotationOH,
        new Date('2022/12/13 00:00:00') // Tuesday
      )).toEqual(openingAtMondayLabel);
    });
    // 「営業中」（日を跨いだ1秒後）
    it(`Valid business hours notation must be '${openingAtMondayLabel}', when datetime is '2022/12/13 00:00:01' which is 1 sec after midnight on Tuesday`, () => {
      expect(getBusinessHoursLabel(
        closingAfterMidnight20HoursNotationOH,
        new Date('2022/12/13 00:00:01') // Tuesday
      )).toEqual(openingAtMondayLabel);
    });
    // 「営業中」から「まもなく閉店」へ切り替えの1秒前
    it(`Valid business hours notation must be '${openingAtMondayLabel}', when datetime is '2022/12/13 01:39:59' which is 1 sec before start of closing_soon on Monday`, () => {
      expect(getBusinessHoursLabel(
        closingAfterMidnight20HoursNotationOH,
        new Date('2022/12/13 01:39:59') // Tuesday
      )).toEqual(openingAtMondayLabel);
    });
    // 「営業中」から「まもなく閉店」へ切り替え
    it(`Valid business hours notation must be '${closingSoonAtMondayLabel}', when datetime is '2022/12/13 01:40:00' which is just start of closing_soon on Monday`, () => {
      expect(getBusinessHoursLabel(
        closingAfterMidnight20HoursNotationOH,
        new Date('2022/12/13 01:40:00') // Tuesday
      )).toEqual(closingSoonAtMondayLabel);
    });
    // 「まもなく閉店」の1秒後
    it(`Valid business hours notation must be '${closingSoonAtMondayLabel}', when datetime is '2022/12/13 01:40:01' which is 1 sec after closing_soon on Monday`, () => {
      expect(getBusinessHoursLabel(
        closingAfterMidnight20HoursNotationOH,
        new Date('2022/12/13 01:40:01') // Tuesday
      )).toEqual(closingSoonAtMondayLabel);
    });
    // 「まもなく閉店」から「営業時間外（当日）」の切り替え1秒前
    it(`Valid business hours notation must be '${closingSoonAtMondayLabel}', when datetime is '2022/12/13 02:00:00' which is just end of closing_soon on Monday`, () => {
      expect(getBusinessHoursLabel(
        closingAfterMidnight20HoursNotationOH,
        new Date('2022/12/13 02:00:00') // Tuesday
      )).toEqual(closingSoonAtMondayLabel);
    });
    // 「まもなく閉店」から「営業時間外（当日）」の切り替え
    it(`Valid business hours notation must be '${closingTodayAtTuesdayLabel}', when datetime is '2022/12/13 02:00:01' which is 1 sec after end of closing_soon on Monday`, () => {
      expect(getBusinessHoursLabel(
        closingAfterMidnight20HoursNotationOH,
        new Date('2022/12/13 02:00:01') // Tuesday
      )).toEqual(closingTodayAtTuesdayLabel);
    });
    // 「まもなく開店」の1秒前
    it(`Valid business hours notation must be '${closingTodayAtTuesdayLabel}', when datetime is '2022/12/13 19:39:59' which is 1 sec before start of opening_soon on Tuesday`, () => {
      expect(getBusinessHoursLabel(
        closingAfterMidnight20HoursNotationOH,
        new Date('2022/12/13 19:39:59') // Tuesday
      )).toEqual(closingTodayAtTuesdayLabel);
    });
    // 「まもなく開店」
    it(`Valid business hours notation must be '${openingSoonAtTuesdayLabel}', when datetime is '2022/12/13 19:40:00' which is just start of opening_soon on Tuesday`, () => {
      expect(getBusinessHoursLabel(
        closingAfterMidnight20HoursNotationOH,
        new Date('2022/12/13 19:40:00') // Tuesday
      )).toEqual(openingSoonAtTuesdayLabel);
    });
    // 「まもなく開店」の1秒後
    it(`Valid business hours notation must be '${openingSoonAtTuesdayLabel}', when datetime is '2022/12/13 19:40:01' which is 1 sec after opening_soon on Tuesday`, () => {
      expect(getBusinessHoursLabel(
        closingAfterMidnight20HoursNotationOH,
        new Date('2022/12/13 19:40:01') // Tuesday
      )).toEqual(openingSoonAtTuesdayLabel);
    });
    // 「まもなく開店」から「営業中」へ切り替えの1秒前
    it(`Valid business hours notation must be '${openingSoonAtTuesdayLabel}', when datetime is '2022/12/13 19:59:59' which is 1 sec before start of opening on Tuesday`, () => {
      expect(getBusinessHoursLabel(
        closingAfterMidnight20HoursNotationOH,
        new Date('2022/12/13 19:59:59') // Tuesday
      )).toEqual(openingSoonAtTuesdayLabel);
    });
    // 「まもなく開店」から「営業中」へ切り替え
    it(`Valid business hours notation must be '${openingAtTuesdayLabel}', when datetime is '2022/12/13 20:00:00' which is just end of opening_soon, and start of opening on Tuesday`, () => {
      expect(getBusinessHoursLabel(
        closingAfterMidnight20HoursNotationOH,
        new Date('2022/12/13 20:00:00') // Tuesday
      )).toEqual(openingAtTuesdayLabel);
    });
    // 「営業中」の1秒後
    it(`Valid business hours notation must be '${openingAtTuesdayLabel}', when datetime is '2022/12/13 20:00:01' which is 1 sec after opening on Tuesday`, () => {
      expect(getBusinessHoursLabel(
        closingAfterMidnight20HoursNotationOH,
        new Date('2022/12/13 20:00:01') // Monday
      )).toEqual(openingAtTuesdayLabel);
    });
    // 「営業中」（日を跨ぐ1秒前）
    it(`Valid business hours notation must be '${openingAtTuesdayLabel}', when datetime is '2022/12/13 23:59:59' which is 1 sec before midnight on Monday`, () => {
      expect(getBusinessHoursLabel(
        closingAfterMidnight20HoursNotationOH,
        new Date('2022/12/13 23:59:59') // Monday
      )).toEqual(openingAtTuesdayLabel);
    });
    // 「営業中」（ちょうど0時）
    it(`Valid business hours notation must be '${openingAtTuesdayLabel}', when datetime is '2022/12/13 00:00:00' which is just midnight on Tuesday`, () => {
      expect(getBusinessHoursLabel(
        closingAfterMidnight20HoursNotationOH,
        new Date('2022/12/14 00:00:00') // Tuesday
      )).toEqual(openingAtTuesdayLabel);
    });  
    // 「営業中」（日を跨いだ1秒後）
    it(`Valid business hours notation must be '${openingAtTuesdayLabel}', when datetime is '2022/12/14 00:00:01' which is 1 sec after midnight on Tuesday`, () => {
      expect(getBusinessHoursLabel(
        closingAfterMidnight20HoursNotationOH,
        new Date('2022/12/14 00:00:01') // Wednesday
      )).toEqual(openingAtTuesdayLabel);
    });
    // 「営業中」から「まもなく閉店」へ切り替えの1秒前
    it(`Valid business hours notation must be '${openingAtTuesdayLabel}', when datetime is '2022/12/14 01:54:59' which is 1 sec before start of closing_soon on Tuesday`, () => {
      expect(getBusinessHoursLabel(
        closingAfterMidnight20HoursNotationOH,
        new Date('2022/12/14 01:54:59') // Wednesday
      )).toEqual(openingAtTuesdayLabel);
    });
    // 「営業中」から「まもなく閉店」へ切り替え
    it(`Valid business hours notation must be '${closingSoonAtTuesdayLabel}', when datetime is '2022/12/14 01:55:00' which is just start of closing_soon on Tuesday`, () => {
      expect(getBusinessHoursLabel(
        closingAfterMidnight20HoursNotationOH,
        new Date('2022/12/14 01:55:00') // Wednesday
      )).toEqual(closingSoonAtTuesdayLabel);
    });
    // 「まもなく閉店」の1秒後
    it(`Valid business hours notation must be '${closingSoonAtTuesdayLabel}', when datetime is '2022/12/14 01:40:01' which is 1 sec after closing_soon on Tuesday`, () => {
      expect(getBusinessHoursLabel(
        closingAfterMidnight20HoursNotationOH,
        new Date('2022/12/14 01:55:01') // Wednesday
      )).toEqual(closingSoonAtTuesdayLabel);
    });
    // 「まもなく閉店」から「営業時間外（当日）」の切り替え1秒前
    it(`Valid business hours notation must be '${closingSoonAtTuesdayLabel}', when datetime is '2022/12/13 02:15:00' which is just end of closing_soon on Tuesday`, () => {
      expect(getBusinessHoursLabel(
        closingAfterMidnight20HoursNotationOH,
        new Date('2022/12/14 02:15:00') // Wednesday
      )).toEqual(closingSoonAtTuesdayLabel);
    });
    // 「まもなく閉店」から「営業時間外（当日）」の切り替え
    it(`Valid business hours notation must be '${closingAtMondayLabel}', when datetime is '2022/12/13 02:15:01' which is 1 sec after end of closing_soon on Tuesday`, () => {
      expect(getBusinessHoursLabel(
        closingAfterMidnight20HoursNotationOH,
        new Date('2022/12/14 02:15:01') // Wednesday
      )).toEqual(closingAtMondayLabel);
    });
  });


  // Mo-Fr 10:00-20:00; PH off
  // Mo-Fr 10:00-20:00; PH 10:00-12:00'
});
