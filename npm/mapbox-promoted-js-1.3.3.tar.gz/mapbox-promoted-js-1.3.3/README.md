# Mapbox Promoted JS

## Index
- [quick start(EN)](./docs/quick_start.en.md)
- [quick start(JA)](./docs/quick_start.ja.md)
- [how to(EN)](./docs/how_to.en.md)
- [how to(JA)](./docs/how_to.ja.md)
