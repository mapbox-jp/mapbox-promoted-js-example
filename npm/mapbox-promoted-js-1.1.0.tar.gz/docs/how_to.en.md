# Web Promoted SDK 

## Example Project

There is a example project.
You can see how to delivery promoted SDK on the example project.<br />
https://github.com/mapbox-jp/mapbox-promoted-js-example

## Installation

1. You need to delivery two files
* **lib/core/commonjs/index.js** works to handle main logic.
* **lib/app/es/index.js** works to handle web components.

### Delivery by npm

#### Delivery core module from core/commonjs/index.js

1. Add the dependency for **mapbox-promoted-js-VERSION.tar.gz** at your package.json.

```
"dependencies": {
  ...
  "mapbox-gl": "1.13.0",
  "mapbox-promoted-js": "file:FILE_PATH/mapbox-promoted-js-1.0.0.tar.gz",
  "@types/mapbox-promoted-js": "file:FILE_PATH/mapbox-promoted-js-1.0.0.tar.gz",
},
```

2. Install packages by **npm install**

#### Delivery app module from app/es/index.js

1. Extract **mapbox-promoted-js-VERSION.tar.gz**, and put app module that is **lib/app/es/index.js** into as your project file.
2. Below example is put them at **mapbox-promoted-js/app.js** 
3. And insert script tag into html header, to read app.js.

```
<html lang='en'>
  <head>
    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link href='https://api.tiles.mapbox.com/mapbox-gl-js/v2.3.0/mapbox-gl.css' rel='stylesheet'/>
    <script src='/mapbox-promoted-js/app.js'></script>
    <title>
      <%= title %>
    </title>
  </head>
  <body>
    <div id='app'></div>
  </body>
</html>
```

### Delivery by CDN

#### Delivery core module and app module.

1. Extract  **mapbox-promoted-js-VERSION.tar.gz**, and put two files, **lib/app/es/index.js** and **lib/core/browser/index.js** into as your project files.
2. Below example is put them at **mapbox-promoted-js/app.js** and **mapbox-promoted-js/core.js**.
3. And insert script tag into html header, to read app.js and core.js.

```
<html lang='en'>
  <head>
    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link href='https://api.tiles.mapbox.com/mapbox-gl-js/v2.3.0/mapbox-gl.css' rel='stylesheet'/>
    <script src='/mapbox-promoted-js/app.js'></script>
    <script src='/mapbox-promoted-js/core.js'></script>
    <title>
      <%= title %>
    </title>
  </head>
  <body>
    <div id='app'></div>
  </body>
</html>
```


# Documentation on Specification

## Hello World

### Delivery by npm

You can initalize Promoted SDK with Mapbox SDK's instance, and it will show ads on the map view of you application.
It needs ACCESS_TOKEN with initialization.

```
import mapboxgl from 'mapbox-gl';
import { Promoted } from 'mapbox-promoted-js';

const token = 'xxxxxxxxxxxxxxxxxxxxxxxxxxx';
mapboxgl.accessToken = token;
const map = new mapboxgl.Map({
  container: 'app',
  style: 'mapbox://styles/mapbox/streets-v11',
  center: [139.7746987, 35.6272648],
  zoom: 13
});
const promoted = new Promoted(map, token);
```


### Delivery by CDN
```
const token = 'xxxxxxxxxxxxxxxxxxxxxxxxxxx';
window.mapboxgl.accessToken = token;
const map = new window.mapboxgl.Map({
  container: 'app',
  style: 'mapbox://styles/mapbox/streets-v11',
  center: [139.7746987, 35.6272648],
  zoom: 13
});
const promoted = new window.PromotedCore.Promoted(map, token);
```


## Mapbox Promoted API

### Promotion Popup
```
// Show up popup promotion
// It is deprecation to trigger from developer's application
window.showPromotionPopup(
  properties: Feature.Properties,
  onClick?: (type: PromotionPopup.ClickTypes, adid: string) => void,
  onClose?: (adid: string) => void
);

// Close popup promotion
window.closePromotionPopup();
```


## Callback API

You can embed varias type of callback apis like below.

```
promoted.on('load', (type: string, event: any) => console.log(type, event));
```

### Common Event

There are examples of callback api and return values.

```
promoted.on('load', (type: string, event: {
  map: mapboxgl.Map
}) => void);

promoted.on('moveend', (type: string, event: {
  map: mapboxgl.Map,
  originEvent: mapboxgl.MapboxEvent<any>.originalEvent
}) => void);

promoted.on('zoomend', (type: string, event: {
  map: mapboxgl.Map,
  originEvent: mapboxgl.MapboxEvent<any>.originalEvent
}) => void);

promoted.on('sourcedata', (type: string, event: {
  map: mapboxgl.Map,
  originEvent: mapboxgl.MapboxEvent<any>.originalEvent
  tiles: Tile[]
}) => void);

promoted.on('sourcedataend', (type: string, event: {
  map: mapboxgl.Map,
  originEvent: mapboxgl.MapboxEvent<any>.originalEvent
  appearedFeatures: Feature[],
  disappearedFeatures: Feature[]
}) => void);

promoted.on('click_pin', (type: string, event: {
  map: mapboxgl.Map,
  originEvent: mapboxgl.MapboxEvent<any>.originalEvent
  feature: Feature
}) => void);

promoted.on('start_session', (type: string, event: {
  start: Date
}) => void);

promoted.on('update_session', (type: string, event: {
  start: Date
}) => void);

promoted.on('end_session', (type: string, event: {
  start: Date
}) => void);
```


### Promotion Popup Event

```
promoted.on('click_popup', (type: string, event: {
  clickType: 'popup' | 'banner' | 'phone' | 'directions' | 'detail',
  feature: Feature,
}) => void);
promoted.on('show_popup', event: { feature: Feature }) => void);
promoted.on('close_popup', event: { feature: Feature }) => void);
```


## Running by Debug mode

When if you run your application other than production mode, set debug true.
It prevent sending event logs for event log server.

```
const promoted = new MapboxPromoted(
  map,
  MAPBOX_TOKEN,
  {
    debug: true,
  }
);
```


## Connect to another environment

You can change connection environment by setting **baseUrl** and **logUrl** at initialization.
These two params, please ask us.

```
const promoted = new MapboxPromoted(
  map,
  MAPBOX_TOKEN,
  {
    baseUrl: PROMOTED_BASE_URL,
    logUrl: PROMOTED_LOG_URL,
  }
);
```
