declare namespace Feature {
  namespace Properties {
    type BusinessHours = {
      monday?: string;
      tuesday?: string;
      wednesday?: string;
      thursday?: string;
      friday?: string;
      saturday?: string;
      sunday?: string;
    };
  }
  interface Properties {
    auction_id: string;
    feature_id: string;
    cps: string;
    promotion_type?: PromotionTypes;
    icon?: string;
    advertizer?: string;
    category?: string;
    address_ja?: string;
    address_en?: string;
    name_ja?: string;
    name_en?: string;
    subtitle?: string;
    summary?: string;
    phone_number?: string;
    promotion_banner?: string;
    promotion_banner_width?: number;
    promotion_banner_height?: number;
    promotion_card?: string;
    promotion_url?: string;
    directions?: string;
    lat?: string;
    lng?: string;
    min_zoom?: string;
    business_hours?: Properties.BusinessHours;
    remarks?: string;
  }
  const PROMOTION_TYPES: {
    readonly CARD: 'card';
  }
  type PromotionTypes = typeof PROMOTION_TYPES[keyof typeof PROMOTION_TYPES];
}
declare interface Feature extends mapboxgl.MapboxGeoJSONFeature {
  properties: Feature.Properties;
  geometry: GeoJSON.Geometry;
}
declare type FeatureLog = {
  feature: Feature;
  startActionType?: string;
  endActionType?: string;
  startZoomLevel?: number;
  endZoomLevel?: number;
  visibleStartTime?: number;
  visibleEndTime?: number;
}
