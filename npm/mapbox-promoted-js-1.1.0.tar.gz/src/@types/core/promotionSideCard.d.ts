declare namespace Promoted {
  class PromotionSideCard {
    constructor(promoted: Promoted.Core, source: Promoted.Source);
    get feature(): Feature | undefined;
    public show(feature: Feature): void;
    public close(): void;
    public remove(): void;
  }
}
