declare namespace Promoted {
  namespace PromotionPopup {
    type PopupGroup = {
      popup: mapboxgl.Popup;
      sessionId: string;
      feature: Feature;
    };
  }
  class PromotionPopup {
    constructor(promoted: Promoted.Core, source: Promoted.Source);
    public getFeatureByPoints(x: number, y: number): Feature | undefined;
    public generatePopupClassName(feature: Feature): string;
    public show(feature: Feature): void;
    public close(feature: Feature): void;
    public remove(feature: Feature): void;
  }
}
