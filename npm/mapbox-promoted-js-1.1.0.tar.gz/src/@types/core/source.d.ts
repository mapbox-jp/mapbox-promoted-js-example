declare namespace Promoted {
  class Source {
    constructor(map: mapboxgl.Map, token: string);
    get layer(): mapboxgl.AnyLayer;
    get tilesets(): { [quadkey: string]: Feature[] };
    public requestFeatures(quadkeys: string[], event: mapboxgl.MapboxEvent<any> & mapboxgl.EventData): void;
    public addSource(quadkeys: string[]): void;
    public visibleLayer(): void;
    public hideLayer(): void;
    public reload(): void;
    public selectFeature(feature: Feature): void;
    public deselectLayer(): void;
  }
}
