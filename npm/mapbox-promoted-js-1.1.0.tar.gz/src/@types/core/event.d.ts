declare namespace Promoted {
  namespace Event {
    type Listener = (type: EventTypes, event: any) => any;
    type Listeners = { [key: string]: Array<Listener> };
  }

  class Event {
    public on(type: Promoted.EventTypes, listener: Promoted.Event.Listener): void;
    public off(type: Promoted.EventTypes, listener: Promoted.Event.Listener): void;
    public fire(event: EventData): void;
  }  
}
