declare namespace PromotionSideCard {
  const CLICK_TYPES: {
    readonly ADS: 'Ads';
    readonly CARD: 'Card';
    readonly BANNER: 'BannerDetail';
    readonly SUMMARY: 'Summary';
    readonly ADDRESS: 'Address';
    readonly BUSINESS_HOURS: 'BusinessHours';
    readonly CALL: 'Call';
    readonly ROUTE: 'Route';
    readonly DETAIL: 'Detail';
    readonly TAB: 'Tab';
    readonly TOGGLE: 'Toggle';
  };
  export type ClickTypes = typeof CLICK_TYPES[keyof typeof CLICK_TYPES];
}

declare var showPromotionSideCard: ((
  feature: Feature,
  onClick?: (type: PromotionSideCard.ClickTypes, feature: Feature) => void,
  onClose?: (feature: Feature) => void,
  onOpen?: (feature: Feature) => void,
  onHide?: (feature: Feature) => void,
) => void) | undefined;
declare var updatePromotionSideCard: ((feature: Feature) => void) | undefined;
declare var openPromotionSideCard: (() => void) | undefined;
declare var hidePromotionSideCard: (() => void) | undefined;
declare var closePromotionSideCard: (() => void) | undefined;
