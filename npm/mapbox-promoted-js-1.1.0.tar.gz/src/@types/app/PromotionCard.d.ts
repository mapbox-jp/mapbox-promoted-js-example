declare namespace PromotionCard {
  const CLICK_TYPES: {
    readonly ADS: 'Ads';
    readonly CARD: 'Card';
    readonly BANNER: 'BannerDetail';
    readonly SUMMARY: 'Summary';
    readonly ADDRESS: 'Address';
    readonly BUSINESS_HOURS: 'BusinessHours';
    readonly CALL: 'Call';
    readonly ROUTE: 'Route';
    readonly LINE: 'Line';
    readonly INSTAGRAM: 'Instagram';
    readonly FACEBOOK: 'Facebook';
    readonly TWITTER: 'Twitter';
    readonly APP_STORE: 'AppStore';
    readonly PLAY_STORE: 'PlayStore';
    readonly DETAIL: 'Detail';
    readonly TAB: 'Tab';
  };
  export type ClickTypes = typeof CLICK_TYPES[keyof typeof CLICK_TYPES];
}

declare var showPromotionCard: ((
  feature: Feature,
  onClick?: (type: PromotionCard.ClickTypes, feature: Feature) => void,
  onClose?: (feature: Feature) => void
) => void) | undefined;
declare var updatePromotionCard: ((feature: Feature) => void) | undefined;
declare var closePromotionCard: (() => void) | undefined;
