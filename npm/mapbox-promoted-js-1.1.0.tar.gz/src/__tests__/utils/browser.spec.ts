import {
  isSp,
  isSmall,
  isMedium,
  insertEndpointElement,
  updateEndpointElement,
  removeEndpointElement,
} from 'utils/browser';

describe('utils/browser.isSp', () => {
  const setWindow = (width: number) => {
    Object.defineProperty(window, 'innerWidth', {
      writable: true,
      configurable: true,
      value: width,
    });
    window.dispatchEvent(new Event('resize'));
  };

  it('isSp = true when if window width is 320px', () => {
    setWindow(320);
    expect(isSp()).toEqual(true);
  });

  it('isSp = true when if window width is 768px', () => {
    setWindow(768);
    expect(isSp()).toEqual(true);
  });

  it('isSp = true when if window width is 769px', () => {
    setWindow(769);
    expect(isSp()).toEqual(false);
  });

  it('isSp = false when if window width is 1024px', () => {
    setWindow(1024);
    expect(isSp()).toEqual(false);
  });
});

describe('utils/browser.isSmall', () => {
  const setWindow = (width: number) => {
    Object.defineProperty(window, 'innerWidth', {
      writable: true,
      configurable: true,
      value: width,
    });
    window.dispatchEvent(new Event('resize'));
  };

  it('isSmall = true when if window width is 320px', () => {
    setWindow(320);
    expect(isSmall()).toEqual(true);
  });

  it('isSmall = true when if window width is 640px', () => {
    setWindow(640);
    expect(isSmall()).toEqual(true);
  });

  it('isSmall = true when if window width is 641px', () => {
    setWindow(641);
    expect(isSmall()).toEqual(false);
  });

  it('isSmall = false when if window width is 1024px', () => {
    setWindow(1024);
    expect(isSmall()).toEqual(false);
  });
});

describe('utils/browser.isMedium', () => {
  const setWindow = (width: number) => {
    Object.defineProperty(window, 'innerWidth', {
      writable: true,
      configurable: true,
      value: width,
    });
    window.dispatchEvent(new Event('resize'));
  };

  it('isMedium = false when if window width is 320px', () => {
    setWindow(320);
    expect(isMedium()).toEqual(false);
  });

  it('isMedium = false when if window width is 640px', () => {
    setWindow(640);
    expect(isMedium()).toEqual(false);
  });

  it('isMedium = true when if window width is 641px', () => {
    setWindow(641);
    expect(isMedium()).toEqual(true);
  });

  it('isMedium = false when if window width is 768px', () => {
    setWindow(768);
    expect(isMedium()).toEqual(true);
  });

  it('isMedium = false when if window width is 769px', () => {
    setWindow(769);
    expect(isMedium()).toEqual(false);
  });

  it('isMedium = false when if window width is 1024px', () => {
    setWindow(1024);
    expect(isMedium()).toEqual(false);
  });
});

describe('utils/browser.insertEndpointElement', () => {
  afterEach(() => {
    document.getElementsByTagName('html')[0].innerHTML = ''; 
  });

  const setMapboxElement = () => {
    const mapboxElement = document.createElement('div');
    mapboxElement.className = 'mapboxgl-map';
    document.body.appendChild(mapboxElement);
  };

  it('Confirm there is not test element', () => {
    setMapboxElement();
    expect(document.querySelector('.test')).toBeNull();
  });

  it('Scucess to insert endpoint element', () => {
    setMapboxElement();
    insertEndpointElement('test');
    expect(document.querySelector('.test')).toBeDefined();
  });

  it('Throw error to insert endpoint element', () => {
    expect(() => {
      insertEndpointElement('test');
    }).toThrow(new Error('Filed to find element: .mapboxgl-map'));
  });
});

describe('utils/browser.updateEndpointElement', () => {
  afterEach(() => {
    document.getElementsByTagName('html')[0].innerHTML = ''; 
  });

  const setMapboxElement = () => {
    const mapboxElement = document.createElement('div');
    mapboxElement.className = 'mapboxgl-map';
    document.body.appendChild(mapboxElement);
    const testElement = document.createElement('div');
    testElement.className = 'test';
    mapboxElement.appendChild(testElement);
  };

  it('Confirm test element is created', () => {
    setMapboxElement();
    expect(document.querySelector('.test')).toBeDefined();
  });

  it('Scucess to update endpoint element', () => {
    setMapboxElement();
    updateEndpointElement('.test', 'update-test');
    expect(document.querySelector('.update-test')).toBeDefined();
  });

  it('Throw error to update endpoint element', () => {
    expect(() => {
      updateEndpointElement('.test', 'update-test');
    }).toThrow(new Error('Filed to find element: .test'));
  });
});

describe('utils/browser.removeEndpointElement', () => {
  afterEach(() => {
    document.getElementsByTagName('html')[0].innerHTML = ''; 
  });

  const setMapboxElement = () => {
    const mapboxElement = document.createElement('div');
    mapboxElement.className = 'mapboxgl-map';
    document.body.appendChild(mapboxElement);
    const testElement = document.createElement('div');
    testElement.className = 'test';
    mapboxElement.appendChild(testElement);
  };

  it('Confirm test element is created', () => {
    setMapboxElement();
    expect(document.querySelector('.test')).toBeDefined();
  });

  it('Scucess to remove endpoint element', () => {
    setMapboxElement();
    removeEndpointElement('.test');
    expect(document.querySelector('.test')).toBeDefined();
  });

  it('Throw error to remove endpoint element', () => {
    expect(() => {
      removeEndpointElement('.test');
    }).toThrow(new Error('Filed to find element: .test'));
  });
});
