import styled from 'styled-components';

export const Container = styled.div`
  position: relative;
  margin-top: 15px;
`;
export const Title = styled.div``;
export const TitleLabel = styled.h1`
  margin: 0;
  display: -webkit-box;
  width: calc(100% - 36px - 10px);
  max-height: 20px;
  font-size: 15px;
  font-weight: 600;
  overflow: hidden;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
`;
export const PromotionTagWrapper = styled.div`
  position: absolute;
  top: 0;
  right: 0;
`;
export const Category = styled.div`
  display: -webkit-box;
  margin-top: 5px;
  font-size: 12px;
  line-height: 1.8;
  color: #9f9f9f;
  overflow: hidden;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
`;
export const Remarks = styled.div`
  display: -webkit-box;
  font-size: 12px;
  line-height: 1.8;
  color: #ff4343;
  overflow: hidden;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
`;
