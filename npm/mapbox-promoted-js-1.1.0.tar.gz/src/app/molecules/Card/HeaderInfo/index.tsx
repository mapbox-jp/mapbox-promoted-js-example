import React from 'react';
// Components
import PromotionTag from 'atoms/PromotionTag';
import {
  Container,
  Title,
  TitleLabel,
  PromotionTagWrapper,
  Category,
  Remarks,
} from './styles';
import { CLICK_TYPES } from '../helpers';

type Props = {
  classPrefix?: string;
  feature: Feature;
  onClick: (type: PromotionPopup.ClickTypes, feature: Feature) => void;
};

const HeaderInfo: React.FC<Props> = props => {
  const { classPrefix, feature, onClick } = props;
  const { name_ja, category, remarks } = feature.properties;
  const PREFIX_CLASSNAME = `${classPrefix}__header-info`;

  const handleClick = (type: PromotionPopup.ClickTypes) => {
    onClick(type, feature);
  };
  return (
    <Container className={PREFIX_CLASSNAME}>
      {name_ja ? (
        <Title className={`${PREFIX_CLASSNAME}__title`}>
          <TitleLabel className={`${PREFIX_CLASSNAME}__title-label`}>
            {name_ja || ''}
          </TitleLabel>
          <PromotionTagWrapper className={`${PREFIX_CLASSNAME}__promotion-tag-wrapper`}>
            <PromotionTag
              classPrefix={`${PREFIX_CLASSNAME}__`}
              onClick={() => handleClick(CLICK_TYPES.ADS)}
            />
          </PromotionTagWrapper>
        </Title>
      ) : null}
      {category ? (
        <Category className={`${PREFIX_CLASSNAME}__category`}>
          {category.split(',').join(', ')}
        </Category>
      ) : null}
      {remarks ? (
        <Remarks className={`${PREFIX_CLASSNAME}__remarks`}>
          {remarks}
        </Remarks>
      ) : null}
    </Container>
  );
};

export default HeaderInfo;
