import styled from 'styled-components';

type OpenerIcon = {
  isOpening?: boolean;
};
type Opener = {
  isOpening?: boolean;
  height?: number;
};
type Label = {
  lineClamp?: number;
};

export const Container = styled.ul``;
export const Row = styled.li`
  position: relative;
  padding: 10px 0;
  cursor: pointer;
  & + & {
    :before {
      content: "";
      position: absolute;
      display: block;
      top: 0;
      width: 100%;
      border-top: 1px solid #e8eaed;
    }
  }
`;
export const Title = styled.span`
  padding: 0 4px;
  font-weight: 600;
  font-size: 12px;
`;
export const OpenerIcon = styled.div`
  position: absolute;
  display: flex;
  justify-content: center;
  align-items: center;
  margin-left: 5px;
  padding: 2px;
  right: 0;
  width: 12px;
  min-width: 12px;
  height: 12px;
  min-height: 12px;
  font-size: 12px;
  color: #8d8d8d;
  transition: transform 0.2s;
  transform: rotate(${({ isOpening }: OpenerIcon) => isOpening ? '180' : '0'}deg);
`;
export const Opener = styled.div`
  overflow: hidden;
  height: ${({ isOpening, height }: Opener) => isOpening ? `${height}px` : '0'};
  transition: height 0.2s;
`;
export const BusinessHoursWrapper = styled.div`
  padding: 0 0 0 23px;
`;
export const Value = styled.div`
  position: relative;
  display: flex;
  align-items: center;
  padding: 0 4px;
  background-color: transparent;
  transition: background-color 0.1s;
`;
export const Label = styled.span`
  display: -webkit-box;
  overflow: hidden;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: ${({ lineClamp }: Label) => lineClamp || 1};
`;
