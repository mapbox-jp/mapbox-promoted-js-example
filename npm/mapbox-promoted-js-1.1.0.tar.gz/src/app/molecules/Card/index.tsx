import React, { useMemo } from 'react';
import { DEFAULT_BANNER_SIZE } from 'utils/config';
import { isPc } from 'utils/browser';
// Components
import HeaderInfo from './HeaderInfo';
// import Tabs, { Tab } from './Tabs';
import Actions from './Actions';
import Summary from './Summary';
// import Info from './Info';
import {
  GlobalStyle,
  Container,
  Header,
  Banner,
  BannerImg,
  Wrapper,
  Content,
} from './styles';
import { CLICK_TYPES, ClickTypes/*, TAB_TYPES, TabTypes*/ } from './helpers';

type Props = {
  classPrefix?: string;
  feature: Feature;
  height?: string;
  isSmall?: boolean;
  isFadeout?: boolean;
  isRendered?: boolean;
  onClick: (
    type: ClickTypes,
    feature: Feature
  ) => void;
};

const Card = React.forwardRef<HTMLDivElement, Props>((props, ref) => {
  const { classPrefix, feature, height, isSmall, onClick } = props;
  const { properties } = feature;
  const { promotion_banner } = properties;

  // const [selectedTab, setSelectedTab] = useState<TabTypes>(TAB_TYPES.SUMARRY);
  const bannerSize = useMemo(() => {
    const { promotion_banner_width, promotion_banner_height } = properties;
    return {
      width: promotion_banner_width || DEFAULT_BANNER_SIZE.WIDTH,
      height: promotion_banner_height || DEFAULT_BANNER_SIZE.HEIGHT,
    };
  }, [properties]);
  const isVertical = useMemo(() => isPc() && !isSmall, [document.body.clientWidth]);

  // const handleClickTab = (type: TabTypes) => {
  //   setSelectedTab(type);
  //   handleClick(CLICK_TYPES.TAB);
  // };
  const handleClick = (type: PromotionPopup.ClickTypes) => {
    onClick && onClick(type, feature);
  };
  const renderContent = () => {
    return (
      <Summary
        classPrefix={classPrefix}
        feature={feature}
        onClick={handleClick}
      />
    );
    // switch (selectedTab) {
    //   case TAB_TYPES.SUMARRY:
    //     return (
    //       <Summary
    //         classPrefix={classPrefix}
    //         feature={feature}
    //         onClick={handleClick}
    //       />
    //     );
    //   // case TAB_TYPES.NEWS:
    //   //   return <News />;
    //   // case TAB_TYPES.MENU:
    //   //   return <Menu />;
    //   // case TAB_TYPES.PHOTOS:
    //   //   return <Photos />;
    //   case TAB_TYPES.INFO:
    //     return (
    //       <Info
    //         classPrefix={classPrefix}
    //         feature={feature}
    //         onClick={handleClick}
    //       />
    //     );
    //   default:
    //     return null;
    // }
  };
  return (
    <>
      <GlobalStyle />
      <Container
        className={classPrefix}
        height={height}
        onClick={() => handleClick(CLICK_TYPES.CARD)}
        ref={ref}
      >
        <Header
          className={`${classPrefix}__header`}
          isVertical={isVertical}
        >
          <Banner
            className={`${classPrefix}__banner`}
            onClick={() => handleClick(CLICK_TYPES.BANNER)}
          >
            <BannerImg
              className={`${classPrefix}__banner-img`}
              src={promotion_banner}
              width={bannerSize.width}
              height={bannerSize.height}
            />
          </Banner>
          <HeaderInfo
            classPrefix={classPrefix}
            feature={feature}
            onClick={handleClick}
          />
          <Actions
            classPrefix={classPrefix}
            feature={feature}
            isSmall={isSmall}
            onClick={handleClick}
          />
        </Header>
        {!isSmall && (
          <Wrapper className={`${classPrefix}__wrapper`}>
            {/* <Tabs classPrefix={classPrefix}>
              <Tab
                classPrefix={classPrefix}
                label="概要"
                isSelected={selectedTab === TAB_TYPES.SUMARRY}
                onClick={() => handleClickTab(TAB_TYPES.SUMARRY)}
              />
              <Tab
                label="最新情報"
                isSelected={selectedTab === TAB_TYPES.NEWS}
                onClick={() => handleClickTab(TAB_TYPES.NEWS)}
              />
              <Tab
                label="メニュー"
                isSelected={selectedTab === TAB_TYPES.MENU}
                onClick={() => handleClickTab(TAB_TYPES.MENU)}
              />
              <Tab
                label="写真"
                isSelected={selectedTab === TAB_TYPES.PHOTOS}
                onClick={() => handleClickTab(TAB_TYPES.PHOTOS)}
              />
              <Tab
                classPrefix={classPrefix}
                label="情報"
                isSelected={selectedTab === TAB_TYPES.INFO}
                onClick={() => handleClickTab(TAB_TYPES.INFO)}
              />
            </Tabs> */}
            <Content className={`${classPrefix}__content`}>
              {renderContent()}
            </Content>
          </Wrapper>
        )}
      </Container>
    </>
  );
});

export default Card;
