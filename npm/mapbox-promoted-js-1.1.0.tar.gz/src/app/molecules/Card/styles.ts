import styled, { createGlobalStyle } from 'styled-components';
import { CONFIG } from 'utils/config';

type Container = {
  height?: string;
};
type Banner = {
  height: number;
};
type Header = {
  isVertical?: boolean;
};

export const GlobalStyle = createGlobalStyle`
  .promotion-popup {
    &-card {
      @media screen and (max-width: ${CONFIG.SMALL_MAX_WIDTH}px) {
        zoom: 80%;
      }
      @media screen and (min-width: ${CONFIG.SMALL_MAX_WIDTH}px) and (max-width: ${CONFIG.MEDIUM_MAX_WIDTH}px) {
        zoom: 90%;
      }
      @media screen and (min-width: ${CONFIG.LARGE_MAX_WIDTH}px) {
        
      }
    }
  }
`;
export const Container = styled.div`
  height: ${({ height }: Container) => height || '100%'};
  background-color: rgb(255, 255, 255);
`;
export const Header = styled.div`
  padding-bottom: ${({ isVertical }: Header) => isVertical ? '74px' : '40px'};
`;
export const Banner = styled.div.attrs(({ height }: Banner) => ({ height }))`
  background-color: rgb(142, 142, 142);
  border-radius: 4px;
  overflow: hidden;
`;
export const BannerImg = styled.img`
  width: 100%;
  height: auto;
  object-fit: cover;
`;
export const Wrapper = styled.div`
  // margin-top: 12px;
  width: 100%;
`;
export const Content = styled.div`
  // padding-top: 29px;
`;
