export const CLICK_TYPES = {
  ADS: 'Ads',
  CARD: 'Card',
  BANNER: 'BannerDetail',
  SUMMARY: 'Summary',
  ADDRESS: 'Address',
  BUSINESS_HOURS: 'BusinessHours',
  CALL: 'Call',
  ROUTE: 'Route',
  DETAIL: 'Detail',
  TAB: 'Tab',
} as const;

export type ClickTypes = typeof CLICK_TYPES[keyof typeof CLICK_TYPES];

export const TAB_TYPES = {
  SUMARRY: 'card-tab-sumarry',
  NEWS: 'card-tab-news',
  MENU: 'card-tab-menu',
  PHOTOS: 'card-tab-photos',
  INFO: 'card-tab-info',
} as const;

export type TabTypes = typeof TAB_TYPES[keyof typeof TAB_TYPES];
