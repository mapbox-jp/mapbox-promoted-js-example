import React, { useMemo } from 'react';
import { isPc } from 'utils/browser';
// Components
import ActionItem from './Item';
import { Container } from './styles';
import { ACTION_TYPES, ACTIONS, ActionTypes } from './helpers';

type Props = {
  classPrefix?: string;
  feature: Feature;
  isSmall?: boolean;
  onClick: (type: PromotionPopup.ClickTypes) => void;
};

const Actions: React.FC<Props> = props => {
  const { classPrefix, feature, isSmall, onClick } = props;
  const { properties } = feature;
  const PREFIX_CLASSNAME = `${classPrefix}__actions`;

  const isVertical = useMemo(() => isPc() && !isSmall, [document.body.clientWidth]);

  const keys = Object.keys(ACTION_TYPES) as ActionTypes[];
  const handleClick = (type: PromotionPopup.ClickTypes) => {
    onClick(type);
  };
  return (
    <Container
      className={PREFIX_CLASSNAME}
      isVertical={isVertical}
    >
      {keys.map(key => {
        const type: ActionTypes = (ACTION_TYPES as any)[key];
        const action = ACTIONS[type];
        const value = (properties as any)[action.key];
        return value || action.isRequired ? (
          <ActionItem
            classPrefix={classPrefix}
            type={type}
            feature={feature}
            isSmall={isSmall}
            onClick={handleClick}
            key={`${PREFIX_CLASSNAME}-${type}`}
          />
        ) : null;
      })}
    </Container>
  );
};

export default Actions;
