import { ICON_TYPE } from 'atoms/Icon';
import { CLICK_TYPES } from '../helpers';

export const ACTION_TYPES = {
  ROUTE: 'action-type-route',
  PHONE_NUMBER: 'action-type-phone-number',
  PROMOTION_URL: 'action-type-promotion-url',
} as const;

export type ActionTypes = typeof ACTION_TYPES[keyof typeof ACTION_TYPES];

type Actions = {
  [key in ActionTypes]: {
    key: string;
    classKey: string;
    iconType: string;
    clickType?: PromotionPopup.ClickTypes;
    label?: string;
    isRequired?: boolean;
  };
};

export const ACTIONS: Actions = {
  [ACTION_TYPES.ROUTE]: {
    key: 'route',
    classKey: 'route',
    iconType: ICON_TYPE.ROUTE,
    clickType: CLICK_TYPES.ROUTE,
    label: '経路',
    isRequired: true,
  },
  [ACTION_TYPES.PROMOTION_URL]: {
    key: 'promotion_url',
    classKey: 'promotion-url',
    iconType: ICON_TYPE.EARTH,
    clickType: CLICK_TYPES.DETAIL,
    label: '公式サイト',
  },
  [ACTION_TYPES.PHONE_NUMBER]: {
    key: 'phone_number',
    classKey: 'phone-number',
    iconType: ICON_TYPE.PHONE,
    clickType: CLICK_TYPES.CALL,
    label: '電話',
  },
};
