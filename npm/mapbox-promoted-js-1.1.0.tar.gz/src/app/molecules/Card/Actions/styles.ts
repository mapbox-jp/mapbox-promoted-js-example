import styled from 'styled-components';

type Container = {
  isVertical?: boolean;
};

export const Container = styled.ul`
  display: flex;
  position: absolute;
  margin: ${({ isVertical }: Container) => isVertical ? '14px 0 0 0' : '8px 0 0 0'};
  padding: 0;
  left: 0;
  width: 100%;
  overflow-x: scroll;
  list-style: none;
`;
