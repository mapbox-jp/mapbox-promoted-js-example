import React, { useMemo } from 'react';
import { isPc } from 'utils/browser';
// Components
import Icon from 'atoms/Icon';
import { ACTION_TYPES, ACTIONS, ActionTypes } from '../helpers';
import {
  createItemGlobalStyle,
  Container,
  ItemButton,
  ItemAnchor,
  ItemIcon,
  ItemLabel,
} from './styles';

type Props = {
  classPrefix?: string;
  type: ActionTypes;
  feature: Feature;
  isSmall?: boolean;
  onClick: (type: PromotionPopup.ClickTypes) => void;
};

const Item: React.FC<Props> = props => {
  const { classPrefix, type, feature, isSmall, onClick } = props;
  const { properties } = feature;
  const PREFIX_CLASSNAME = `${classPrefix}__actions-item`;

  const GlobalStyle = useMemo(() => {
    return createItemGlobalStyle(PREFIX_CLASSNAME);
  }, [PREFIX_CLASSNAME]);
  const isVertical = useMemo(() => isPc() && !isSmall, [document.body.clientWidth]);
  const action = ACTIONS[type];
  const { key, classKey, iconType, clickType } = action;
  const value = (properties as any)[key];
  const label = action.label || value;
  const handleClick = (type: PromotionPopup.ClickTypes) => {
    onClick(type);
  };
  const renderContent = (iconType: string, label: string) => (
    <>
      <ItemIcon className={`${PREFIX_CLASSNAME}__icon`}>
        <Icon type={iconType} />
      </ItemIcon>
      {isSmall || !isPc() ? (
        <ItemLabel
          className={`${PREFIX_CLASSNAME}__label`}
          isSmall={isSmall}
        >
          {label}
        </ItemLabel>
      ) : null}
    </>
  );
  return (
    <>
      <GlobalStyle />
      <Container
        className={`${PREFIX_CLASSNAME} ${PREFIX_CLASSNAME}-${classKey}`}
        isVertical={isVertical}
        onClick={() => clickType && handleClick(clickType)}
      >
        {type === ACTION_TYPES.PROMOTION_URL ? (
          <ItemAnchor
            className={`${PREFIX_CLASSNAME}__anchor`}
            isVertical={isVertical}
            href={value}
            target='_break'
          >
            {renderContent(iconType, label)}
          </ItemAnchor>
        ) : (
          <ItemButton
            className={`${PREFIX_CLASSNAME}__button`}
            isVertical={isVertical}
          >
            {renderContent(iconType, label)}
          </ItemButton>
        )}
        {!isSmall && isPc() && (
          <ItemLabel
            className={`${PREFIX_CLASSNAME}__label`}
            isVertical={isVertical}
            isSmall={isSmall}
          >
            {label}
          </ItemLabel>
        )}
      </Container>
    </>
  );
};

export default Item;
