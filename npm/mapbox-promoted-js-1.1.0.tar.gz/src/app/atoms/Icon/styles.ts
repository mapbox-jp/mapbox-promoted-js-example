import styled from 'styled-components';

type Container = {
  size?: string
  color?: string
  margin?: string
}

export const Container = styled.i`
  display: inline-block;
  margin: ${({ margin }: Container) => margin || '0'};
  font-size: ${({ size }: Container) => size || null};
  color: ${({ color }: Container) => color || null};
`;
