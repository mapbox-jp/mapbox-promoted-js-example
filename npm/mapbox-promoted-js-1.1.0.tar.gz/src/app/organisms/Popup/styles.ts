import styled, { keyframes, createGlobalStyle } from 'styled-components';

type Container = {
  isPopup?: boolean;
  isFadeout?: boolean;
  isRendered?: boolean;
};

const bounceIn = keyframes`
  from {
    opacity: 0.0;
    transform: scale3d(0.3, 0.3, 0.3);
    -webkit-transform: scale3d(0.3, 0.3, 0.3);
    -ms-transform: scale3d(0.3, 0.3, 0.3);
  }
  to {
    opacity: 1.0;
    transform: scale3d(1.0, 1.0, 1.0);
    -webkit-transform: scale3d(1.0, 1.0, 1.0);
    -ms-transform: scale3d(1.0, 1.0, 1.0);
  }
`;
const bounceOut = keyframes`
  from {
    opacity: 1.0;
    transform: scale3d(1.0, 1.0, 1.0);
    -webkit-transform: scale3d(1.0, 1.0, 1.0);
    -ms-transform: scale3d(1.0, 1.0, 1.0);
  }
  to {
    opacity: 0.0;
    transform: scale3d(0.3, 0.3, 0.3);
    -webkit-transform: scale3d(0.3, 0.3, 0.3);
    -ms-transform: scale3d(0.3, 0.3, 0.3);
  }
`;

export const GlobalStyle = createGlobalStyle`
  .mapbox-promoted-popup {
    max-width: none !important;

    & > .mapboxgl-popup-tip {
      display: none;
    }
    & > .mapboxgl-popup-content {
      padding: 0;
      background-color: transparent;
      box-shadow: none;
    }
  }
`;
export const Container = styled.div`
  position: absolute;
  padding: 8px;
  top: 0;
  left: 0;
  width: calc(280px + 8px + 8px);
  background-color: rgb(255, 255, 255);
  border-radius: 5px;
  visibility: ${({ isRendered }: Container) => isRendered ? 'visible' : 'hidden'};
  box-shadow: 0 0 5px rgba(0, 0, 0, 0.3);
  overflow: hidden;
  animation-duration: 0.2s;
  animation-name: ${({ isRendered, isFadeout }: Container) => !isRendered ? 'none' : isFadeout ? bounceOut : bounceIn};
`;
