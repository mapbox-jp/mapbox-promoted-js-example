import openingHours from 'opening_hours';
import { getDay, format, startOfWeek, endOfWeek } from 'date-fns';

export const isUrl = (string: string): boolean => !!string.match(/https?:\/\//);

export const DAYS = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
export const DAY_PAIRS = {
  mon: '月曜日',
  tue: '火曜日',
  wed: '水曜日',
  thu: '木曜日',
  fri: '金曜日',
  sat: '土曜日',
  sun: '日曜日',
};

export const parseBusinessHours = (businessHoursString: string, date: Date = new Date()) => {
  const startDateOfWeek = startOfWeek(date);
  const endDateOfWeek = endOfWeek(date);
  const oh = new openingHours(businessHoursString);
  const intervals = oh.getOpenIntervals(startDateOfWeek, endDateOfWeek);
  let businessHours: { [key: string]: string[] } = {};
  for (const interval of intervals) {
    const openHour = interval[0];
    const closeHour = interval[1];
    const dayNo = getDay(openHour);
    const day = DAYS[dayNo];
    const openCloseHour = `${format(openHour, 'HH:mm')} ~ ${format(closeHour, 'HH:mm')}`;
    if (day in businessHours) {
      businessHours[day].push(openCloseHour);
    } else {
      businessHours[day] = [openCloseHour];
    }
  }
  return businessHours;
};
