import mapboxgl from 'mapbox-gl';
import { CONFIG, sourceId, layerId } from 'utils/config';
import { quadkeyToTile } from 'utils/geometry';
import { isSmall } from 'utils/browser';
import PromotionPopup from './promotionPopup';
import PromotionCard from './promotionCard';
import PromotionSideCard from './promotionSideCard';
import Event from './event';
import Source from './source';
import Session from './session';
import EventAction from './eventAction';
import Logger from './logger';

class Promoted extends Event implements Promoted.Core {
  private _map: mapboxgl.Map;
  private _source: Promoted.Source;
  private _session: Promoted.Session;
  private _eventAction: Promoted.EventAction;
  private _logger: Promoted.Logger;
  private _isDarkMode: boolean;
  private _promotionPopup: Promoted.PromotionPopup;
  private _promotionCard: Promoted.PromotionCard;
  private _promotionSideCard: Promoted.PromotionSideCard;

  constructor(map: mapboxgl.Map, token: string, options: Promoted.Core.Options = {}) {
    super();

    CONFIG.ACCESS_TOKEN = token;

    const {
      baseUrl,
      logUrl,
      isDarkMode,
      debug,
    } = options;

    baseUrl && (CONFIG.BASE_URL = baseUrl);
    logUrl && (CONFIG.LOG_URL = logUrl);
    debug && (this.debug = debug);

    this._map = map;
    this._isDarkMode = isDarkMode || false;

    this._logger = new Logger();
    this._session = new Session(this, this._logger);
    this._eventAction = new EventAction(map, this, this._session, this._logger);
    this._source = new Source(map, this, this._eventAction, this._logger);
    this._eventAction.source = this._source;

    this._promotionPopup = new PromotionPopup(this, this._session, this._source, this._logger);
    this._promotionCard = new PromotionCard(this, this._session, this._source, this._logger);
    this._promotionSideCard = new PromotionSideCard(this, this._session, this._source, this._logger);
  }

  get map() {
    return this._map;
  }

  get isDarkMode() {
    return this._isDarkMode;
  }

  set isDarkMode(isDarkMode: boolean) {
    this._isDarkMode = isDarkMode;
  }

  set debug(debug: boolean) {
    CONFIG.DEBUG = debug;
  }

  get sourceId(): string {
    return sourceId;
  }

  get layerId() : string {
    return layerId;
  }

  get tiles(): Promoted.Tile[] {
    const quadkeies = Object.keys(this._source.tilesets);
    const tiles = [];
    for (const quadkey of quadkeies) {
      tiles.push({
        ...quadkeyToTile(quadkey),
        quadkey
      });
    }
    return tiles;
  }

  get tilesets(): { [quadkey: string]: Feature[] } {
    return this._source.tilesets;
  }

  get features(): Feature[] {
    return this._map.querySourceFeatures(this.sourceId) as Feature[];
  }

  get renderedFeatures(): Feature[] {
    const featureDictionaries = this._eventAction.getPromotionFeatures();
    return Object.values(featureDictionaries);
  }

  get promotionPopup(): Promoted.PromotionPopup {
    return this._promotionPopup;
  }

  get promotionCard(): Promoted.PromotionCard {
    return this._promotionCard;
  }

  get promotionSideCard(): Promoted.PromotionSideCard {
    return this._promotionSideCard;
  }

  public show(feature: Feature) {
    if (isSmall()) {
      this._promotionCard.show(feature);
    } else {
      this._promotionSideCard.show(feature);
    }
  }

  public visibleLayer() {
    this._source.visibleLayer();
  }

  public hideLayer() {
    this._source.hideLayer();
  }

  public reload() {
    this._source.reload();
  }
}

export default Promoted;
