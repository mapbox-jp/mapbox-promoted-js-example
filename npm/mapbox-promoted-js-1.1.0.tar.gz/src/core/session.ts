import { v4 as uuidv4 } from 'uuid';
import EventData from './eventData';
import { EVENT_TYPES } from './helpers';

const SESSION_INTERVAL = 60 * 1000;

class Session implements Promoted.Session {
  private _promoted: Promoted.Core;
  private _logger: Promoted.Logger;
  private _start = new Date();
  private _sessionId = '';
  private _timerId = -1;
  private _sessoinEndCallback?: () => void;

  constructor(promoted: Promoted.Core, logger: Promoted.Logger) {
    this._promoted = promoted;
    this._logger = logger;
  }

  set sessoinEndCallback(callback: () => void) {
    this._sessoinEndCallback = callback;
  }

  get startDate() {
    return this._start;
  }

  get sessionId() {
    if (!this._sessionId) {
      this.start();
    }
    return this._sessionId;
  }

  public start() {
    this._start = new Date();
    this._sessionId = uuidv4();
    this._timerId = window.setTimeout(this.end.bind(this), SESSION_INTERVAL);
    this._logger.session(this._sessionId);
    this._promoted.fire(new EventData(EVENT_TYPES.START_SESSION, {
      start: this.startDate
    }));
  }

  public update() {
    if (this._timerId === -1) {
      this.start();
      return;
    }
    clearTimeout(this._timerId);
    this._timerId = window.setTimeout(this.end.bind(this), SESSION_INTERVAL);
    this._promoted.fire(new EventData(EVENT_TYPES.UPDATE_SESSION, {
      start: this.startDate
    }));
  }

  private end() {
    this._timerId = -1;
    this._sessoinEndCallback && this._sessoinEndCallback();
    this._promoted.fire(new EventData(EVENT_TYPES.END_SESSION, {
      start: this.startDate
    }));
    this._sessionId = '';
  }
}

export default Session;
