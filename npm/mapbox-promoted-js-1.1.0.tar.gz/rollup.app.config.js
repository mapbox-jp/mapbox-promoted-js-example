import pluginTypescript from '@rollup/plugin-typescript';
import pluginCommonjs from '@rollup/plugin-commonjs';
import pluginNodeResolve from '@rollup/plugin-node-resolve';
import pluginAlias from '@rollup/plugin-alias';
import { babel as pluginBabel, getBabelOutputPlugin } from '@rollup/plugin-babel';
import { terser as pluginTerser } from 'rollup-plugin-terser';
import pluginReplace from 'rollup-plugin-replace';
import pluginStyles from 'rollup-plugin-styles';
import pluginPolyfill from 'rollup-plugin-polyfill-node';

const createStyledComponentsTransformer = require('typescript-plugin-styled-components').default;
const styledComponentsTransformer = createStyledComponentsTransformer({
  displayName: true,
  getDisplayName: () => 'mbx-prom'
});

const plugins = [
  getBabelOutputPlugin({
    allowAllFormats: true,
    presets: [
      [
        '@babel/preset-env',
        {
          useBuiltIns: 'entry',
          corejs: 3,
          targets: {
            ie: 11,
            edge: 16,
            chrome: 64,
            firefox: 58,
            safari: 11
          }
        }
      ]
    ]
  })
];

const __DEV__ = process.env.NODE_ENV === 'development';
!__DEV__ && (
  plugins.push(pluginTerser())
);

const config = [
  {
    input: 'src/app/index.tsx',
    output: [
      {
        file: `lib/app/browser/index.js`,
        name: 'PromotedApp',
        format: 'iife',
        sourcemap: __DEV__ ? 'inline' : '',
        plugins
      },
      {
        file: `lib/app/es/index.js`,
        name: 'PromotedApp',
        format: 'es',
        sourcemap: __DEV__ ? 'inline' : '',
        plugins
      }
    ],
    plugins: [
      pluginReplace({
        'process.env.NODE_ENV': JSON.stringify(process.env.NODE_ENV)
      }),
      pluginAlias({
        entries: [
          { find: 'assets', replacement: './src/assets' }
        ]
      }),
      pluginTypescript({
        tsconfig: 'tsconfig.app.json',
        module: 'esnext',
        transformers: [
          () => ({
            before: [styledComponentsTransformer]
          })
        ]
      }),
      pluginNodeResolve({
        browser: true
      }),
      pluginCommonjs({
        extensions: ['.js', '.ts']
      }),
      pluginBabel({
        babelHelpers: 'bundled',
        presets: ['@babel/preset-react']
      }),
      pluginStyles({
        minimize: true
      }),
      pluginPolyfill()
    ]
  }
];

export default config;
