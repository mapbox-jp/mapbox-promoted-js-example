declare type Coordinate = {
  lng: number;
  lat: number;
};
declare type CornerCoordinates = {
  ne: Coordinate;
  sw: Coordinate;
};
declare type Tile = {
  x: number;
  y: number;
  z: number;
};
