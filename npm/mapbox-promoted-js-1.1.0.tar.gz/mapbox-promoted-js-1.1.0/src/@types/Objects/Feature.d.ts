declare namespace Feature {
  interface Properties {
    auction_id: string;
    feature_id: string;
    cps: string;
    type?: Types;
    promotion_type?: PromotionTypes;
    icon?: string;
    advertizer?: string;
    category?: string;
    address_ja?: string;
    address_en?: string;
    name_ja?: string;
    name_en?: string;
    subtitle?: string;
    phone_number?: string;
    promotion_banner?: string;
    promotion_banner_width?: number;
    promotion_banner_height?: number;
    promotion_card?: string;
    promotion_url?: string;
    directions?: string;
    lat?: string;
    lng?: string;
    min_zoom?: string;
    sat_open?: string;
    sat_close?: number;
    sun_open?: number;
    sun_close?: number;
    week_open?: number;
    week_close?: number;
    holiday_open?: number;
    holiday_close?: number;
  }
  const TYPES: {
    readonly NONE: 'none';
    readonly POPUP: 'popup';
  }
  type Types = typeof TYPES[keyof typeof TYPES];
  const PROMOTION_TYPES: {
    readonly CARD: 'card';
  }
  type PromotionTypes = typeof PROMOTION_TYPES[keyof typeof PROMOTION_TYPES];
}
declare interface Feature extends mapboxgl.MapboxGeoJSONFeature {
  properties: Feature.Properties;
  geometry: GeoJSON.Geometry;
}
declare type FeatureLog = {
  feature: Feature;
  startActionType?: string;
  endActionType?: string;
  startZoomLevel?: number;
  endZoomLevel?: number;
  visibleStartTime?: number;
  visibleEndTime?: number;
}
