declare namespace Promoted {
  const EVENT_TYPES: {
    readonly LOAD: 'load';
    readonly MOVEEND: 'moveend';
    readonly ZOOMEND: 'zoomend';
    readonly SOURCEDATA: 'sourcedata';
    readonly SOURCEDATAEND: 'sourcedataend';
    readonly CLICK_PIN: 'click_pin';
    readonly START_SESSION: 'start_session';
    readonly UPDATE_SESSION: 'update_session';
    readonly END_SESSION: 'end_session';
    readonly CLICK_POPUP: 'click_popup';
    readonly SHOW_POPUP: 'show_popup';
    readonly CLOSE_POPUP: 'close_popup';
  }
  type EventTypes = typeof EVENT_TYPES[keyof typeof EVENT_TYPES];

  class EventData {
    type: Promoted.EventTypes;
    data: Object;
    constructor(type: Promoted.EventTypes, data?: Object);
  } 
}
