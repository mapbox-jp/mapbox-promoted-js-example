declare namespace Promoted {
  class Session {
    constructor(promoted: Promoted.Core);
    set sessoinEndCallback(callback: () => void);
    get startDate(): Date;
    get sessionId(): string;
    public start(): void;
    public update(): void;
  }
}
