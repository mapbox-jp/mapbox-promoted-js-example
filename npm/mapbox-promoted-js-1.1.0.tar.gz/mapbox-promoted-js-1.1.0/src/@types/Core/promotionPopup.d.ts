declare namespace Promoted {
  namespace PromotionPopup {
    type PopupGroup = {
      popup: mapboxgl.Popup;
      sessionId: string;
      feature: Feature;
    };
  }
  class PromotionPopup {
    constructor(promoted: Promoted.Core, source: Promoted.Source);
    public show(feature: Feature): void;
    public close(feature: Feature): void;
    public remove(feature: Feature): void;
  }
}
