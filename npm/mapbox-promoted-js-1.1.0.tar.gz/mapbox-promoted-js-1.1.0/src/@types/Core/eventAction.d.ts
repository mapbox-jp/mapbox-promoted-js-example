declare namespace Promoted {
  type Tile = {
    x: number;
    y: number;
    z: number;
    quadkey: string;
  };

  class EventAction {
    constructor(map: mapboxgl.Map, promoted: Promoted.Core);
    set source(source: Source);
    public click(event: mapboxgl.MapMouseEvent & { features?: mapboxgl.MapboxGeoJSONFeature[] | undefined; } & mapboxgl.EventData): void;
    public updateRenderedFeatures(actionType: string): {
      appearedFeatures: Feature[];
      disappearedFeatures: Feature[];
    };
    public updateRenderedFeatureSessions(): void;
    public getPromotionFeatures(): { [key: string]: Feature };
  }
}
