export const CONFIG = {
  BASE_URL: 'https://mbp.mapbox-lab.com',
  LOG_URL: 'https://mbp.mapbox-lab.com',
  ACCESS_TOKEN: '',
  SMALL_MAX_WIDTH: 640,
  MEDIUM_MAX_WIDTH: 768,
  LARGE_MAX_WIDTH: 1024,
  DEBUG: false,
};

export const DEFAULT_BANNER_SIZE: { WIDTH: number; HEIGHT: number; } = {
  WIDTH: 400,
  HEIGHT: 110,
};
