import LoggerAPI from 'apis/logger';
import { CONFIG } from 'utils/config';

const OBSERVING_INTERVAL = 10 * 1000;
const MAX_VISIBLE_SENDING_COUNT = 100;
const MAX_SENDING_COUNT = 50;
const MAX_VISIBLE_COUNT_LIMITATION = 500;
const MAX_COUNT_LIMITATION = 50;

class Logger implements Promoted.Logger {
  private _sessions: Promoted.Logger.Session[] = [];
  private _visibles: Promoted.Logger.Visible[] = [];
  private _selects: Promoted.Logger.Select[] = [];
  private _deselects: Promoted.Logger.Deselect[] = [];
  private _callToActions: Promoted.Logger.CallToAction[] = [];
  private _feedbacks: Promoted.Logger.Feedback[] = [];
  private _logs: Promoted.Logger.Log[] = [];
  private _isSendingSessions: boolean = false;
  private _isSendingVisibles: boolean = false;
  private _isSendingSelects: boolean = false;
  private _isSendingDeselects: boolean = false;
  private _isSendingCallToActions: boolean = false;
  private _isSendingFeedbacks: boolean = false;
  private _isSendingLogs: boolean = false;
  private _timerId = -1;
  private _sessionId = '';

  constructor() {
    this.startObserving();
  }

  private observe() {
    this._sessions.length > 0 && this.sendSessions();
    this._visibles.length > 0 && this.sendVisibles();
    this._selects.length > 0 && this.sendSelects();
    this._deselects.length > 0 && this.sendDeselects();
    this._feedbacks.length > 0 && this.sendFeedbacks();
    this._logs.length > 0 && this.sendLogs();
  }

  public startObserving() {
    this._timerId = window.setInterval(this.observe.bind(this), OBSERVING_INTERVAL);
  }

  public stopObserving() {
    clearInterval(this._timerId);
    this._timerId = -1;
  }

  private sendSessions() {
    if (this._isSendingSessions) {
      return;
    }
    this._isSendingSessions = true;
    const sessions = this._sessions.concat().slice(0, MAX_SENDING_COUNT);
    new LoggerAPI().sessions(sessions).then(() => {
      this._sessions = this._sessions.reduce((updateSessions: Promoted.Logger.Session[], session) => {
        if (sessions.find((targetSession: Promoted.Logger.Session) => targetSession.created === session.created)) {
          return updateSessions;
        }
        return [...updateSessions, session];
      }, []);
    }).catch((error) => {
      console.error(error);
      if (error.status !== 0) {
        this.log('error_internal', error.text || error.toString(), this._sessionId);
      }
    }).finally(() => {
      this._isSendingSessions = false;
    });
  }

  private sendVisibles() {
    if (this._isSendingVisibles) {
      return;
    }
    this._isSendingVisibles = true;
    const visibles = this._visibles.concat().slice(0, MAX_VISIBLE_SENDING_COUNT);
    new LoggerAPI().visibles(visibles).then(() => {
      this._visibles = this._visibles.reduce((updateVisibles: Promoted.Logger.Visible[], visible) => {
        if (visibles.find(targetVisible => targetVisible.created === visible.created)) {
          return updateVisibles;
        }
        return [...updateVisibles, visible];
      }, []);
    }).catch((error) => {
      console.error(error);
      if (error.status !== 0) {
        this.log('error_internal', error.text || error.toString(), this._sessionId);
      }
    }).finally(() => {
      this._isSendingVisibles = false;
    });
  }

  private sendSelects() {
    if (this._isSendingSelects) {
      return;
    }
    this._isSendingSelects = true;
    const selects = this._selects.concat().slice(0, MAX_SENDING_COUNT);
    new LoggerAPI().selects(this._selects).then(() => {
      this._selects = this._selects.reduce((updateSelects: Promoted.Logger.Select[], select) => {
        if (selects.find(targetSelect => targetSelect.created === select.created)) {
          return updateSelects;
        }
        return [...updateSelects, select];
      }, []);
    }).catch((error) => {
      console.error(error);
      if (error.status !== 0) {
        this.log('error_internal', error.text || error.toString(), this._sessionId);
      }
    }).finally(() => {
      this._isSendingSelects = false;
    });
  }

  private sendDeselects() {
    if (this._isSendingDeselects) {
      return;
    }
    this._isSendingDeselects = true;
    const deselects = this._deselects.concat().slice(0, MAX_SENDING_COUNT);
    new LoggerAPI().deselects(this._deselects).then(() => {
      this._deselects = this._deselects.reduce((updateDeselects: Promoted.Logger.Deselect[], deselect) => {
        if (deselects.find(targetDeselect => targetDeselect.created === deselect.created)) {
          return updateDeselects;
        }
        return [...updateDeselects, deselect];
      }, []);
    }).catch((error) => {
      console.error(error);
      if (error.status !== 0) {
        this.log('error_internal', error.text || error.toString(), this._sessionId);
      }
    }).finally(() => {
      this._isSendingDeselects = false;
    });
  }

  private sendCallToActions() {
    if (this._isSendingCallToActions) {
      return;
    }
    this._isSendingCallToActions = true;
    const callToActions = this._callToActions.concat().slice(0, MAX_SENDING_COUNT);
    new LoggerAPI().callToAction(this._callToActions).then(() => {
      this._callToActions = this._callToActions.reduce((updateCallToActions: Promoted.Logger.CallToAction[], callToAction) => {
        if (callToActions.find(targetCallToAction => targetCallToAction.created === callToAction.created)) {
          return updateCallToActions;
        }
        return [...updateCallToActions, callToAction];
      }, []);
    }).catch((error) => {
      console.error(error);
      if (error.status !== 0) {
        this.log('error_internal', error.text || error.toString(), this._sessionId);
      }
    }).finally(() => {
      this._isSendingCallToActions = false;
    });
  }

  private sendFeedbacks() {
    if (this._isSendingFeedbacks) {
      return;
    }
    this._isSendingFeedbacks = true;
    const feedbacks = this._feedbacks.concat().slice(0, MAX_SENDING_COUNT);
    new LoggerAPI().feedbacks(this._feedbacks).then(() => {
      this._feedbacks = this._feedbacks.reduce((updateFeedbacks: Promoted.Logger.Feedback[], feedback) => {
        if (feedbacks.find(targetFeedback => targetFeedback.created === feedback.created)) {
          return updateFeedbacks;
        }
        return [...updateFeedbacks, feedback];
      }, []);
    }).finally(() => {
      this._isSendingFeedbacks = false;
    });
  }

  private sendLogs() {
    if (this._isSendingLogs) {
      return;
    }
    this._isSendingLogs = true;
    const logs = this._logs.concat().slice(0, MAX_SENDING_COUNT);
    new LoggerAPI().logs(this._logs).then(() => {
      this._logs = this._logs.reduce((updateLogs: Promoted.Logger.Log[], log) => {
        if (logs.find(targetLog => targetLog.created === log.created)) {
          return updateLogs;
        }
        return [...updateLogs, log];
      }, []);
    }).catch((error) => {
      console.error(error);
      if (error.status !== 0) {
        this.log('error_internal', error.text || error.toString(), this._sessionId);
      }
    }).finally(() => {
      this._isSendingLogs = false;
    });
  }

  public session(sessionId: string) {
    if (
      this._sessions.length > MAX_VISIBLE_COUNT_LIMITATION ||
      CONFIG.DEBUG
    ) { return; }
    this._sessionId = sessionId;
    this._sessions.push({
      session_id: sessionId,
      created: Math.floor(new Date().getTime() / 1000),
    });
    this.sendSessions();
  }

  public visibles(sessionId: string, featureLogs: FeatureLog[]) {
    if (
      this._visibles.length > MAX_VISIBLE_COUNT_LIMITATION ||
      CONFIG.DEBUG
    ) { return; }
    for (const featureLog of featureLogs) {
      const {
        feature,
        startActionType,
        endActionType,
        startZoomLevel,
        endZoomLevel,
        visibleStartTime,
        visibleEndTime
      } = featureLog;
      const { auction_id, cps } = feature.properties;
      this._visibles.push({
        session_id: sessionId,
        auction_id,
        cps,
        start_action_type: startActionType,
        end_action_type: endActionType,
        start_zoom_level: startZoomLevel,
        end_zoom_level: endZoomLevel,
        visible_start_time: visibleStartTime,
        visible_end_time: visibleEndTime,
        created: Math.floor(new Date().getTime() / 1000),
      });
    }
    this.sendVisibles();
  }

  public select(
    sessionId: string,
    feature: Feature,
    zoomLevel: number,
    promotionType?: Promoted.Logger.PromotionTypes
  ) {
    if (
      this._selects.length > MAX_COUNT_LIMITATION ||
      CONFIG.DEBUG
    ) { return; }
    const { auction_id, cps } = feature.properties;
    this._selects.push({
      session_id: sessionId,
      auction_id,
      cps,
      zoom_level: zoomLevel,
      promotion_type: promotionType || 'card',
      created: Math.floor(new Date().getTime() / 1000),
    });
    this.sendSelects();
  }

  public deselect(sessionId: string, feature: Feature, zoomLevel: number) {
    if (
      this._deselects.length > MAX_COUNT_LIMITATION ||
      CONFIG.DEBUG
    ) { return; }
    const { auction_id, cps } = feature.properties;
    this._deselects.push({
      session_id: sessionId,
      auction_id,
      cps,
      zoom_level: zoomLevel,
      created: Math.floor(new Date().getTime() / 1000),
    });
    this.sendDeselects();
  }

  public callToAction(
    sessionId: string,
    feature: Feature,
    zoomLevel: number,
    type: Promoted.Logger.ActionTypes
  ) {
    if (
      this._callToActions.length > MAX_COUNT_LIMITATION ||
      CONFIG.DEBUG
    ) { return; }
    const { auction_id, cps } = feature.properties;
    this._callToActions.push({
      session_id: sessionId,
      auction_id,
      cps,
      zoom_level: zoomLevel,
      type,
      created: Math.floor(new Date().getTime() / 1000),
    });
    this.sendCallToActions();
  }

  public feedback(
    sessionId: string,
    feature: Feature,
    zoomLevel: number,
    type: Promoted.Logger.FeedbackTypes
  ) {
    if (
      this._feedbacks.length > MAX_COUNT_LIMITATION ||
      CONFIG.DEBUG
    ) { return; }
    const { auction_id, cps } = feature.properties;
    this._feedbacks.push({
      session_id: sessionId,
      auction_id,
      cps,
      zoom_level: zoomLevel,
      type,
      action: type,
      description: '',
      created: Math.floor(new Date().getTime() / 1000),
    });
    this.sendFeedbacks();
  }

  public log(
    type: string,
    description: string,
    sessionId?: string,
    feature?: Feature,
  ) {
    if (
      this._logs.length > MAX_COUNT_LIMITATION ||
      CONFIG.DEBUG
    ) { return; }
    const { properties } = feature || {};
    const { auction_id, cps } = properties || {};
    this._logs.push({
      type,
      description,
      session_id: sessionId,
      auction_id,
      cps,
      created: Math.floor(new Date().getTime() / 1000),
    });
    this.sendLogs();
  }
}

export default Logger;
