import mapboxgl from 'mapbox-gl';
import { CONFIG } from 'utils/config';
import { quadkeyToTile } from 'utils/geometry';
import PromotionPopup from './promotionPopup';
import Event from './event';
import Source from './source';
import Session from './session';
import EventAction from './eventAction';
import Logger from './logger';
import { DISPLAY_TYPES } from './helpers';

class Promoted extends Event implements Promoted.Core {
  private _map: mapboxgl.Map;
  private _source: Promoted.Source;
  private _session: Promoted.Session;
  private _eventAction: Promoted.EventAction;
  private _logger: Promoted.Logger;
  private _isDarkMode: boolean;
  private _promotionPopup: PromotionPopup;

  constructor(map: mapboxgl.Map, token: string, options: Promoted.Core.Options = {}) {
    super();

    CONFIG.ACCESS_TOKEN = token;

    const {
      baseUrl,
      logUrl,
      isDarkMode,
      debug,
    } = options;

    baseUrl && (CONFIG.BASE_URL = baseUrl);
    logUrl && (CONFIG.LOG_URL = logUrl);
    debug && (this.debug = debug);

    this._map = map;
    this._isDarkMode = isDarkMode || false;

    this._logger = new Logger();
    this._session = new Session(this, this._logger);
    this._eventAction = new EventAction(map, this, this._session, this._logger);
    this._source = new Source(map, this, this._eventAction, this._logger);
    this._eventAction.source = this._source;

    this._promotionPopup = new PromotionPopup(this, this._session, this._source, this._logger);
  }

  get map() {
    return this._map;
  }

  get isDarkMode() {
      return this._isDarkMode;
  }

  set isDarkMode(isDarkMode: boolean) {
    this._isDarkMode = isDarkMode;
  }

  set debug(debug: boolean) {
    CONFIG.DEBUG = debug;
  }

  get sourceId(): string {
    return this._source.sourceId;
  }

  get layerId(): string {
    return this._source.layerId;
  }

  get tiles(): Promoted.Tile[] {
    const quadkeies = Object.keys(this._source.tilesets);
    const tiles = [];
    for (const quadkey of quadkeies) {
      tiles.push({
        ...quadkeyToTile(quadkey),
        quadkey
      });
    }
    return tiles;
  }

  get tilesets(): { [quadkey: string]: Feature[] } {
    return this._source.tilesets;
  }

  get features(): Feature[] {
    return this._map.querySourceFeatures(this.sourceId) as Feature[];
  }

  get renderedFeatures(): Feature[] {
    const featureDictionaries = this._eventAction.getPromotionFeatures();
    return Object.values(featureDictionaries);
  }

  private getDisplayType(feature: Feature): Feature.Types {
    switch (feature.properties.type) {
      case undefined:
        return DISPLAY_TYPES.NONE;
      case DISPLAY_TYPES.POPUP:
        return DISPLAY_TYPES.POPUP;
      default:
        return feature.properties.type;
      }
  }

  public show(feature: Feature) {
    const type = this.getDisplayType(feature);
    switch (type) {
      case DISPLAY_TYPES.POPUP:
      case DISPLAY_TYPES.NONE:
      default:
        this._promotionPopup.show(feature);
        break;
    }
  }

  public visibleLayer() {
    this._source.visibleLayer();
  }

  public hideLayer() {
    this._source.hideLayer();
  }

  public reload() {
    this._source.reload();
  }
}

export default Promoted;
