import { createLayer } from 'utils/layer';

describe('utils/layer.createLayer', () => {
  const layerId = 'test-layer'
  const sourceId = 'test-source'
  const layerProperties = createLayer(layerId, sourceId);

  it('Valid layer id', () => (
    expect(layerProperties).toHaveProperty('id', layerId)
  ));

  it('Valid source id', () => (
    expect(layerProperties).toHaveProperty('source', sourceId)
  ));

  it('Valid type', () => (
    expect(layerProperties).toHaveProperty('type', 'symbol')
  ));

  it('Valid filter expression', () => (
    expect(layerProperties).toHaveProperty('filter', [
      'all',
      ['>=', ['zoom'], ['get', 'min_zoom']],
    ])
  ));

  describe('Layout properties', () => {
    const layoutProperties = layerProperties.layout;

    it('Valid icon image expression', () => (
      expect(layoutProperties).toHaveProperty('icon-image', ['get', 'icon'])
    ));

    it('Valid icon size expression', () => (
      expect(layoutProperties).toHaveProperty('icon-size', [
        'interpolate',
        ['exponential', 1.5],
        ['zoom'],
        10, 0.5,
        16, 1.0
      ])
    ));

    it('Valid icon anchor', () => (
      expect(layoutProperties).toHaveProperty('icon-anchor', 'bottom')
    ));

    it('Valid text field expression', () => (
      expect(layoutProperties).toHaveProperty('text-field', ['get', 'name_ja'])
    ));

    it('Valid text anchor', () => (
      expect(layoutProperties).toHaveProperty('text-anchor', 'top')
    ));

    it('Valid text size expression', () => (
      expect(layoutProperties).toHaveProperty('text-size', [
        'interpolate',
        ['exponential', 1.5],
        ['zoom'],
        10, 9,
        16, 12,
      ])
    ));
  });

  describe('Paint properties', () => {
    const paintProperties = layerProperties.paint;

    it('Valid icon halo color', () => (
      expect(paintProperties).toHaveProperty('icon-halo-color')
    ));

    it('Valid icon halo width', () => (
      expect(paintProperties).toHaveProperty('icon-halo-width')
    ));

    it('Valid text color', () => (
      expect(paintProperties).toHaveProperty('text-color')
    ));

    it('Valid text halo color', () => (
      expect(paintProperties).toHaveProperty('text-halo-color')
    ));

    it('Valid text halo width', () => (
      expect(paintProperties).toHaveProperty('text-halo-width')
    ));

    it('Valid text translate expression', () => (
      expect(paintProperties).toHaveProperty('text-translate')
    ));

    it('Valid text translate anchor', () => (
      expect(paintProperties).toHaveProperty('text-translate-anchor', 'viewport')
    ));

    it('Valid text opacity expression', () => (
      expect(paintProperties).toHaveProperty('text-opacity', [
        'step',
        ['zoom'],
        0,
        14,
        1
      ])
    ));
  });
});
