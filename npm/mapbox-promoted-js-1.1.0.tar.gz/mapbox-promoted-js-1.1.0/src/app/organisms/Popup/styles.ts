import { createGlobalStyle } from 'styled-components';

export const GlobalStyle = createGlobalStyle`
  .mapbox-promoted-popup {
    max-width: 280px !important;

    & > .mapboxgl-popup-tip {
      display: none;
    }
    & > .mapboxgl-popup-content {
      padding: 0;
      background-color: transparent;
      box-shadow: none;
    }
  }
`;
