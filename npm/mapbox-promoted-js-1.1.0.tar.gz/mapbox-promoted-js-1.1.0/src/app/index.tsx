import { CONFIG } from 'utils/config';
import PromotionPopup from './organisms/Popup';

window.addEventListener('DOMContentLoaded', () => {
  window.renderApp = (updateConfig: Config) => {
    CONFIG.ACCESS_TOKEN = updateConfig.ACCESS_TOKEN;
    CONFIG.BASE_URL     = updateConfig.BASE_URL;
    CONFIG.LOG_URL      = updateConfig.LOG_URL;
  };
});

export { PromotionPopup };
