import styled, { keyframes, createGlobalStyle } from 'styled-components';
import { CONFIG } from 'utils/config';

type Container = {
  isFadeout?: boolean;
  isRendered?: boolean;
};
type Wrapper = {
  isRendered?: boolean;
};
type HeaderTitleLabel = {
  isRendered?: boolean;
};
type HeaderSubtitleLabel = {
  isRendered?: boolean;
};
type Banner = {
  height: number;
};

const bounceIn = keyframes`
  from {
    opacity: 0.0;
    transform: scale3d(0.3, 0.3, 0.3);
    -webkit-transform: scale3d(0.3, 0.3, 0.3);
    -ms-transform: scale3d(0.3, 0.3, 0.3);
  }
  to {
    opacity: 1.0;
    transform: scale3d(1.0, 1.0, 1.0);
    -webkit-transform: scale3d(1.0, 1.0, 1.0);
    -ms-transform: scale3d(1.0, 1.0, 1.0);
  }
`;
const bounceOut = keyframes`
  from {
    opacity: 1.0;
    transform: scale3d(1.0, 1.0, 1.0);
    -webkit-transform: scale3d(1.0, 1.0, 1.0);
    -ms-transform: scale3d(1.0, 1.0, 1.0);
  }
  to {
    opacity: 0.0;
    transform: scale3d(0.3, 0.3, 0.3);
    -webkit-transform: scale3d(0.3, 0.3, 0.3);
    -ms-transform: scale3d(0.3, 0.3, 0.3);
  }
`;

export const GlobalStyle = createGlobalStyle`
  .promotion-popup {
    &__card {
      @media screen and (max-width: ${CONFIG.SMALL_MAX_WIDTH}px) {
        zoom: 80%;
      }
      @media screen and (min-width: ${CONFIG.SMALL_MAX_WIDTH}px) and (max-width: ${CONFIG.MEDIUM_MAX_WIDTH}px) {
        zoom: 90%;
      }
      @media screen and (min-width: ${CONFIG.LARGE_MAX_WIDTH}px) {
        
      }
    }
  }
`;
export const Container = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  border-radius: 5px;
  box-shadow: ${({ isRendered }: Container) => isRendered ? '0 0 8px rgba(0, 0, 0, 0.3)' : 'none'};
  overflow: hidden;
  animation-duration: 0.2s;
  animation-name: ${({ isRendered, isFadeout }: Container) => !isRendered ? 'none' : isFadeout ? bounceOut : bounceIn};
`;
export const Wrapper = styled.div`
  visibility: ${({ isRendered }: Wrapper) => isRendered ? 'visible' : 'hidden'};
  width: 280px;
  background: rgb(255, 255, 255);
  z-index: 1;
`;
export const Banner = styled.div.attrs(({ height }: Banner) => ({ height }))`
  width: 280px;
  height: ${({ height }: Banner) => `${height}px`};
  background-color: rgb(142, 142, 142);
`;
export const BannerImg = styled.img`
  width: 100%;
  height: auto;
  object-fit: cover;
`;
export const Content = styled.div`
  padding: 16px;
`;
export const Header = styled.div`
  position: relative;
`;
export const HeaderTitle = styled.div``;
export const HeaderTitleLabel = styled.h1`
  display: -webkit-box;
  width: calc(100% - 36px - 10px);
  max-height: 20px;
  font-size: 14px;
  line-height: 20px;
  overflow: hidden;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
`;
export const HeaderPromotionTag = styled.div`
  position: absolute;
  top: 0;
  right: 0;
`;
export const HeaderSubtitle = styled.div`
  margin-top: 8px;
  font-size: 13px;
`;
export const HeaderSubtitleLabel = styled.span`
  display: -webkit-box;
  line-height: 20px;
  overflow: hidden;
  -webkit-box-orient: vertical;
  @media screen and (min-width: ${CONFIG.MEDIUM_MAX_WIDTH}px) {
    max-height: 60px;
    -webkit-line-clamp: 3;
  }
  @media screen and (max-width: ${CONFIG.MEDIUM_MAX_WIDTH}px) {
    max-height: 40px;
    -webkit-line-clamp: 2;
  }
`;
export const MenuContainer = styled.div`
  margin: 10px -16px 0 -16px;
`;
export const Menu = styled.ul`
  margin: 0;
  padding: 0;
  list-style: none;
`;
export const ActionsContainer = styled.div`
  margin: 14px -16px 0 -16px;
  overflow-x: auto;
  scrollbar-width: none;
  &::-webkit-scrollbar {
    display:none;
  }
`;
export const Actions = styled.ul`
  display: flex;
  margin: 0;
  padding: 0;
  list-style: none;
`;
export const ActionSpace = styled.li`
  width: 16px;
  min-width: 16px;
  height: auto;
`;
