import styled, { css } from 'styled-components';
import { CONFIG } from 'utils/config';

type MenuItem = {
  isAction?: boolean;
};

const hover = css`
  cursor: pointer;
  transition: background-color 0.1s;
  &:hover {
    background-color: #f1f3f4;
  }
`;

export const MenuItem = styled.li`
  display: flex;
  align-items: center;
  padding: 6px 16px;
  line-height: 1;
  overflow-wrap: break-word;
  ${({ isAction }: MenuItem) => isAction && hover}
`;
export const MenuItemIcon = styled.span`
  display: flex;
  justify-content: center;
  align-items: center;
  margin-right: 10px;
  padding: 2px;
  width: 19px;
  min-width: 19px;
  height: 19px;
  min-height: 19px;
  font-size: 15px;
  color: #1a73e8;
`;
export const MenuItemLabel = styled.span`
  display: -webkit-box;
  font-size: 13px;
  line-height: 18px;
  overflow: hidden;
  -webkit-box-orient: vertical;
  @media screen and (min-width: ${CONFIG.MEDIUM_MAX_WIDTH}px) {
    max-height: 37px;
    -webkit-line-clamp: 2;
  }
  @media screen and (max-width: ${CONFIG.MEDIUM_MAX_WIDTH}px) {
    max-height: 18px;
    -webkit-line-clamp: 1;
  }
`;
