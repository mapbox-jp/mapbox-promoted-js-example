import { ICON_TYPE } from 'atoms/Icon';
import { getOpenCloseLabel } from 'utils/feature';
import { CLICK_TYPES } from '../helpers';

export const MENU_TYPES = {
  ADDRESS_JA: 'menu-type-address-ja',
  PHONE_NUMBER: 'menu-type-phone-number',
  OPEN_AND_CLOSE: 'menu-type-open-and-close',
} as const;

export type MenuTypes = typeof MENU_TYPES[keyof typeof MENU_TYPES];

type Menu = {
  [key in MenuTypes]: {
    key: string;
    iconType: string;
    clickType?: PromotionPopup.ClickTypes;
    isRequired?: boolean;
    isAction?: boolean;
    label?: (properties: Feature.Properties) => (string | undefined);
  };
};

export const MENUS: Menu = {
  [MENU_TYPES.ADDRESS_JA]: {
    key: 'address_ja',
    iconType: ICON_TYPE.MAP_MARKER_ALT,
  },
  [MENU_TYPES.PHONE_NUMBER]: {
    key: 'phone_number',
    iconType: ICON_TYPE.PHONE,
    clickType: CLICK_TYPES.CALL,
    isAction: true,
  },
  [MENU_TYPES.OPEN_AND_CLOSE]: {
    key: '',
    iconType: ICON_TYPE.CLOCK,
    isRequired: true,
    label: properties => {
      const lanel = getOpenCloseLabel(properties);
      return lanel && `営業時間: ${lanel}`;
    },
  },
};
