import React from 'react';
import Icon from 'atoms/Icon';
import { MENU_TYPES, MENUS, MenuTypes } from './helpers';
import {
  MenuItem,
  MenuItemIcon,
  MenuItemLabel,
} from './styles';

const PREFIX_CLASSNAME = 'promotion-popup__card__menu-item';

type Props = {
  properties: Feature.Properties;
  onClick: (type: PromotionPopup.ClickTypes) => void;
};

const MenuItems: React.FC<Props> = props => {
  const { properties, onClick } = props;
  const keys = Object.keys(MENU_TYPES) as MenuTypes[];
  const handleClick = (type: PromotionPopup.ClickTypes) => {
    onClick(type);
  };
  return (
    <>
      {keys.map(key => {
        const actionType: MenuTypes = (MENU_TYPES as any)[key];
        const action = MENUS[actionType];
        const value = (properties as any)[action.key] as string;
        const label = action.label ? action.label(properties) : value;
        const { iconType, clickType, isAction } = action;
        return label && (
          <MenuItem
            className={PREFIX_CLASSNAME}
            isAction={isAction}
            onClick={() => clickType && handleClick(clickType)}
            key={`${PREFIX_CLASSNAME}-${key}`}
          >
            <MenuItemIcon className={`${PREFIX_CLASSNAME}__icon`}>
              <Icon type={iconType} />
            </MenuItemIcon>
            <MenuItemLabel className={`${PREFIX_CLASSNAME}__label`}>
              {label}
            </MenuItemLabel>
          </MenuItem>
        );
      })}
    </>
  );
};

export default MenuItems;
