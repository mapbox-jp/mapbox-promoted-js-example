import { ICON_TYPE } from 'atoms/Icon';
import { CLICK_TYPES } from '../helpers';

export const ACTION_TYPES = {
  NAVIGATION: 'action-type-navigation',
  PHONE_NUMBER: 'action-type-phone-number',
  PROMOTION_URL: 'action-type-promotion-url',
} as const;

export type ActionTypes = typeof ACTION_TYPES[keyof typeof ACTION_TYPES];

type Actions = {
  [key in ActionTypes]: {
    key: string;
    iconType: string;
    clickType?: PromotionPopup.ClickTypes;
    label: string;
    isRequired?: boolean;
  };
};

export const ACTIONS: Actions = {
  [ACTION_TYPES.NAVIGATION]: {
    key: 'directions',
    iconType: ICON_TYPE.ROUTE,
    clickType: CLICK_TYPES.NAVIGATION,
    label: '行き方',
    isRequired: true,
  },
  [ACTION_TYPES.PHONE_NUMBER]: {
    key: 'phone_number',
    iconType: ICON_TYPE.PHONE,
    clickType: CLICK_TYPES.CALL,
    label: '電話番号',
  },
  [ACTION_TYPES.PROMOTION_URL]: {
    key: 'promotion_url',
    iconType: ICON_TYPE.EARTH,
    clickType: CLICK_TYPES.DETAIL,
    label: '関連サイト',
  }
};
