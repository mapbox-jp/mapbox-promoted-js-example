import React from 'react';
import Icon from 'atoms/Icon';
import { ACTION_TYPES, ACTIONS, ActionTypes } from './helpers';
import {
  ActionItem,
  ActionItemAnchor,
  ActionItemButton,
  ActionItemButtonIcon,
  ActionItemLabel,
} from './styles';

const PREFIX_CLASSNAME = 'promotion-popup__card__actions-item';

type Props = {
  properties: Feature.Properties;
  onClick: (type: PromotionPopup.ClickTypes) => void;
};

const ActionItems: React.FC<Props> = props => {
  const { properties, onClick } = props;
  const keys = Object.keys(ACTION_TYPES) as ActionTypes[];
  const handleClick = (type: PromotionPopup.ClickTypes) => {
    onClick(type);
  };
  const renderContent = (iconType: string, label: string) => (
    <>
      <ActionItemButton className={`${PREFIX_CLASSNAME}__button`}>
        <ActionItemButtonIcon className={`${PREFIX_CLASSNAME}__button-icon`}>
          <Icon type={iconType} />
        </ActionItemButtonIcon>
      </ActionItemButton>
      <ActionItemLabel className={`${PREFIX_CLASSNAME}__label`}>
        {label}
      </ActionItemLabel>
    </>
  );
  return (
    <>
      {keys.map((key: ActionTypes) => {
        const actionType: ActionTypes = (ACTION_TYPES as any)[key];
        const action = ACTIONS[actionType];
        const value = (properties as any)[action.key] as string;
        const { iconType, clickType, label, isRequired } = action;
        return value || isRequired ? (
          <ActionItem
            className={PREFIX_CLASSNAME}
            onClick={() => clickType && handleClick(clickType)}
            key={`${PREFIX_CLASSNAME}-${key}`}
          >
            {actionType === ACTION_TYPES.PROMOTION_URL ? (
              <ActionItemAnchor
                className={`${PREFIX_CLASSNAME}__anchor`}
                href={value}
                target='_break'
              >
                {renderContent(iconType, label)}
              </ActionItemAnchor>
            ) : renderContent(iconType, label)}
          </ActionItem>
        ) : null;
      })}
    </>
  );
};

export default ActionItems;
