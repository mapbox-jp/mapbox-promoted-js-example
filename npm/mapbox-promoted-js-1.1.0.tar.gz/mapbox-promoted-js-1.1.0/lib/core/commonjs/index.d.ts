/// <reference types="mapbox-gl" />
declare module 'mapbox-promoted-js' {
  namespace Promoted {
    type Options = {
      baseUrl?: string;
      sourceUrl?: string;
      telemetryUrl?: string;
      isDarkMode?: boolean;
      debug?: boolean;
    };

    type Tile = {
      x: number;
      y: number;
      z: number;
      quadkey: string;
    };
  
    class Event {
      type: EventTypes;
      data: Object;
      constructor(type: EventTypes, data?: Object);
    }
  
    const EVENT_TYPES: {
      readonly LOAD: 'load';
      readonly MOVEEND: 'moveend';
      readonly SOURCEDATA: 'sourcedata';
      readonly SOURCEDATAFEND: 'sourcedataend';
      readonly CLICK_PIN: 'click_pin';
      readonly CLICK_POPUP: 'click_popup';
      readonly SHOW_POPUP: 'show_popup';
      readonly CLOSE_POPUP: 'close_popup';
    }

    type EventTypes = typeof EVENT_TYPES[keyof typeof EVENT_TYPES];
    type Listener = (type: EventTypes, event: any) => any;
  }

  export class Promoted {
    constructor(map: mapboxgl.Map, token: string, options?: Promoted.Options);
    get map(): mapboxgl.Map;
    get isDarkMode(): boolean;
    set isDarkMode(isDarkMode: boolean);
    get debug(): boolean;
    set debug(debug: boolean);
    get layer(): mapboxgl.AnyLayer;
    get sourceIds(): string[];
    get layerIds(): string[];
    get tiles(): Promoted.Tile[];
    get tilesets(): { [quadkey: string]: Feature[] };
    get promotionFeatures(): Feature[];
    on(type: Promoted.EventTypes, listener: Promoted.Listener): void;
    off(type: Promoted.EventTypes, listener: Promoted.Listener): void;
    reload(): void;
  }

  namespace Feature {
    interface Properties {
      cps: string;
      icon?: string;
      advertizer?: string;
      category?: string;
      addressJa?: string;
      addressEn?: string;
      nameJa?: string;
      nameEn?: string;
      subtitle?: string;
      phoneNumber?: string;
      promotionBanner?: string;
      promotionBannerWidth?: number;
      promotionBannerHeight?: number;
      promotionCard?: string;
      promotionUrl?: string;
      displayPromotionInternal?: boolean;
      directions?: string;
      lat?: string;
      lng?: string;
      minZoom?: string;
      satOpen?: string;
      satClose?: string;
      sunOpen?: string;
      sunClose?: string;
      weekOpen?: string;
      weekClose?: string;
      holidayOpen?: string;
      holidayClose?: string;
    }
  }
  interface Feature extends mapboxgl.MapboxGeoJSONFeature {
    properties: Feature.Properties;
  }
}
