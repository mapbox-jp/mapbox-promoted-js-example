declare type Coordinates = {
  lng: number;
  lat: number;
};
declare type Point = {
  x: number;
  y: number;
};
declare type Tile = {
  x: number;
  y: number;
  z: number;
};
declare type Bound = {
  ne: Coordinates;
  nw: Coordinates;
  se: Coordinates;
  sw: Coordinates;
};
declare type TileBound = {
  ne: Tile;
  nw: Tile;
  se: Tile;
  sw: Tile;
};

declare namespace Feature {
  interface Properties {
    auction_id: string;
    feature_id: string;
    cps: string;
    icon?: string;
    advertizer?: string;
    category?: string;
    address_ja?: string;
    address_en?: string;
    address_remarks?: string;
    name_ja?: string;
    name_en?: string;
    subtitle?: string;
    summary?: string;
    phone_number?: string;
    promotion_banner?: string;
    promotion_banner_width?: number;
    promotion_banner_height?: number;
    promotion_card?: string;
    promotion_url?: string;
    directions?: string;
    lat?: string;
    lng?: string;
    min_zoom?: string;
    business_hours?: string;
    business_hours_remarks?: string;
    external_links?: string;
    profile?: string;
  }
  namespace Properties {
    type BusinessHours = {
      monday?: string;
      tuesday?: string;
      wednesday?: string;
      thursday?: string;
      friday?: string;
      saturday?: string;
      sunday?: string;
    };
  }
  namespace Profile {
    type Category = {
      id: string;
      name: string;
    };
    type Image = {
      id: string;
      mime_type: string;
      url: string;
      width: number;
      height: number;
    };
    type Images = {
      small: Image;
      medium: Image;
      large: Image;
    };
    type News = {
      id: string;
      title: string;
      text: string;
      images: Images;
    };
    type Product = {
      id: string;
      category_ids: string[];
      title: string;
      text: string;
      image_url: string;
    };
    type Media = {
      id: string;
      category_ids: string[];
      type: string;
      title?: string;
      images: Images;
    };
  }
  type Profile = {
    news?: boolean;
    products?: boolean;
    media?: boolean;
  };
}
interface Feature extends mapboxgl.MapboxGeoJSONFeature {
  properties: Feature.Properties;
}

declare namespace PromotedMap {
  type Event = {
    features?: Feature[];
    point?: Point;
  };
  type EventListener = {
    listener: any;
    layerId?: string;
  };
  type EventListeners = {
    [quadkey: string]: EventListener[];
  };
  export class Plugin {
    constructor(map: mapboxgl.Map);
    get map(): any;
    get zoomLevel(): number;
    public getBounds(): Bound;
    public getRenderedFeatures(point: Point): Feature[];
    public on(type: string, layerId: any, listener?: any): void;
    public off(type: string, layerId: any, listener?: any): void;
    public render(
      features: Feature[],
      visibledFeatures: Feature[],
      unvisibledFeatures: Feature[]
    ): void;
    public visibleLayer(): void;
    public hideLayer(): void;
    public selectFeature(feature: Feature): void;
    public deselectLayer(): void;
    public reload(): void;
  }
}
