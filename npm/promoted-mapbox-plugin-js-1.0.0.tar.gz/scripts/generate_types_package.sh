#!/bin/bash
VERSION=$1
IGNORE_FILEPATHS=("tmp" "node_modules" "promoted-mapbox-plugin-js" ".git" ".DS_Store")
mkdir ./tmp
for FILEPATH in ./*; do
  IS_IGNORED=false 
  for IGNORE_FILEPATH in "${IGNORE_FILEPATHS[@]}"
  do
    if [[ $FILEPATH == *"${IGNORE_FILEPATH}"* ]]; then
      IS_IGNORED=true
    fi
  done
  if [ "$IS_IGNORED" = false ]
  then
    cp -r $FILEPATH ./tmp/$FILEPATH
  fi
done
echo `tar zcvf ./@types-promoted-mapbox-plugin-js-${VERSION}.tar.gz ./tmp/*`
rm -r tmp
