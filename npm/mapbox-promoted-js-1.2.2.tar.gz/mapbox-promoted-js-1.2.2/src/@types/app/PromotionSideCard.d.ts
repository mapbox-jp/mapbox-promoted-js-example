
declare var renderPromotionSideCardInnerElement: ((
  continer: string | HTMLElement,
  feature: Feature,
  onClick?: (type: Promotion.ClickTypes, feature: Feature, profileItems?: Feature.ProfileItems) => void,
  onUpdate?: (feature: Feature) => void,
  onClose?: (feature: Feature) => void,
) => HTMLElement) | undefined;
declare var removePromotionSideCardInnerElement: ((container: string | HTMLElement) => void) | undefined;
declare var showPromotionSideCard: ((
  feature: Feature,
  onClick?: (type: Promotion.ClickTypes, feature: Feature, profileItems?: Feature.ProfileItems) => void,
  onUpdate?: (feature: Feature) => void,
  onClose?: (feature: Feature) => void,
  onOpen?: (feature: Feature) => void,
  onHide?: (feature: Feature) => void,
) => void) | undefined;
declare var updatePromotionSideCard: ((feature: Feature) => void) | undefined;
declare var openPromotionSideCard: (() => void) | undefined;
declare var hidePromotionSideCard: (() => void) | undefined;
declare var closePromotionSideCard: (() => void) | undefined;
