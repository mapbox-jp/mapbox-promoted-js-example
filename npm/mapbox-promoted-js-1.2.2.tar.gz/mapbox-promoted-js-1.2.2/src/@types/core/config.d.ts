declare namespace Promoted {
  type Config = {
    BASE_URL: string;
    LOG_URL: string;
    ACCESS_TOKEN: string;
    SMALL_MAX_WIDTH: number;
    MEDIUM_MAX_WIDTH: number;
    LARGE_MAX_WIDTH: number;
    DEBUG: boolean;
  }
}
