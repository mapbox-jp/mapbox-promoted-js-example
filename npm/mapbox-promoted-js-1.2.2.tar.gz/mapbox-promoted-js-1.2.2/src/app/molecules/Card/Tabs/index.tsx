import React from 'react';
import Tab from './Tab';
import { Container } from './styles';

type Props = {
  classPrefix: string;
  children?: React.ReactNode;
};

const Tabs: React.FC<Props> = props => {
  const { classPrefix, children } = props;
  return (
    <Container className={`${classPrefix}__tabs`}>
      {children}
    </Container>
  );
};

export default Tabs;
export {
  Tab,
};