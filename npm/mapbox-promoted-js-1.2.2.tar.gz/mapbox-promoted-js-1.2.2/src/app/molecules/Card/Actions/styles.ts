import styled from 'styled-components';

export const Container = styled.div`
  position: relative;
  margin: 0 -10px;
  padding: 22px 0 12px 0;
`;
export const ScrollButtonLeft = styled.div`
  position: absolute;
  display: flex;
  align-items: center;
  padding: 0 0 0 8px;
  top: 0;
  left: 0;
  height: 100%;
`;
export const ScrollButtonRight = styled.div`
  position: absolute;
  display: flex;
  align-items: center;
  padding: 0 8px 0 0;
  top: 0;
  right: 0;
  height: 100%;
`;
export const ActionItems = styled.ul`
  display: flex;
  left: 0;
  overflow-x: scroll;
  scrollbar-width: none;
  list-style: none;
  &::-webkit-scrollbar {
    display: none;
  }
`;
