import styled from 'styled-components';

type Description = {
  isHorizontal?: boolean;
};
type Content = {
  isHorizontal?: boolean;
};

export const Container = styled.li`
  border: solid 1px #ebebed;
  border-radius: 4px;
  cursor: pointer;
  overflow: hidden;
  & + & {
    margin: 10px 0 0 0;
  }
`;
export const VerticalContainer = styled.li`
  width: 180px;
  min-width: 180px;
  height: 213px;
  max-height: 213px;
  border: solid 1px #ebebed;
  border-radius: 4px;
  cursor: pointer;
  overflow: hidden;
  & + & {
    margin: 0 0 0 10px;
  }
`;
export const Thumbnail = styled.div`
  position: relative;
  width: 100%;
  height: 102px;
  &:before {
    content: "";
    display: block;
    width: 100%;
    height: 100%;
    border-bottom: solid 1px #ebebed;
  }
`;
export const ThumbnailImg = styled.img`
  position: absolute;
  top: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
`;
export const Content = styled.div`
  padding: 10px;
`;
export const Title = styled.h4`
  display: -webkit-box;
  margin: 0 0 5px 0;
  font-size: 14px;
  line-height: 1.5;
  color: #636363;
  overflow: hidden;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
`;
export const Description = styled.div`
  display: -webkit-box;
  font-size: 14px;
  line-height: 1.5;
  color: #636363;
  overflow: hidden;
  -webkit-line-clamp: ${({ isHorizontal }: Description) => isHorizontal ? '3' : 'initial'};
  -webkit-box-orient: vertical;
`;
