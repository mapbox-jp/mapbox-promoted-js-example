import React, { useContext, useEffect, useRef, useState } from 'react';
import { ProfileContext } from 'molecules/Card/hooks';
// Components
import ScrollButton from 'atoms/ScrollButton';
import Item from './Item';
import {
  Container,
  CategoriesWrapper,
  Categories,
  Category,
  Items,
  ScrollButtonLeft,
  ScrollButtonRight,
  EmptyColumn,
} from './styles';

type Props = {
  classPrefix?: string;
  selectedProduct?: Feature.Profile.Product;
  isHorizontal?: boolean;
  onClick?: (product: Feature.Profile.Product) => void;
};

const PRODUCTS_ITEM_WIDTH = 253;
const CATEGORIES_ITEM_WIDTH = 70;

const Products: React.FC<Props> = props => {
  const { classPrefix, selectedProduct, isHorizontal, onClick } = props;
  const {
    productCategories,
    products,
    productCategoryId,
    productIsLasted,
    updateProductCategory,
    readmoreProducts
  } = useContext(ProfileContext);
  const PREFIX_CLASSNAME = `${classPrefix}-products`;

  const ref = useRef<HTMLDivElement>(null);
  const productsRef = useRef<HTMLUListElement>(null);
  const categoriesRef = useRef<HTMLDivElement>(null);
  const [isHovering, setIsHovering] = useState(false);
  const [isHoveringCategories, setIsHoveringCategories] = useState(false);
  const [_, setDate] = useState<Date>();

  const handleSelectCategory = (categoryId?: string) => updateProductCategory(categoryId);
  const handleReadMore = () => readmoreProducts(productCategoryId);
  const handleMouseEnter = () => setIsHovering(true);
  const handleMouseLeave = () => setIsHovering(false);
  const handleMouseEnterCatevories = () => setIsHoveringCategories(true);
  const handleMouseLeaveCatevories = () => setIsHoveringCategories(false);
  const handleScroll = (left: boolean = false) => {
    if (!productsRef.current) { return; }
    productsRef.current.scroll({
      left: productsRef.current.scrollLeft + (
        left ? -1 * PRODUCTS_ITEM_WIDTH : PRODUCTS_ITEM_WIDTH
      ),
      behavior: 'smooth'
    });
    productsRef.current.scrollLeft
  };
  const handleScrollCategories = (left: boolean = false) => {
    if (!categoriesRef.current) { return; }
    categoriesRef.current.scroll({
      left: categoriesRef.current.scrollLeft + (
        left ? -1 * CATEGORIES_ITEM_WIDTH : CATEGORIES_ITEM_WIDTH
      ),
      behavior: 'smooth'
    });
    categoriesRef.current.scrollLeft
  };
  
  useEffect(() => {
    if (selectedProduct) {
      const id = `promotion-profile-products__${selectedProduct.id}`;
      const target = document.getElementById(id);
      target && target.scrollIntoView();
    }
  }, []);
  useEffect(() => {
    setDate(new Date());
  }, [ref]);

  return (
    <>
      {productCategories.length ? (
        <CategoriesWrapper
          className={`${PREFIX_CLASSNAME}__categories-wrapper`}
          isHorizontal={isHorizontal}
          onMouseEnter={handleMouseEnterCatevories}
          onMouseLeave={handleMouseLeaveCatevories}
        >
          {isHoveringCategories && (
            <ScrollButtonLeft
              className={`${PREFIX_CLASSNAME}__categories__scroll-button-left__wrapper`}
              onClick={() => handleScrollCategories(true)}
            >
              <ScrollButton
                classPrefix={`${PREFIX_CLASSNAME}__categories`}
                type='left'
                size='medium'
              />
            </ScrollButtonLeft>
          )}
          {ref.current ? (
            <Categories
              className={`${PREFIX_CLASSNAME}__categories`}
              width={`${ref.current.clientWidth}px`}
              isHorizontal={isHorizontal}
              ref={categoriesRef}
            >
              <Category
                className={`${PREFIX_CLASSNAME}__categories-item`}
                isSelected={!productCategoryId}
                onClick={() => handleSelectCategory()}
              >
                すべて
              </Category>
              {productCategories.map((category) => (
                <Category
                  className={`${PREFIX_CLASSNAME}__categories-item`}
                  isSelected={category.id === productCategoryId}
                  onClick={() => handleSelectCategory(category.id)}
                  key={`product-categories__${category.id}`}
                >
                  {category.name}
                </Category>
              ))}
            </Categories>
          ) : null}
          {isHoveringCategories && (
            <ScrollButtonRight
              className={`${PREFIX_CLASSNAME}__categories__scroll-button-right__wrapper`}
              onClick={() => handleScrollCategories()}
            >
              <ScrollButton
                classPrefix={`${PREFIX_CLASSNAME}__categories`}
                type='right'
                size='medium'
              />
            </ScrollButtonRight>
          )}
        </CategoriesWrapper>
      ) : null}
      <Container
        className={PREFIX_CLASSNAME}
        isHorizontal={isHorizontal}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        ref={ref}
      >
        {isHorizontal && isHovering && (
          <ScrollButtonLeft
            className={`${PREFIX_CLASSNAME}__scroll-button-left__wrapper`}
            onClick={() => handleScroll(true)}
          >
            <ScrollButton
              classPrefix={PREFIX_CLASSNAME}
              type='left'
              size='medium'
            />
          </ScrollButtonLeft>
        )}
        <Items
          className={`${PREFIX_CLASSNAME}__items`}
          isHorizontal={isHorizontal}
          existCategories={!!productCategories.length}
          ref={productsRef}
        >
          {isHorizontal ? (
            <EmptyColumn className={`${PREFIX_CLASSNAME}__empty-column`} />
          ) : null}
          {products.length ? products.map((row: Feature.Profile.Product, i) => (
            <Item
              classPrefix={PREFIX_CLASSNAME}
              product={row}
              isHorizontal={isHorizontal}
              isLast={i === products.length - 1 && !productIsLasted}
              onReadMore={handleReadMore}
              onClick={onClick}
              key={`products-row__${row.id}`}
            />
          )) : (
            <Item
              classPrefix={PREFIX_CLASSNAME}
              isHorizontal={isHorizontal}
              onClick={onClick}
              key={`products-row__empty`}
            />
          )}
          {isHorizontal ? (
            <EmptyColumn className={`${PREFIX_CLASSNAME}__empty-column`} />
          ) : null}
        </Items>
        {isHorizontal && isHovering && (
          <ScrollButtonRight
            className={`${PREFIX_CLASSNAME}__scroll-button-right__wrapper`}
            onClick={() => handleScroll()}
          >
            <ScrollButton
              classPrefix={PREFIX_CLASSNAME}
              type='right'
              size='medium'
            />
          </ScrollButtonRight>
        )}
      </Container>
    </>
  );
};

export default Products;
