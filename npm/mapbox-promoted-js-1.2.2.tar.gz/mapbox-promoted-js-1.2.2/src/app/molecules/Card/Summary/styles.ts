import styled from 'styled-components';

type Container = {
  enableProfile?: boolean;
};
type Row = {
  padding?: string
  cursor?: string;
};
type OpenerIcon = {
  isOpening?: boolean;
};
type Opener = {
  isOpening?: boolean;
  height?: number;
};
type LabelText = {
  lineClamp?: string;
};
type LabelAnchar = {
  lineClamp?: string;
};
type Value = {
  padding?: string;
  margin?: string;
  height?: string;
};

export const Container = styled.ul`
  padding: ${({ enableProfile }: Container) => enableProfile ? '15px 10px 45px' : '0 10px 15px 10px'};
  overflow-y: scroll;
  overflow-x: hidden;
  list-style: none;
`;
export const Row = styled.li`
  position: relative;
  padding: ${({ padding }: Row) => padding || '10px 0'};
  cursor: ${({ cursor }: Row) => cursor || 'auto'};
  &:first-child {
    padding: 0 0 10px 0;
  }
  &:last-child {
    padding: 10px 0 0 0;
  }
  & + & {
    :before {
      content: "";
      position: absolute;
      display: block;
      top: 0;
      width: 100%;
      border-top: 1px solid #e8eaed;
    }
  }
`;
export const Title = styled.span`
  display: block;
  margin: 0 0 8px 0;
  padding: 0 4px;
  font-weight: 600;
  font-size: 14px;
`;
export const OpenerIcon = styled.div`
  position: absolute;
  display: flex;
  justify-content: center;
  align-items: center;
  margin-left: 5px;
  padding: 2px;
  right: 0;
  width: 12px;
  min-width: 12px;
  height: 12px;
  min-height: 12px;
  font-size: 14px;
  color: #8d8d8d;
  transition: transform 0.2s;
  transform: rotate(${({ isOpening }: OpenerIcon) => isOpening ? '180' : '0'}deg);
`;
export const Opener = styled.div`
  overflow: hidden;
  height: ${({ isOpening, height }: Opener) => isOpening ? `${height}px` : '0'};
  transition: height 0.2s;
`;
export const BusinessHoursWrapper = styled.div`
  padding: 0 0 0 30px;
`;
export const Value = styled.div`
  position: relative;
  padding: ${({ padding }: Value) => padding || '0 4px'};
  margin: ${({ margin }: Value) => margin || '0'};
  height: ${({ height }: Value) => height || 'auto'};
  max-height: ${({ height }: Value) => height || 'auto'};
  background-color: transparent;
  transition: background-color 0.1s;
`;
export const Label = styled.div`
  display: flex;
  align-items: center;
`;
export const LabelText = styled.span`
  display: -webkit-box;
  overflow: hidden;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: ${({ lineClamp }: LabelText) => lineClamp || 1};
  word-break: break-all;
  font-size: 14px;
  line-height: 1.8;
`;
export const LabelTextWrapper = styled.div`
  display: flex;
  flex-direction: column;
`;
export const LabelAnchar = styled.a`
  display: -webkit-box;
  overflow: hidden;
  -webkit-box-orient: vertical;
  -webkit-line-clamp: ${({ lineClamp }: LabelAnchar) => lineClamp || 1};
  font-size: 14px;
  line-height: 1.8;
`;
export const Remarks = styled.span`
  font-size: 14px;
  line-height: 1.8;
  color: rgb(255, 67, 67);
`;
