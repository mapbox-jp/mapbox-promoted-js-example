import styled from 'styled-components';
import { CONFIG } from 'utils/config';

type Container = {
  isHorizontal?: boolean;
};
type CategoriesWrapper = {
  isHorizontal?: boolean;
};
type Categories = {
  width?: string;
  isHorizontal?: boolean;
};
type Category = {
  isSelected?: boolean;
};
type Items = {
  isHorizontal?: boolean;
  existCategories?: boolean;
};

export const Container = styled.div`
  position: relative;
  width: 100%;
  overflow-y: scroll;
  ${({ isHorizontal }: Container) => isHorizontal ? `` : `
    height: auto;
    max-height: auto;
  `};
`;
export const CategoriesWrapper = styled.div`
  position: relative;
  background: #ffffff;
  ${({ isHorizontal }: CategoriesWrapper) => isHorizontal ? `
    height: 30px;
  ` : `
    height: 57px;
    box-shadow: rgb(0 0 0 / 30%) 0px 0px 10px;
  `};
`;
export const Categories = styled.div`
  display: flex;
  width: ${({ width }: Categories ) => width};
  height; 30px;
  overflow-x: scroll;
  white-space: nowrap;
  scrollbar-width: none;
  &::-webkit-scrollbar {
    display: none;
  }
  ${({ isHorizontal }: Categories) => isHorizontal ? `
    position: relative;
  ` : `
    padding: 12px 0 15px 0;
  `};
`;
export const Category = styled.span`
  display: block;
  margin: 0 0 0 10px;
  padding: 5px 15px;
  background-color: ${({ isSelected }: Category) => isSelected ? CONFIG.BASE_COLOR : '#ecf7ff'};
  color: ${({ isSelected }: Category) => isSelected ? '#ffffff' : CONFIG.BASE_COLOR};
  border-radius: 15px;
  font-size: 13px;
  cursor: pointer;
  transition: color 0.1s;
  &:last-child {
    margin: 0 10px 0 10px;
  }
`;
export const Items = styled.ul`
  display: flex;
  margin: ${({ existCategories }: Items) => existCategories ? '10px 0 0' : '0'};
  list-style: none;
  ${({ isHorizontal }: Items) => isHorizontal ? `
    padding: 0;
    overflow-x: scroll;
    scrollbar-width: none;
    &::-webkit-scrollbar {
      display: none;
    }
  ` : `
    margin: 0;
    padding: 15px 10px 45px;
    flex-flow: row wrap;
  `};
`;
export const ScrollButtonLeft = styled.div`
  position: absolute;
  display: flex;
  align-items: center;
  padding: 0 0 0 8px;
  top: 0;
  left: 0;
  height: 100%;
`;
export const ScrollButtonRight = styled.div`
  position: absolute;
  display: flex;
  align-items: center;
  padding: 0 8px 0 0;
  top: 0;
  right: 0;
  height: 100%;
`;
export const EmptyColumn = styled.li`
  width: 10px;
  min-width: 10px;
`;
