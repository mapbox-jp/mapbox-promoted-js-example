import AjaxError from 'apis/ajaxError';

class Ajax implements Promoted.Ajax {
  private _request: XMLHttpRequest;
  private _baseUrl: string;
  private _options: Promoted.Ajax.Options;

  constructor(baseUrl?: string, options: Promoted.Ajax.Options = {}) {
    this._request = new XMLHttpRequest();
    this._baseUrl = baseUrl || '';
    this._options = options;
    if (this._options.isBlob) {
      this._request.responseType = 'blob';
    }
  }

  set baseURL(baseUrl: string) {
    this._baseUrl = baseUrl;
  }

  get isSuccess() {
    return (
      (this._request.status >= 200 && this._request.status < 300) || this._request.status === 0
    ) && this._request.response !== null;
  }

  private getResponseHeaders() {
    const responseHeaders: any = {};
    const headersStr = this._request.getAllResponseHeaders();
    const headersValue = headersStr.split('\r\n');
    for (const row of headersValue) {
      const splittedRow = row.split(': ');
      if (splittedRow[1]) {
        responseHeaders[splittedRow[0]] = splittedRow[1];
      }
    }
    return responseHeaders;
  }

  public createRequest(
    resolve: (value: any) => void,
    reject: (value: any) => void,
    method: string,
    url: string,
    isAsync: boolean,
  ) {
    const { headers } = this._options;
    this._request.open(method, `${this._baseUrl}${url}`, isAsync);
    if (headers) {
      for (const key of Object.keys(headers)) {
        this._request.setRequestHeader(key, headers[key]);
      }
    }
    this._request.onload = () => {
      if (this.isSuccess) {
        const parsedResponse = this._request.responseText ? JSON.parse(this._request.responseText) : {};
        const responseHeaders = this.getResponseHeaders();
        if (this._options.isBlob) {
          const reader = new FileReader();
          reader.onloadend = () => resolve([reader.result, responseHeaders]);
        } else {
          resolve([parsedResponse, responseHeaders]);
        }
      } else {
        reject(new AjaxError(this._request.responseText, this._request.status, { url: `${this._baseUrl}${url}` }));
      }
    };
    this._request.onerror = () => {
      reject(new AjaxError(this._request.responseText, this._request.status, { url: `${this._baseUrl}${url}` }));
    };
  }

  public post(
    url: string = '',
    data?: Object,
    options: Promoted.Ajax.RequestOptions = { isAsync: true }
  ) {
    const { isAsync } = options;
    return new Promise((resolve, reject) => {
      try {
        const dataString = JSON.stringify(data);
        this.createRequest(resolve, reject, 'POST', url, !!isAsync );
        this._request.send(dataString);
      } catch (error) {
        reject(error);
      }
    });
  }

  public get(
    url: string = '',
    options: Promoted.Ajax.RequestOptions = { isAsync: true }
  ) {
    const { isAsync } = options;
    return new Promise((resolve, reject) => {
      try {
        this.createRequest(resolve, reject, 'GET', url, !!isAsync );
        this._request.send();
      } catch (error) {
        reject(error);
      }
    });
  }
}

export default Ajax;
