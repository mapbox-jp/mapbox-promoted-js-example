import ajax from './ajax';
import { CONFIG } from 'utils/config';

type Option = {
  scaleIcon: number;
  sessionId?: string;
};

export function getFeatures(
  quadkey: string,
  options: Option = { scaleIcon: 1 }
): Promise<GeoJSON.FeatureCollection<GeoJSON.Geometry>> {
  const { scaleIcon, sessionId } = options;
  return new Promise((resolve, reject) => {
    const headers = {
      'Authorization': `Bearer ${CONFIG.ACCESS_TOKEN}`,
    };
    let url = `/loc/v1/features/quad/${quadkey}?scale_icon=${scaleIcon}`;
    url += CONFIG.MEDIA_ID ? `&media_id=${CONFIG.MEDIA_ID}` : '';
    url += sessionId ? `&session_id=${sessionId}` : '';
    return new ajax(CONFIG.BASE_URL, { headers }).get(url).then((response: any) => {
      resolve(response[0]);
    }).catch((error: Error) => {
      reject(error);
    });
  });
}
