import Promoted from './promoted';
import promotionSideCard from './promotionSideCard';

export {
  Promoted,
  promotionSideCard,
};
