import { CONFIG, layerId } from 'utils/config';
import { getQuadkeysOnBound } from 'utils/geometry';
import EventData from './eventData';
import { EVENT_TYPES, SESSION_EVENT_TYPES } from './helpers';

class EventAction implements Promoted.EventAction {
  private _promoted: Promoted.Core;
  private _session: Promoted.Session;
  private _source?: Promoted.Source;
  private _logger: Promoted.Logger;
  private _renderedFeatureLogsMap: { [featureId: string]: FeatureLog } = {};
  private _lastActionType?: string;
  private _updatedFeaturesAt: Date = new Date();
  private _mousemoveTimesetTimer?: { id: number; feature: Feature };

  constructor(
    promoted: Promoted.Core,
    session: Promoted.Session,
    logger: Promoted.Logger
  ) {
    this._promoted = promoted;
    this._session = session;
    this._logger = logger;

    this._session.on(
      SESSION_EVENT_TYPES.END_SESSION,
      () => this.endSession.bind(this)
    );
    this._lastActionType = 'load';

    this._promoted.plugin.on('load', this.load.bind(this));
    this._promoted.plugin.on('move', this.updateFeatures.bind(this));
    this._promoted.plugin.on('idle', this.updateFeatures.bind(this));
    this._promoted.plugin.on('moveend', this.moveend.bind(this));
    this._promoted.plugin.on('zoomend', this.zoomend.bind(this));
    this._promoted.plugin.on('click', this.updateSession.bind(this));
    this._promoted.plugin.on('click', this.click.bind(this), layerId)

    window.addEventListener('load', () => this.activate());
    document.readyState === 'complete' && this.activate();
  }

  set source(source: Promoted.Source) {
    this._source = source;
  }
  
  get lastActionType() {
    return this._lastActionType;
  }

  private activate() {
    window.updateConfig && window.updateConfig(CONFIG);
  }

  public load(event: mapboxgl.MapboxEvent<any> & mapboxgl.EventData) {
    try {
      this._session.start();
      this.updateSourceData(event);
      this._promoted.fire(new EventData(
        EVENT_TYPES.LOAD, {
          ...event
        }
      ));
    } catch(error) {
      console.error(error);
      (error instanceof Error) && this._logger.log('error_internal', error.stack || error.message);
    }
  }

  private updateSourceData(event: mapboxgl.MapboxEvent<any> & mapboxgl.EventData) {
    if (!this._source) {
      throw new Error('It did not initialize source module.');
    }
    const { ne, sw } = this._promoted.plugin.getBounds();
    const { quadkeys, tiles } = getQuadkeysOnBound(sw, ne, this._promoted.plugin.zoomLevel);
    this._source.addSource(quadkeys);
    this._promoted.fire(new EventData(
      EVENT_TYPES.SOURCEDATA, {
        ...event,
        tiles
      }
    ));
  }

  private moveend(event: any) {
    this._lastActionType = 'move';
    this._session.update();
    this.updateSourceData(event);
    this._promoted.fire(new EventData(
      EVENT_TYPES.MOVEEND, {
        ...event,
      }
    ));
  }

  private zoomend(event: any) {
    this._lastActionType = 'zoom';
    this._session.update();
    this.updateSourceData(event);
    this._promoted.fire(new EventData(
      EVENT_TYPES.ZOOMEND, {
        ...event,
      }
    ));
  }

  public click(event: mapboxgl.MapMouseEvent & { features?: mapboxgl.MapboxGeoJSONFeature[] | undefined; }) {
    try {
      this.clearMousemoveTimeset();
      const feature = event.features && event.features[0] as Feature;
      if (!feature) { return; }
      this._promoted.fire(new EventData(
        EVENT_TYPES.CLICK_PIN, {
          ...event,
        }
      ));
      this._promoted.show(feature);
    } catch (error: any) {
      console.error(error);
      this._logger.log('error_internal', error);
    }
  }

  public updateFeatures(event: mapboxgl.MapboxEvent & mapboxgl.EventData) {
    if (!this._source) {
      throw new Error('It did not initialize source module.');
    }
    const now = new Date();
    const diff = now.getTime() - this._updatedFeaturesAt.getTime();
    if (event.type === 'move' && diff > 500) {
      const { visibledFeatures, unvisibledFeatures } = this._source.updateFeatureVisibles();
      this._promoted.plugin.render(this._source.features, visibledFeatures, unvisibledFeatures);
      this._updatedFeaturesAt = new Date();
      this._promoted.fire(new EventData(
        EVENT_TYPES.SOURCEDATAEND, {
          ...event,
          visibledFeatures,
          unvisibledFeatures,
        }
      ));
    }
  }

  private clearMousemoveTimeset() {
    if (this._mousemoveTimesetTimer) {
      clearTimeout(this._mousemoveTimesetTimer.id);
      this._mousemoveTimesetTimer = undefined;
    }
  }

  private updateSession() {
    this._session.update();
  }

  private endSession() {
    const featureLogs = Object.values(this._renderedFeatureLogsMap);
    const updateRenderedFeatureLogs: { [featureId: string]: FeatureLog } = {};
    const unvisibledFeatureLogs: { [featureId: string]: FeatureLog } = {};

    for (const featureLog of featureLogs) {
      updateRenderedFeatureLogs[featureLog.feature.properties.feature_id] = {
        feature: featureLog.feature,
        startActionType: 'session',
        startZoomLevel: this._promoted.plugin.zoomLevel,
        visibleStartTime: Date.now(),
      };
      unvisibledFeatureLogs[featureLog.feature.properties.feature_id] = {
        ...featureLog,
        endActionType: 'session',
        endZoomLevel: this._promoted.plugin.zoomLevel,
        visibleEndTime: Date.now(),
      };
    }

    this._renderedFeatureLogsMap = updateRenderedFeatureLogs;
    
    featureLogs.length && (
      this._logger.visibles(this._session.sessionId, Object.values(unvisibledFeatureLogs))
    );
  }
}

export default EventAction;
