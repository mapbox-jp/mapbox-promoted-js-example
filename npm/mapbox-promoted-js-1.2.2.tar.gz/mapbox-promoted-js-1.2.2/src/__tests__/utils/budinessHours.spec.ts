import OpeningHours, {
  getBusinessHoursLabel,
} from 'utils/businessHours';

describe('utils/openingHours.OpeningHours.getTable', () => {
  it('Valid converting from 24/7', () => {
    expect(new OpeningHours('24/7').getTable()).toMatchObject({
      su: ['00:00-23:59'],
      mo: ['00:00-23:59'],
      tu: ['00:00-23:59'],
      we: ['00:00-23:59'],
      th: ['00:00-23:59'],
      fr: ['00:00-23:59'],
      sa: ['00:00-23:59'],
    });
  });
  it('Valid converting from Su 0:00-23:59; Mo 0:00-23:59; Tu 0:00-23:59; We 0:00-23:59; Th 0:00-23:59; Fr 0:00-23:59; Sa 0:00-23:59', () => {
    expect(new OpeningHours('Su 0:00-23:59; Mo 0:00-23:59; Tu 0:00-23:59; We 0:00-23:59; Th 0:00-23:59; Fr 0:00-23:59; Sa 0:00-23:59').getTable()).toMatchObject({
      su: ['00:00-23:59'],
      mo: ['00:00-23:59'],
      tu: ['00:00-23:59'],
      we: ['00:00-23:59'],
      th: ['00:00-23:59'],
      fr: ['00:00-23:59'],
      sa: ['00:00-23:59'],
    });
  });
  it('Valid converting from Mo 09:00-13:00', () => {
    expect(new OpeningHours('Mo 09:00-13:00').getTable()).toMatchObject({
      su: [],
      mo: ['09:00-13:00'],
      tu: [],
      we: [],
      th: [],
      fr: [],
      sa: [],
    });
  });
  it('Valid converting from Mo 09:00-13:00; 17:00-22:00', () => {
    expect(new OpeningHours('Mo 09:00-13:00, 17:00-22:00').getTable()).toMatchObject({
      su: [],
      mo: ['09:00-13:00', '17:00-22:00'],
      tu: [],
      we: [],
      th: [],
      fr: [],
      sa: [],
    });
  });
  it('Valid converting from Mo 09:00-13:00; 17:00-22:00; Sa 10:00-19:00', () => {
    expect(new OpeningHours('Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00').getTable()).toMatchObject({
      su: [],
      mo: ['09:00-13:00', '17:00-22:00'],
      tu: [],
      we: [],
      th: [],
      fr: [],
      sa: ['10:00-19:00'],
    });
  });
  it('Valid converting from Mo-Sa 10:00-23:00', () => {
    expect(new OpeningHours('Mo-Sa 10:00-23:00').getTable()).toMatchObject({
      su: [],
      mo: ['10:00-23:00'],
      tu: ['10:00-23:00'],
      we: ['10:00-23:00'],
      th: ['10:00-23:00'],
      fr: ['10:00-23:00'],
      sa: ['10:00-23:00'],
    });
  });
  it('Valid converting from Mo-Sa 10:00-15:00; 17:00-23:00', () => {
    expect(new OpeningHours('Mo-Sa 10:00-15:00, 17:00-23:00').getTable()).toMatchObject({
      su: [],
      mo: ['10:00-15:00', '17:00-23:00'],
      tu: ['10:00-15:00', '17:00-23:00'],
      we: ['10:00-15:00', '17:00-23:00'],
      th: ['10:00-15:00', '17:00-23:00'],
      fr: ['10:00-15:00', '17:00-23:00'],
      sa: ['10:00-15:00', '17:00-23:00'],
    });
  });
  it('Valid converting from Mo-Th 10:00-14:00; 15:00-20:00; Fr 10:00-14:00; 15:00-18:00', () => {
    expect(new OpeningHours('Mo-Th 10:00-14:00, 15:00-20:00; Fr 10:00-14:00, 15:00-18:00').getTable()).toMatchObject({
      su: [],
      mo: ['10:00-14:00', '15:00-20:00'],
      tu: ['10:00-14:00', '15:00-20:00'],
      we: ['10:00-14:00', '15:00-20:00'],
      th: ['10:00-14:00', '15:00-20:00'],
      fr: ['10:00-14:00', '15:00-18:00'],
      sa: [],
    });
  });
  it('Valid converting from Mo-Fr 10:00-20:00; PH off', () => {
    expect(new OpeningHours('Mo-Fr 10:00-20:00; PH off').getTable()).toMatchObject({
      su: [],
      mo: ['10:00-20:00'],
      tu: ['10:00-20:00'],
      we: ['10:00-20:00'],
      th: ['10:00-20:00'],
      fr: ['10:00-20:00'],
      sa: [],
    });
  });
  it('Valid converting from Mo-Fr 10:00-20:00; PH 10:00-12:00', () => {
    expect(new OpeningHours('Mo-Fr 10:00-20:00; PH 10:00-12:00').getTable()).toMatchObject({
      su: [],
      mo: ['10:00-20:00'],
      tu: ['10:00-20:00'],
      we: ['10:00-20:00'],
      th: ['10:00-20:00'],
      fr: ['10:00-20:00'],
      sa: [],
    });
  });
});

describe('utils/openingHours.getBusinessHoursLabel', () => {
  // 24 hours
  it("Valid business hours indication 24 hours during business hours '24/7'", () => {
    expect(getBusinessHoursLabel(
      '24/7',
      new Date('2022/12/14 10:00:00') // Wednesday
    )).toMatch('24時間営業');
  });
  it("Valid business hours indication 24 hours during business hours 'Su 0:00-23:59; Mo 0:00-23:59; Tu 0:00-23:59; We 0:00-23:59; Th 0:00-23:59; Fr 0:00-23:59; Sa 0:00-23:59'", () => {
    expect(getBusinessHoursLabel(
      'Su 0:00-23:59; Mo 0:00-23:59; Tu 0:00-23:59; We 0:00-23:59; Th 0:00-23:59; Fr 0:00-23:59; Sa 0:00-23:59',
      new Date('2022/12/18 23:59:00') // Sunday
    )).toMatch('24時間営業');
  });

  // Mo 09:00-13:00
  it("Valid business hours indication until 20 min before start of the business hours 'Mo 09:00-13:00'", () => {
    expect(getBusinessHoursLabel(
      'Mo 09:00-13:00',
      new Date('2022/12/12 08:50:00') // Monday
    )).toMatch('まもなく開店： 09:00 〜 13:00');
  });
  it("Valid business hours indication until 20 min before end of the business hours 'Mo 09:00-13:00'", () => {
    expect(getBusinessHoursLabel(
      'Mo 09:00-13:00',
      new Date('2022/12/12 12:50:00') // Monday
    )).toMatch('まもなく閉店： 09:00 〜 13:00');
  });
  it("Valid business hours indication during the business hours 'Mo 09:00-13:00'", () => {
    expect(getBusinessHoursLabel(
      'Mo 09:00-13:00',
      new Date('2022/12/12 11:00:00') // Monday
    )).toMatch('営業中： 09:00 〜 13:00');
  });
  it("Valid business hours indication just the time to start of the business hours 'Mo 09:00-13:00'", () => {
    expect(getBusinessHoursLabel(
      'Mo 09:00-13:00',
      new Date('2022/12/12 09:00:00') // Monday
    )).toMatch('営業中： 09:00 〜 13:00');
  });
  it("Valid business hours indication just the time to end of the business hours 'Mo 09:00-13:00'", () => {
    expect(getBusinessHoursLabel(
      'Mo 09:00-13:00',
      new Date('2022/12/12 13:00:00') // Monday
    )).toMatch('営業中： 09:00 〜 13:00');
  });
  it("Valid business hours indication before the business hours 'Mo 09:00-13:00', but it is the same day of the week", () => {
    expect(getBusinessHoursLabel(
      'Mo 09:00-13:00',
      new Date('2022/12/12 08:00:00') // Monday
    )).toMatch('営業時間外： 営業開始 09:00 〜 13:00');
  });
  it("Valid business hours indication after the business hours 'Mo 09:00-13:00', and the date label must be next week's", () => {
    expect(getBusinessHoursLabel(
      'Mo 09:00-13:00',
      new Date('2022/12/12 23:59:00') // Monday
    )).toMatch('営業時間外： 営業開始 月 09:00 〜 13:00');
  });
  it("Valid business hours indication out of the business hours 'Mo 09:00-13:00', but it is a different day of the week", () => {
    expect(getBusinessHoursLabel(
      'Mo 09:00-13:00',
      new Date('2022/12/18 08:00:00') // Sunday
    )).toMatch('営業時間外： 営業開始 月 09:00 〜 13:00');
  });
  it("Valid business hours indication out of the business hours 'Mo 09:00-13:00', but it is a different day of the week", () => {
    expect(getBusinessHoursLabel(
      'Mo 09:00-13:00',
      new Date('2022/12/25 08:00:00') // Sunday
    )).toMatch('営業時間外： 営業開始 月 09:00 〜 13:00');
  });

  // Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00
  it("Valid business hours indication until 20 min before start of the first business hours on Mooday 'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:0'", () => {
    expect(getBusinessHoursLabel(
      'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00',
      new Date('2022/12/12 08:50:00') // Monday
    )).toMatch('まもなく開店： 09:00 〜 13:00, 17:00 〜 22:00');
  });
  it("Valid business hours indication until 20 min before start of the second business hours on Mooday 'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00'", () => {
    expect(getBusinessHoursLabel(
      'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00',
      new Date('2022/12/12 16:50:00') // Monday
    )).toMatch('まもなく開店： 09:00 〜 13:00, 17:00 〜 22:00');
  });
  it("Valid business hours indication until 20 min before start of the business hours on Saturday 'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00'", () => {
    expect(getBusinessHoursLabel(
      'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00',
      new Date('2022/12/17 09:50:00') // Saturday
    )).toMatch('まもなく開店： 10:00 〜 19:00');
  });
  it("Valid business hours indication until 20 min before end of the first business hours on Monday 'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00'", () => {
    expect(getBusinessHoursLabel(
      'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00',
      new Date('2022/12/12 12:50:00') // Monday
    )).toMatch('まもなく閉店： 09:00 〜 13:00');
  });
  it("Valid business hours indication until 20 min before end of the second business hours on Monday 'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00'", () => {
    expect(getBusinessHoursLabel(
      'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00',
      new Date('2022/12/12 21:50:00') // Monday
    )).toMatch('まもなく閉店： 09:00 〜 13:00, 17:00 〜 22:00');
  });
  it("Valid business hours indication until 20 min before end of the business hours on Saturday 'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00'", () => {
    expect(getBusinessHoursLabel(
      'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00',
      new Date('2022/12/17 18:50:00') // Saturday
    )).toMatch('まもなく閉店： 10:00 〜 19:00');
  });
  it("Valid business hours indication during the first business hours on Monday 'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00'", () => {
    expect(getBusinessHoursLabel(
      'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00',
      new Date('2022/12/12 10:00:00') // Monday
    )).toMatch('営業中： 09:00 〜 13:00, 17:00 〜 22:00');
  });
  it("Valid business hours indication during the second business hours on Monday 'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00'", () => {
    expect(getBusinessHoursLabel(
      'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00',
      new Date('2022/12/12 18:00:00') // Monday
    )).toMatch('営業中： 09:00 〜 13:00, 17:00 〜 22:00');
  });
  it("Valid business hours indication just the time to start of the first business hours on Monday 'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00'", () => {
    expect(getBusinessHoursLabel(
      'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00',
      new Date('2022/12/12 09:00:00') // Monday
    )).toMatch('営業中： 09:00 〜 13:00, 17:00 〜 22:00');
  });
  it("Valid business hours indication just the time to end of the first business hours on Monday 'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00'", () => {
    expect(getBusinessHoursLabel(
      'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00',
      new Date('2022/12/12 13:00:00') // Monday
    )).toMatch('営業中： 09:00 〜 13:00, 17:00 〜 22:00');
  });
  it("Valid business hours indication just the time to start of the second business hours on Monday 'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00'", () => {
    expect(getBusinessHoursLabel(
      'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00',
      new Date('2022/12/12 17:00:00') // Monday
    )).toMatch('営業中： 09:00 〜 13:00, 17:00 〜 22:00');
  });
  it("Valid business hours indication just the time to end of the second business hours on Monday 'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00'", () => {
    expect(getBusinessHoursLabel(
      'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00',
      new Date('2022/12/12 22:00:00') // Monday
    )).toMatch('営業中： 09:00 〜 13:00, 17:00 〜 22:00');
  });
  it("Valid business hours indication during the business hours on Saturday 'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00'", () => {
    expect(getBusinessHoursLabel(
      'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00',
      new Date('2022/12/17 11:00:00') // Saturday
    )).toMatch('営業中： 10:00 〜 19:00');
  });
  it("Valid business hours indication before the first business hours on Monday 'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00', but the date is the same day of the week", () => {
    expect(getBusinessHoursLabel(
      'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00',
      new Date('2022/12/12 08:00:00') // Monday
    )).toMatch('営業時間外： 営業開始 09:00 〜 13:00, 17:00 〜 22:00');
  });
  it("Valid business hours indication before the second business hours on Monday 'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00', but the date is the same day of the week", () => {
    expect(getBusinessHoursLabel(
      'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00',
      new Date('2022/12/12 14:00:00') // Monday
    )).toMatch('営業時間外： 営業開始 09:00 〜 13:00, 17:00 〜 22:00');
  });
  it("Valid business hours indication before the business hours on Saturday 'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00', but the date is the same day of the week", () => {
    expect(getBusinessHoursLabel(
      'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00',
      new Date('2022/12/17 09:00:00') // Saturday
    )).toMatch('営業時間外： 営業開始 10:00 〜 19:00');
  });
  it("Valid business hours indication after the first business hours on Monday 'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00', but the date is the same day of the week", () => {
    expect(getBusinessHoursLabel(
      'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00',
      new Date('2022/12/12 16:00:00') // Monday
    )).toMatch('営業時間外： 営業開始 09:00 〜 13:00, 17:00 〜 22:00');
  });
  it("Valid business hours indication after the second business hours on Monday 'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00', but the date is the same day of the week", () => {
    expect(getBusinessHoursLabel(
      'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00',
      new Date('2022/12/12 23:00:00') // Monday
    )).toMatch('営業時間外： 営業開始 土 10:00 〜 19:00');
  });
  it("Valid business hours indication after the business hours on Saturday 'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00', and the date label must be next week's", () => {
    expect(getBusinessHoursLabel(
      'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00',
      new Date('2022/12/17 20:00:00') // Saturday
    )).toMatch('営業時間外： 営業開始 月 09:00 〜 13:00, 17:00 〜 22:00');
  });
  it("Valid business hours indication out of the business hours 'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00', but the date is a different day of the week", () => {
    expect(getBusinessHoursLabel(
      'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00',
      new Date('2022/12/18 08:00:00') // Sunday
    )).toMatch('営業時間外： 営業開始 月 09:00 〜 13:00, 17:00 〜 22:00');
  });
  it("Valid business hours indication out of the business hours 'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00', but the date is a different day of the week", () => {
    expect(getBusinessHoursLabel(
      'Mo 09:00-13:00, 17:00-22:00; Sa 10:00-19:00',
      new Date('2022/12/16 08:00:00') // Friday
    )).toMatch('営業時間外： 営業開始 土 10:00 〜 19:00');
  });


  // Mo-Th 10:00-14:00; 15:00-20:00; Fr 10:00-14:00; 15:00-18:00
  it("Valid business hours indication until 20 min before start of the first business hours on Tuesday 'Mo-Th 10:00-14:00; 15:00-20:00; Fr 10:00-14:00; 15:00-18:00'", () => {
    expect(getBusinessHoursLabel(
      'Mo-Th 10:00-14:00, 15:00-20:00; Fr 10:00-14:00, 15:00-18:00',
      new Date('2022/12/13 09:50:00') // Tuesday
    )).toMatch('まもなく開店： 10:00 〜 14:00, 15:00 〜 20:00');
  });
  it("Valid business hours indication until 20 min before start of the second business hours on Tuesday 'Mo-Th 10:00-14:00; 15:00-20:00; Fr 10:00-14:00; 15:00-18:00'", () => {
    expect(getBusinessHoursLabel(
      'Mo-Th 10:00-14:00, 15:00-20:00; Fr 10:00-14:00, 15:00-18:00',
      new Date('2022/12/13 14:50:00') // Tuesday
    )).toMatch('まもなく開店： 10:00 〜 14:00, 15:00 〜 20:00');
  });
  it("Valid business hours indication until 20 min before start of the first business hours on Friday 'Mo-Th 10:00-14:00; 15:00-20:00; Fr 10:00-14:00; 15:00-18:00'", () => {
    expect(getBusinessHoursLabel(
      'Mo-Th 10:00-14:00, 15:00-20:00; Fr 10:00-14:00, 15:00-18:00',
      new Date('2022/12/16 09:50:00') // Friday
    )).toMatch('まもなく開店： 10:00 〜 14:00, 15:00 〜 18:00');
  });
  it("Valid business hours indication until 20 min before start of the second business hours on Friday 'Mo-Th 10:00-14:00; 15:00-20:00; Fr 10:00-14:00; 15:00-18:00'", () => {
    expect(getBusinessHoursLabel(
      'Mo-Th 10:00-14:00, 15:00-20:00; Fr 10:00-14:00, 15:00-18:00',
      new Date('2022/12/16 14:50:00') // Friday
    )).toMatch('まもなく開店： 10:00 〜 14:00, 15:00 〜 18:00');
  });

  // Mo-Fr 10:00-20:00; PH off
  // Mo-Fr 10:00-20:00; PH 10:00-12:00'
});
