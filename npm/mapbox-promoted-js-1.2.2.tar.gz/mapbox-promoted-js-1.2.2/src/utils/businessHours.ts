import {
	format,
  isSameDay,
  isAfter,
  isBefore,
  startOfDay,
  endOfDay,
  startOfWeek,
  differenceInMinutes,
  differenceInCalendarDays,
  addDays,
  getDay
} from 'date-fns';

type BusinessHour = { start: Date; end: Date; };
type BusinessHours = { [key: string]: BusinessHour[]; };

export const DAYS = ['su', 'mo', 'tu', 'we', 'th', 'fr', 'sa'];
export const DAY_PAIRS = {
  su: '日曜日',
  mo: '月曜日',
  tu: '火曜日',
  we: '水曜日',
  th: '木曜日',
  fr: '金曜日',
  sa: '土曜日',
};

export const parseBusinessHours = (
  businessHoursString: string,
  date: Date = new Date()
) => {
  const oh = new OpeningHours(businessHoursString);
  const intervals = oh.getIntervals(date);
  let businessHours: { [key: string]: BusinessHour[] } = {
		su: [],
		mo: [],
		tu: [],
		we: [],
		th: [],
		fr: [],
		sa: [],
	};
  for (const day of DAYS) {
    const dayIntervals = intervals[day] || [];
		for (const interval of dayIntervals) {
			const { start, end } = interval || {};
			if (!start || !end) {
				continue;
			}
			if (isSameDay(start, end)) {
				const dayNo = getDay(start);
				const day = DAYS[dayNo];
				businessHours[day].push({ start, end });
			} else {
				for (let index = 0; index <= differenceInCalendarDays(end, start); index ++) {
					const updatedStart: Date = addDays(start, index);
					const dayNo = getDay(updatedStart);
					const day = DAYS[dayNo];
					businessHours[day].push({ start: updatedStart, end: endOfDay(updatedStart) });
				}
			}
		}
  }
  return businessHours;
};

export const getNearestBusinessHours = (
  businessHours: BusinessHours,
  now = new Date
) => {
	const startWeekDay = startOfWeek(now);
  for (let index = 0; index < 7; index ++) {
    const dayNo = getDay(addDays(startWeekDay, index));
		const dayBusinessHours = businessHours[DAYS[dayNo]];
    if (
			!!dayBusinessHours.length &&
			DAYS[dayNo] in businessHours &&
			isBefore(now, dayBusinessHours[dayBusinessHours.length - 1].end)
		) {
      return dayBusinessHours;
    }
	}
  return [];
};

const isOpeningSoon = (businessHours: BusinessHour[], now: Date) => {
	let enable = false;
	let label = 'まもなく開店： ';
	businessHours.forEach((businessHoursRow, index) => {
		const { start, end } = businessHoursRow;
		const diffStart = differenceInMinutes(start, now);
		const isRangeBeforeOpening20Min = isBefore(now, start) && 0 < diffStart && diffStart <= 20;
		if (isRangeBeforeOpening20Min) { // まもなく開店：xx:xx 〜 yy:yy
			enable = true;
		}
		label += `${index !== 0 ? ', ' : ''}${format(start, 'HH:mm')} 〜 ${format(end, 'HH:mm')}`;
	});
	return enable ? label : '';
};

const isClosingSoon = (businessHours: BusinessHour[], now: Date) => {
	let enable = false;
	let label = 'まもなく閉店： ';
	businessHours.forEach((businessHoursRow, index) => {
		const { start, end } = businessHoursRow;
		const diffEnd = differenceInMinutes(end, now);
		const isRangeBeforeClosing20Min = isBefore(now, end) && 0 < diffEnd && diffEnd <= 20;
		if (isRangeBeforeClosing20Min) { // まもなく閉店：xx:xx 〜 yy:yy
			enable = true;
		}
		label += `${index !== 0 ? ', ' : ''}${format(start, 'HH:mm')} 〜 ${format(end, 'HH:mm')}`;
	});
	return enable ? label : '';
};

const isOpening = (businessHours: BusinessHour[], now: Date) => {
	let enable = false;
	let label = '営業中： ';
	businessHours.forEach((businessHoursRow, index) => {
		const { start, end } = businessHoursRow;
		const diffStartMinutes = differenceInMinutes(start, now);
		const diffEndMinutes   = differenceInMinutes(now, end);
		const isRange = isAfter(now, start) && isBefore(now, end) || diffStartMinutes === 0 || diffEndMinutes === 0;
		if (isRange) { // 営業中：xx:xx 〜 yy:yy
			enable = true;
		}
		label += `${index !== 0 ? ', ' : ''}${format(start, 'HH:mm')} 〜 ${format(end, 'HH:mm')}`;
	});
	return enable ? label : '';
};

const isClosingToday = (businessHours: BusinessHour[], now: Date) => {
	let enable = false;
	let label = '営業時間外： 営業開始 ';
	// Skip the process, when if it is after the last business hours at the day
	if (!!businessHours.length && isAfter(now, businessHours[businessHours.length - 1].end)) {
		return '';
	}
	businessHours.forEach((businessHoursRow, index) => {
		const { start, end } = businessHoursRow;
		const isToday = isSameDay(now, start);
		if (isToday) { // 営業時間外：営業開始 xx:xx 〜 yy:yy
			enable = true;
		}
		label += `${index !== 0 ? ', ' : ''}${format(start, 'HH:mm')} 〜 ${format(end, 'HH:mm')}`;
	});
	return enable ? label : '';
};

const isClosing = (businessHours: BusinessHours, now: Date, businessHoursStr: string) => {
  let nearestBusinessHours = getNearestBusinessHours(businessHours, now);
	if (!nearestBusinessHours.length) {
		businessHours = parseBusinessHours(businessHoursStr, addDays(now, 7));
		nearestBusinessHours = getNearestBusinessHours(businessHours, now);
	}
  if (nearestBusinessHours) { // 営業時間外：営業開始 ○ xx:xx〜yy:yy
		let enable = false;
		let label = '営業時間外： 営業開始 ';
		nearestBusinessHours.forEach((businessHoursRow, index) => {
			const { start, end } = businessHoursRow;
			if (index === 0) {
				const day = DAYS[getDay(start)];
				const dayLabel = DAY_PAIRS[day as 'mo'];
				label += `${dayLabel.slice(0, 1)} `;
			}
			enable = true;
			label += `${index !== 0 ? ', ' : ''}${format(start, 'HH:mm')} 〜 ${format(end, 'HH:mm')}`;
		});
		return enable ? label : '';
  }
	return '';
};

export const getBusinessHoursLabel = (businessHoursStr: string, now = new Date): string => {
  const businessHours = parseBusinessHours(businessHoursStr, now);
	const is24Hours = !!Object.keys(businessHours).filter((day) => {
		const { start, end } = businessHours[day][0] || {};
    return start && end &&
			differenceInMinutes(start, startOfDay(start)) === 0 &&
			differenceInMinutes(end, endOfDay(start)) === 0;
	}).length;
	if (is24Hours) { // 24時間営業
		return '24時間営業';
	}
  for (const day of Object.keys(businessHours)) {
		const openingSoonLabel = isOpeningSoon(businessHours[day], now);
		if (openingSoonLabel) {
			return openingSoonLabel;
		}
		const closingSoonLabel = isClosingSoon(businessHours[day], now);
		if (closingSoonLabel) {
			return closingSoonLabel;
		}
		const openingLabel = isOpening(businessHours[day], now);
		if (openingLabel) {
			return openingLabel;
		}
		const closingTodayLabel = isClosingToday(businessHours[day], now);
		if (closingTodayLabel) {
			return closingTodayLabel;
		}
  }
	const closingLabel = isClosing(businessHours, now, businessHoursStr);
	if (closingLabel) {
		return closingLabel;
	}
  return '詳細はお問い合わせください';
};

/*
 * Copied and originated from this repo, that is MIT Lisence.
 * https://github.com/wbkd/simple-opening-hours/blob/master/src/simple-opening-hours.ts
 */
export default class OpeningHours {
  private _openingHours: { [key: string]: string[]; };
	private _alwaysOpen?: boolean;
	private _alwaysClosed?: boolean;

	constructor(input: string) {
		this._openingHours = {
			su: [],
			mo: [],
			tu: [],
			we: [],
			th: [],
			fr: [],
			sa: [],
			ph: []
		};
		this.parse(input);
	}

  get alwaysOpen() {
    return this._alwaysOpen;
  }

  get alwaysClosed() {
    return this._alwaysClosed;
  }

	// Parses the input and creates openingHours Object
	private parse(input: string) {
		const parts = input.toLowerCase().replace(/\s*([-:,;])\s*/g, '$1').split(';');
		parts.forEach(part => this.parseHardPart(part));
	}

	private parseHardPart(part: string) {
		if (part == '24/7') {
			part = 'mo-su 00:00-23:59';
		}
		let segments = part.split(/\ |\,/);
		let tempData: { [key: string]: string[]; } = {};
		let days: string[] = [];
		let times: string[] = [];
		segments.forEach((segment) => {
			if (this.checkDay(segment)) {
				if (times.length == 0) {
					days = days.concat(this.parseDays(segment));
				} else {
					// append
					days.forEach((day) => {
						if (tempData[day]) {
							tempData[day] = tempData[day].concat(times);
						} else {
							tempData[day] = times;
						}
					})
					days = this.parseDays(segment);
					times = [];
				}
			} else if (this.isTimeRange(segment)) {
				if (segment === 'off') {
					times = [];
				} else {
					segment = segment.replace(/^([0-9]{1})(:[0-9]{2})/, '0$1$2');
					segment = segment.replace(/\-[0-9]{1}:[0-9]{2}/, '0$1$2');
					times.push(segment);
				}
			}
		});

		// commit last times to it days
		days.forEach((day) => {
			if (tempData[day]) {
				tempData[day] = tempData[day].concat(times);
			} else {
				tempData[day] = times;
			}
		});

		// apply data to main obj
		for (let key in tempData) {
			this._openingHours[key] = tempData[key];
		}
	}

	private parseDays(part: string): string[] {
		let days: string[] = [];
		let softparts = part.split(',');
		softparts.forEach((part) => {
			let rangecount = (part.match(/\-/g) || []).length;
			if (rangecount == 0) {
				days.push(part);
			} else {
				days = days.concat(this.calcDayRange(part))
			}
		});
		return days;
	}

	/**
	 * Calculates the days in range 'mo-we' -> ['mo', 'tu', 'we']
	 */
	private calcDayRange(range: string): string[] {
		let def: { [key: string]: number; } = {
			su: 0,
			mo: 1,
			tu: 2,
			we: 3,
			th: 4,
			fr: 5,
			sa: 6
		}
		let rangeElements = range.split('-');
		let dayStart = def[rangeElements[0]];
		let dayEnd = def[rangeElements[1]];
		let numberRange = this.calcRange(dayStart, dayEnd, 6);
		let outRange: string[] = [];
		numberRange.forEach(n => {
			for (let key in def) {
				def[key] == n && outRange.push(key);
			}
		});
		return outRange;
	}

	/**
	 * Creates a range between two number.
	 * if the max value is 6 a range bewteen 6 and 2 is 6, 0, 1, 2
	 */
	private calcRange(min: number, max: number, maxval: number): number[] {
		if (min == max) {
			return [min];
		}
		let range = [min];
		let rangepoint = min;
		while (rangepoint < ((min < max) ? max : maxval)) {
			rangepoint++;
			range.push(rangepoint);
		}
		if (min > max) {
			// add from first in list to max value
			range = range.concat(this.calcRange(0, max, maxval));
		}
		return range;
	}

	// Check if string is time range
	private isTimeRange(input: string): boolean {
		// e.g. 09:00+
		if (input.match(/[0-9]{1,2}:[0-9]{2}\+/)) {
			return true;
		} else if (input.match(/[0-9]{1,2}:[0-9]{2}\-[0-9]{1,2}:[0-9]{2}/)) { // e.g. 08:00-12:00
			return true;
		} else if (input.match(/off/)) { // off
			return true;
		}
		return false;
	}

	// check if string is day or dayrange
	private checkDay(input: string): boolean {
		let days = ['mo', 'tu', 'we', 'th', 'fr', 'sa', 'su', 'ph'];
		if (input.match(/\-/g)) {
			let rangeElements = input.split('-');
			if (days.indexOf(rangeElements[0]) !== -1 && days.indexOf(rangeElements[1]) !== -1) {
				return true;
			}
		} else if (days.indexOf(input) !== -1) {
			return true;
		}
		return false;
	}

	public getTable() {
		return this._openingHours;
	}

	public getIntervals(date: Date = new Date) {
		const startDateOfWeek = startOfWeek(date);
		const intervals: { [key: string]: { start: Date; end: Date; }[] } = {
			su: [],
			mo: [],
			tu: [],
			we: [],
			th: [],
			fr: [],
			sa: [],
			ph: []
		};
		DAYS.forEach((day, index) => {
			const openingHours = this._openingHours[day];
			for (const openingHour of openingHours) {
				const openingHourMatch = openingHour.match(/([0-9]{1,2}:[0-9]{2})\-([0-9]{1,2}:[0-9]{2})/);
				const updatedDate = addDays(startDateOfWeek, index);
				if (openingHourMatch) {
					intervals[day].push({
						start: new Date(format(updatedDate, `yyyy/MM/dd ${openingHourMatch[1]}`)),
						end: new Date(format(updatedDate, `yyyy/MM/dd ${openingHourMatch[2]}`)),
					});
				}
			}
		});
		return intervals;
	}
}
