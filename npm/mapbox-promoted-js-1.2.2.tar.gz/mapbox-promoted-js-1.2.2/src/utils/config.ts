export const CONFIG: {
  ACCESS_TOKEN: string;
  MEDIA_ID?: string;
  SESSION_ID?: string;
  CONTAINER?: HTMLElement;
  BASE_URL: string;
  LOG_URL: string;
  BASE_COLOR: string;
  SMALL_MAX_WIDTH: number;
  MEDIUM_MAX_WIDTH: number;
  LARGE_MAX_WIDTH: number;
  SCALE_ICON: number;
  MEDIA_MODAL?: boolean;
  DEBUG?: boolean;
} = {
  ACCESS_TOKEN: '',
  MEDIA_ID: undefined,
  SESSION_ID: undefined,
  CONTAINER: undefined,
  BASE_URL: 'https://mbp.mapbox-lab.com',
  LOG_URL: 'https://mbp.mapbox-lab.com',
  BASE_COLOR: '#1a73e8',
  SMALL_MAX_WIDTH: 640,
  MEDIUM_MAX_WIDTH: 768,
  LARGE_MAX_WIDTH: 1024,
  SCALE_ICON: 1,
  MEDIA_MODAL: false,
  DEBUG: false,
};
export const sourceId = 'promoted-source';
export const layerId = 'promoted-layer';
export const DEFAULT_BANNER_SIZE: { WIDTH: number; HEIGHT: number; } = {
  WIDTH: 400,
  HEIGHT: 110,
};
