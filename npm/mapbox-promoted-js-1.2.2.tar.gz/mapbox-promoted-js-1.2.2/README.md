# Mapbox Promoted JS


## Start running example web application

```bash
cd example
npm run start
```

## Start watching library

```bash
npm run watch
```

## Unit tests

Run the whole unit tests
```bash
jest --config ./jest.config.js
```

Run the specific unit test
```bash
jest --config ./jest.config.js src/__tests__/utils/budinessHours.spec.ts
```
