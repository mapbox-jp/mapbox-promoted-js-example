# Mapbox Promoted JS


## Start running example web application

```bash
cd example
npm run start
```

## Start watching library

```bash
npm run watch
```
