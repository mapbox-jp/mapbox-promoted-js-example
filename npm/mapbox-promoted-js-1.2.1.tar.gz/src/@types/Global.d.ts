type Config = {
  BASE_URL: string;
  LOG_URL: string;
  ACCESS_TOKEN: string;
};
declare var renderApp: (config: Config) => void;
