type Config = {
  BASE_URL: string;
  LOG_URL: string;
  ACCESS_TOKEN: string;
  BASE_COLOR: string;
  MEDIA_MODAL: boolean;
};
declare var renderApp: (config: Config) => void;
