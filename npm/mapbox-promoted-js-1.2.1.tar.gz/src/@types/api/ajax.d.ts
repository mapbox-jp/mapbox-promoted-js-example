declare namespace Promoted {
  namespace Ajax {
    type Headers = {
      [key: string]: any;
    };
    type Options = {
      headers?: Headers;
      isBlob?: boolean;
    };
    type RequestOptions = {
      isAsync?: boolean;
      responseHeaders?: string[];
    };
    type ResponseHeaders = {
      link?: string;
    };
  }

  class Ajax {
    constructor(baseUrl?: string, options?: Promoted.Ajax.Options);
    set baseURL(baseUrl: string);
    get isSuccess(): boolean;
    public createRequest(
      resolve: (value: any) => void,
      reject: (value: any) => void,
      method: string,
      url: string,
      isAsync: boolean,
      responseHeaders: string[],
    ): any;
    public post(
      url: string,
      data?: Object,
      options?: Promoted.Ajax.RequestOptions
    ): any;
    public get(
      url: string,
      options?: Promoted.Ajax.RequestOptions
    ): any;
  }
}
