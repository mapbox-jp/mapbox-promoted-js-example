declare var showPromotionCard: ((
  feature: Feature,
  onClick?: (type: Promotion.ClickTypes, feature: Feature) => void,
  onClose?: (feature: Feature) => void
) => void) | undefined;
declare var updatePromotionCard: ((feature: Feature) => void) | undefined;
declare var closePromotionCard: (() => void) | undefined;
