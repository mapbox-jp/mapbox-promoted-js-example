declare namespace PromotionPopup {
  type InputOptions = {
    isSmall?: boolean;
  };
}

declare var showPromotionPopup: ((
  popup: Promoted.PromotionPopup,
  feature: Feature,
  onClick?: (type: Promotion.ClickTypes, feature: Feature) => void,
  onClose?: (feature: Feature) => void,
  options?: PromotionPopup.InputOptions
) => void) | undefined;
declare var closePromotionPopup: ((feature: Feature) => boolean) | undefined;
