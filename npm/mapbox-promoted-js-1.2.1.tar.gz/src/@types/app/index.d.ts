declare namespace Promotion {
  const CLICK_TYPES: {
    readonly ATTRIBUTION: 'attribution';
    readonly QUOTE: 'quote';
    readonly CARD: 'Card';
    readonly BANNER: 'BannerDetail';
    readonly SUMMARY: 'Summary';
    readonly ADDRESS: 'Address';
    readonly BUSINESS_HOURS: 'BusinessHours';
    readonly CALL: 'Call';
    readonly ROUTE: 'Route';
    readonly NAVIGATION: 'Navigation';
    readonly LINE: 'Line';
    readonly INSTAGRAM: 'Instagram';
    readonly FACEBOOK: 'Facebook';
    readonly TWITTER: 'Twitter';
    readonly APP_STORE: 'AppStore';
    readonly PLAY_STORE: 'PlayStore';
    readonly DETAIL: 'Detail';
    readonly TOGGLE: 'Toggle';
    readonly TAB: 'Tab';
    readonly NEWS: 'News';
    readonly PRODUCT: 'Product';
    readonly MEDIA: 'Media';
    readonly NEWS_ITEM: 'NewsItem';
    readonly PRODUCT_ITEM: 'ProductItem';
    readonly MEDIA_ITEM: 'MediaItem';
  };
  export type ClickTypes = typeof CLICK_TYPES[keyof typeof CLICK_TYPES];
}
