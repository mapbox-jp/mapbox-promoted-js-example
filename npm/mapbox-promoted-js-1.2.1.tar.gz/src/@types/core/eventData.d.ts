declare namespace Promoted {
  namespace EventData {
    type EventTypes = Promoted.EventTypes | Promoted.Session.EventTypes;
  }

  class EventData {
    type: EventData.EventTypes;
    data: Object;
    constructor(type: EventData.EventTypes, data?: Object);
  } 
}
