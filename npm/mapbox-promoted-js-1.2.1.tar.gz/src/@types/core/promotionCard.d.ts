declare namespace Promoted {
  class PromotionCard {
    constructor(promoted: Promoted.Core, source: Promoted.Source);
    get feature(): Feature | undefined;
    public show(feature: Feature): void;
    public close(): void;
  }
}
