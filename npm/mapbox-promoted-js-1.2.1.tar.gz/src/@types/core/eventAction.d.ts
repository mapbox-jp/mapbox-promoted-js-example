declare namespace Promoted {
  type Tile = {
    x: number;
    y: number;
    z: number;
    quadkey: string;
  };

  class EventAction {
    constructor(map: mapboxgl.Map, promoted: Promoted.Core, session: Promoted.Session, logger: Promoted.Logger);
    set source(source: Source);
    get lastActionType(): string | undefined;
    public load(event: mapboxgl.MapboxEvent<any> & mapboxgl.EventData): void;
    public click(event: mapboxgl.MapMouseEvent & { features?: mapboxgl.MapboxGeoJSONFeature[] | undefined; } & mapboxgl.EventData): void;
    public updateFeatures(event: mapboxgl.MapboxEvent & mapboxgl.EventData): void;
  }
}
