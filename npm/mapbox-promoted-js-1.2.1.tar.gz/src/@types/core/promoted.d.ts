declare namespace Promoted {
  namespace Core {
    type Options = {
      map: PromotedPlugin.Plugin | mapboxgl.Map;
      accessToken: string;
      container: HTMLElement;
      baseUrl?: string;
      logUrl?: string;
    };
  }
  class Core implements Promoted.Event {
    constructor(map: mapboxgl.Map, token: string, options?: Promoted.Core.Options);
    get map(): any;
    get plugin(): PromotedPlugin.Plugin;
    get tilesets(): { [quadkey: string]: Feature[] };
    get features(): Feature[];
    get promotionPopup(): PromotionPopup;
    get promotionSideCard(): PromotionSideCard;
    public show(feature: Feature): void;
    public visibleLayer(): void;
    public hideLayer(): void;
    public selectFeature(feature: Feature): void;
    public deselectLayer(): void;
    public reload(): void;

    // Promoted.Event
    public on(type: Promoted.EventTypes, listener: Promoted.Event.Listener): void;
    public off(type: Promoted.EventTypes, listener: Promoted.Event.Listener): void;
    public fire(event: Promoted.EventData): void;
  }
}
