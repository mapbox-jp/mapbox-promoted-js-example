import { isUrl, parseBusinessHours } from 'utils/string';

describe('utils/string.isUrl', () => {
  const httpsGeojsonUrl = 'https://test.co.jp/test.json';
  const httpGeojsonUrl = 'http://test.co.jp/test.json';
  const mapboxSourceUrl = 'mapbox://mapbox-ads.abcdefg';

  it('is http geojson', () => (
    expect(isUrl(httpsGeojsonUrl)).toEqual(true)
  ));

  it('is https geojson', () => (
    expect(isUrl(httpGeojsonUrl)).toEqual(true)
  ));

  it('is mapbox source url', () => (
    expect(isUrl(mapboxSourceUrl)).toEqual(false)
  ));
});

describe('utils/string.parseBusinessHours', () => {
  const date = new Date('6/30/2022 12:00:00');
  date.toLocaleString('ja');

  describe('Valid business hours that is bewteen monday and friday', () => {
    const osmString = 'Mo-Fr 10:00-17:30';
    expect(parseBusinessHours(osmString)).toMatchObject({
      mon: ['10:00 ~ 17:30'],
      tue: ['10:00 ~ 17:30'],
      wed: ['10:00 ~ 17:30'],
      thu: ['10:00 ~ 17:30'],
      fri: ['10:00 ~ 17:30'],
    });
  });

  describe('Valid multiple business hours that is bewteen monday and friday', () => {
    const osmString = 'Mo-Fr 10:00-12:00,13:00-17:30';
    expect(parseBusinessHours(osmString)).toMatchObject({
      mon: ['10:00 ~ 12:00', '13:00 ~ 17:30'],
      tue: ['10:00 ~ 12:00', '13:00 ~ 17:30'],
      wed: ['10:00 ~ 12:00', '13:00 ~ 17:30'],
      thu: ['10:00 ~ 12:00', '13:00 ~ 17:30'],
      fri: ['10:00 ~ 12:00', '13:00 ~ 17:30'],
    });
  });

  describe('Valid multiple business hours between monday and friday, but tuesday is off', () => {
    const osmString = 'Mo-Fr 10:00-12:00,13:00-17:30; Tu Off';
    expect(parseBusinessHours(osmString)).toMatchObject({
      mon: ['10:00 ~ 12:00', '13:00 ~ 17:30'],
      wed: ['10:00 ~ 12:00', '13:00 ~ 17:30'],
      thu: ['10:00 ~ 12:00', '13:00 ~ 17:30'],
      fri: ['10:00 ~ 12:00', '13:00 ~ 17:30'],
    });
  });

  describe('Valid multiple business hours between monday and friday, but tuesday has different one', () => {
    const osmString = 'Mo-Fr 10:00-12:00,13:00-17:30; Tu 13:00-16:30';
    expect(parseBusinessHours(osmString)).toMatchObject({
      mon: ['10:00 ~ 12:00', '13:00 ~ 17:30'],
      tue: ['13:00 ~ 16:30'],
      wed: ['10:00 ~ 12:00', '13:00 ~ 17:30'],
      thu: ['10:00 ~ 12:00', '13:00 ~ 17:30'],
      fri: ['10:00 ~ 12:00', '13:00 ~ 17:30'],
    });
  });

  describe('Inalid business hours that is bewteen monday and friday', () => {
    const osmString = 'Mo-Fr 10:00-16:30';
    expect(parseBusinessHours(osmString)).not.toMatchObject({
      mon: ['10:00 ~ 17:30'],
      tue: ['10:00 ~ 17:30'],
      wed: ['10:00 ~ 17:30'],
      thu: ['10:00 ~ 17:30'],
      fri: ['10:00 ~ 17:30'],
    });
  });

  describe('Invalid multiple business hours between monday and friday, but tuesday is off', () => {
    const osmString = 'Mo-Fr 10:00-12:00,13:00-17:30; Tu Off';
    expect(parseBusinessHours(osmString)).not.toMatchObject({
      mon: ['10:00 ~ 12:00', '13:00 ~ 17:30'],
      tue: ['10:00 ~ 12:00', '13:00 ~ 17:30'],
      wed: ['10:00 ~ 12:00', '13:00 ~ 17:30'],
      thu: ['10:00 ~ 12:00', '13:00 ~ 17:30'],
      fri: ['10:00 ~ 12:00', '13:00 ~ 17:30'],
    });
  });

  describe('Invalid multiple business hours between monday and friday, but tuesday has different one', () => {
    const osmString = 'Mo-Fr 10:00-12:00,13:00-17:30; Tu 13:00-16:30';
    expect(parseBusinessHours(osmString)).not.toMatchObject({
      mon: ['10:00 ~ 12:00', '13:00 ~ 17:30'],
      tue: ['10:00 ~ 12:00', '13:00 ~ 17:30'],
      wed: ['10:00 ~ 12:00', '13:00 ~ 17:30'],
      thu: ['10:00 ~ 12:00', '13:00 ~ 17:30'],
      fri: ['10:00 ~ 12:00', '13:00 ~ 17:30'],
    });
  });
});
