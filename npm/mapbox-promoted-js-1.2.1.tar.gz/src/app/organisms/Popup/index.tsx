import ReactDOM from 'react-dom';
import React, { useRef, useEffect, useState, useMemo, useCallback } from 'react';
import { PROMOTION_TYPES } from 'core/helpers';
import { isSmall, isMedium } from 'utils/browser';
import Card, { CARD_TYPES } from 'molecules/Card';
import {
  GlobalStyle,
  Container,
} from './styles';

type CloseHandler = {
  featureId: string;
  close: () => void;
};
let closeHandlers: CloseHandler[] = [];

window.showPromotionPopup = (
  popup: Promoted.PromotionPopup,
  feature: Feature,
  onClick?: (type: Promotion.ClickTypes, feature: Feature) => void,
  onClose?: (feature: Feature) => void,
) => {
  const element = document.querySelector(`.mapbox-promoted-popup__content__feature-${feature.properties.feature_id}`);
  if (!element) { return; }
  const content = element.querySelector('.mapbox-promoted-popup__content');
  !content && ReactDOM.render(
    <PromotionPopup
      popup={popup}
      feature={feature}
      onClick={onClick}
      onClose={onClose}
    />,
    element
  );
};

window.closePromotionPopup = (feature: Feature): boolean => {
  const { properties } = feature;
  const { feature_id } = properties;
  const closeHandler = closeHandlers.find(handler => handler.featureId === feature_id);
  if (!closeHandler) { return false; }
  closeHandler.close();
  closeHandlers = closeHandlers.filter(closeHandler => closeHandler.featureId !== feature_id);
  return true;
};

type Props = {
  popup: Promoted.PromotionPopup;
  feature: Feature;
  onClick?: (type: Promotion.ClickTypes, feature: Feature) => void;
  onClose?: (feature: Feature) => void;
};

const PromotionPopup: React.FC<Props> = props => {
  const { popup, feature, onClick, onClose } = props;
  const { properties } = feature;
  const { promotion_type, feature_id } = properties;

  const ref = useRef<HTMLDivElement>(null);
  const [isFadeout, setIsFadeout] = useState(false);
  const [isRendered, setIsRendered] = useState(false);

  const enableScale = useMemo(() =>
    promotion_type === undefined || promotion_type === PROMOTION_TYPES.CARD, []);

  const handleClick = (type: Promotion.ClickTypes) => {
    onClick && onClick(type, feature);
  };
  const handleMouseLeave = useCallback(
    (event: Event) => {
      const { x, y } = event as MouseEvent;
      const clickedFeature = popup.getFeatureByPoints(x, y);
      if (
        !clickedFeature ||
        clickedFeature.properties.feature_id !== feature.properties.feature_id
      ) {
        close();
      }
    }, []
  );
  const handleClickOutside = useCallback(
    (event: MouseEvent) => {
      const clickedFeature = popup.getFeatureByPoints(event.x, event.y);
      if (
        ref.current &&
        !ref.current.contains(event.target as Node) &&
        (!clickedFeature || clickedFeature.properties.feature_id !== feature.properties.feature_id)
      ) {
        close();
      }
    }, []
  );
  const handleResize = useCallback(
    () => {
      if (ref.current) {
        const clientWidth = ref.current.clientWidth;
        const clientHeight = ref.current.clientHeight;
        const popupContent = document.querySelector(`.mapbox-promoted-popup__content__feature-${feature_id}`) as HTMLElement;
        const popup = document.querySelector(`.mapbox-promoted-popup__feature-${feature_id}`) as HTMLElement;
        const width = enableScale ? `calc(${clientWidth}px * ${isSmall() ? '0.8' : isMedium() ? '0.9' : '1.0'})` : `${clientWidth}px`;
        const height = enableScale ? `calc(${clientHeight}px * ${isSmall() ? '0.8' : isMedium() ? '0.9' : '1.0'})` : `${clientHeight}px`;
        if (popupContent) {
          popupContent.style.width = width;
          popupContent.style.height = height;
        }
        if (popup) {
          popup.style.width = width;
          popup.style.height = height;
        }
        setIsRendered(true);
      }
    }, []
  );
  const renderPromotion = () => {
    switch (promotion_type) {
      case PROMOTION_TYPES.CARD:
      default:
        return (
          <Card 
            classPrefix='promotion-popup-card'
            feature={feature}
            cardType={CARD_TYPES.POPUP}
            isFadeout={isFadeout}
            onClick={handleClick}
            ref={ref}
          />
        );
    }
  };
  const close = () => {
    setIsFadeout(true);
    setTimeout(() => {
      onClose && onClose(feature);
      const popup = document.querySelector(`.mapbox-promoted-popup__feature-${feature_id}`);
      if (!popup || !popup.parentNode) { return; }
      popup.parentNode.removeChild(popup);
    }, 150);
    removeEventListeners();
  };
  const removeEventListeners = () => {
    const popup = document.querySelector(`.mapbox-promoted-popup__feature-${feature_id}`);
    popup && popup.removeEventListener('mouseleave', handleMouseLeave)
    document.removeEventListener('click', handleClickOutside);
    window.removeEventListener('resize', handleResize);
  };

  useEffect(() => {
    closeHandlers.push({ featureId: feature_id, close: () => close() });
    const popup = document.querySelector(`.mapbox-promoted-popup__feature-${feature_id}`);
    popup && popup.addEventListener('mouseleave', handleMouseLeave)
    document.addEventListener('click', handleClickOutside);
    window.addEventListener('resize', handleResize);
    return () => removeEventListeners();
  }, []);
  useEffect(() => {
    handleResize();
  }, [ref]);

  return (
    <Container
      className='promotion-popup'
      isFadeout={isFadeout}
      isRendered={isRendered}
    >
      <GlobalStyle />
      {renderPromotion()}
    </Container>
  );
};

export default PromotionPopup;
