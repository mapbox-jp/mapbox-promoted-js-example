import ReactDOM from 'react-dom';
import React, { useRef, useEffect, useState, useCallback } from 'react';
// Components
import Icon, { ICON_TYPE } from 'atoms/Icon';
import Card, { CARD_TYPES } from 'molecules/Card';
import { SideCardInnerContent } from './InnerContent';
import {
  Container,
  Wrapper,
  ContentWrapper,
  Toggle,
  ToggleButton,
  ToggleButtonIcon,
} from './styles';
import { CLICK_TYPES, isProfileElement, isMediaModalElement } from './helpers';

export const PREFIX_CLASSNAME = 'promotion-side-card';

window.renderPromotionSideCardInnerElement = (
  container: string | HTMLElement,
  feature: Feature,
  onClick?: (type: Promotion.ClickTypes, feature: Feature, profileItems?: Feature.ProfileItems) => void,
  onUpdate?: (feature: Feature) => void,
  onClose?: (feature: Feature) => void,
) => {
  const containerElement = typeof container === 'string' ? document.querySelector(container) as HTMLElement : container;
  containerElement && ReactDOM.render(
    <SideCardInnerContent
      container={containerElement}
      feature={feature}
      onClick={onClick}
      onUpdate={onUpdate}
      onClose={onClose}
    />,
    containerElement
  );
  return containerElement;
};
window.removePromotionSideCardInnerElement = (container: string | HTMLElement) => {
  const containerElement = typeof container === 'string' ? document.querySelector(container) : container;
  containerElement && ReactDOM.unmountComponentAtNode(containerElement);
};

window.showPromotionSideCard = (
  feature: Feature,
  onClick?: (type: Promotion.ClickTypes, feature: Feature, profileItems?: Feature.ProfileItems) => void,
  onUpdate?: (feature: Feature) => void,
  onClose?: (feature: Feature) => void,
  onOpen?: (feature: Feature) => void,
  onHide?: (feature: Feature) => void,
) => {
  ReactDOM.render(
    <PromotionSideCard
      feature={feature}
      onClick={onClick}
      onUpdate={onUpdate}
      onClose={onClose}
      onOpen={onOpen}
      onHide={onHide}
    />,
    document.querySelector('.mapbox-promoted-side-card')
  );
};

type Props = {
  feature: Feature;
  onClick?: (type: Promotion.ClickTypes, feature: Feature, profileItems?: Feature.ProfileItems) => void;
  onUpdate?: (feature: Feature) => void;
  onClose?: (feature: Feature) => void;
  onOpen?: (feature: Feature) => void;
  onHide?: (feature: Feature) => void;
};

const PromotionSideCard: React.FC<Props> = props => {
  const { onClick, onUpdate, onClose, onOpen, onHide } = props;

  const ref = useRef<HTMLDivElement>(null);
  const isUpdated = useRef<boolean>(false);
  const [feature, setFeature] = useState(props.feature);
  const [isShowing, setIsShowing] = useState(false);
  const [isFadeout, setIsFadeout] = useState(false);
  const [isRendered, setIsRendered] = useState(false);

  window.updatePromotionSideCard = (updateFeature: Feature) => {
    isUpdated.current = true;
    setFeature(updateFeature);
    setIsShowing(true);
  };
  window.openPromotionSideCard = () => setIsShowing(true);
  window.hidePromotionSideCard = () => setIsShowing(false);
  window.closePromotionSideCard = () => close();

  const close = () => {
    if (!isUpdated.current) {
      setIsShowing(false);
      setIsFadeout(true);
      setTimeout(() => {
        removeEventListeners();
        onClose && onClose(feature);
      }, 200);
    }
    isUpdated.current = false;
  };
  const removeEventListeners = () =>
    document.removeEventListener('click', handleClickOutside);

  const handleClick = (
    type: Promotion.ClickTypes,
    profileItems?: Feature.ProfileItems
  ) => {
    onClick && onClick(type, feature, profileItems);
  };
  const handleUpdate = (feature: Feature) => onUpdate && onUpdate(feature);
  const handleToggle = () => {
    onClick && onClick(CLICK_TYPES.TOGGLE, feature);
    if (isShowing) {
      onHide && onHide(feature);
    } else {
      onOpen && onOpen(feature);
    }
    setIsShowing(!isShowing);
  };
  const handleClickOutside = useCallback((event: MouseEvent) => {
    if (
      (ref.current && !ref.current.contains(event.target as Node)) && 
      (event.target && !isProfileElement(event.target as HTMLElement)) &&
      (event.target && !isMediaModalElement(event.target as HTMLElement))
    ) {
      close();
    }
  }, []);

  useEffect(() => {
    document.addEventListener('click', handleClickOutside);
    setIsShowing(true);
    return () => removeEventListeners();
  }, []);
  useEffect(() => {
    ref.current && setIsRendered(true);
  }, [ref]);

  return (
    <Container
      className={PREFIX_CLASSNAME}
      isShowing={isShowing}
      onClick={() => handleClick(CLICK_TYPES.CARD)}
      ref={ref}
    >
      <Wrapper className={`${PREFIX_CLASSNAME}__wrapper`}>
        <Toggle className={`${PREFIX_CLASSNAME}__toggle`}>
          <ToggleButton
            className={`${PREFIX_CLASSNAME}__toggle-button`}
            isFadeout={isFadeout}
            isRendered={isRendered}
            onClick={handleToggle}
          >
            <ToggleButtonIcon
              className={`${PREFIX_CLASSNAME}__toggle-button__icon`}
              isShowing={isShowing}
            >
              <Icon type={ICON_TYPE.ANGLE_LEFT} width='14px' height='14px' />
            </ToggleButtonIcon>
          </ToggleButton>
        </Toggle>
        <ContentWrapper className={`${PREFIX_CLASSNAME}__content-wrapper`}>
          <Card
            classPrefix={PREFIX_CLASSNAME}
            feature={feature}
            cardType={CARD_TYPES.SIDE_MENU}
            onClick={handleClick}
            onUpdate={handleUpdate}
          />
        </ContentWrapper>
      </Wrapper>
    </Container>
  );
};

export default PromotionSideCard;
