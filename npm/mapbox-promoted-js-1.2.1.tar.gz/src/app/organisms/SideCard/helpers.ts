export const CLICK_TYPES = {
  CARD: 'Card',
  TOGGLE: 'Toggle',
  BANNER: 'BannerDetail',
  CALL: 'Call',
  NAVIGATION: 'Navigation',
  DETAIL: 'Detail',
} as const;

export const isProfileElement = (target: HTMLElement) => {
  const classNames = [...target.classList];
  const isProfileNews = !!classNames.find(className => className.includes('promotion-profile-news'));
  const isProfileProducts = !!classNames.find(className => className.includes('promotion-profile-products'));
  const isProfileMedia = !!classNames.find(className => className.includes('promotion-profile-media'));
  return isProfileNews || isProfileProducts || isProfileMedia;
};

export const isMediaModalElement = (target: HTMLElement) => {
  const classNames = [...target.classList];
  return !!classNames.find(className => className.includes('promotion-side-card__media-modal'));
};
