import styled, { keyframes } from 'styled-components';

type Container = {
  height?: string;
  isShowingFull?: boolean;
  isFadeout?: boolean;
  isRendered?: boolean;
};

const bounceIn = keyframes`
  from {
    opacity: 0.0;
    transform: translate3d(0, 100%, 0);
    -ms-transform: translate3d(0, 100%, 0);
  }
  to {
    opacity: 1.0;
    transform: translate3d(0, 0, 0);
    -ms-transform: translate3d(0, 0, 0);
  }
`;
const bounceOut = keyframes`
  0% {
    opacity: 1.0;
    transform: translate3d(0, 0, 0);
    -ms-transform: translate3d(0, 0, 0);
  }
  to {
    opacity: 0.0;
    transform: translate3d(0, 100%, 0);
    -ms-transform: translate3d(0, 100%, 0);
  }
`;

export const Container = styled.div`
  position: absolute;
  margin: 0 auto;
  bottom: 0;
  left: 0;
  right: 0;
  height: 100%;
  min-height: ${({ height }: Container) => height || 0};
  max-height: ${({ height }: Container) => height || 0};
  background-color: rgb(255, 255, 255);
  border-radius: 5px 5px 0px 0;
  box-shadow: 0 0 8px rgba(0, 0, 0, 0.3);
  overflow-x: hidden;
  overflow-y: ${({ isShowingFull }: Container) => isShowingFull ? 'scroll' : 'hidden'};
  z-index: 2;
  animation-duration: 0.25s;
  animation-name: ${({ isFadeout }: Container) => isFadeout ? bounceOut : bounceIn};
  transition: min-height 0.2s, max-height 0.2s;
  -webkit-transition:  min-height 0.2s, max-height 0.2s;
  will-change: min-height, max-height;
`;
export const Wrapper = styled.div``;
export const Oppener = styled.div`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 18px;
  &:before {
    content: "";
    position: absolute;
    display: block;
    margin: auto;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    width: 40px;
    height: 5px;
    border-radius: 5px;
    background-color: rgb(213, 213, 213);
  }
`;
