export const CLICK_TYPES = {
  CARD: 'Card',
  TOGGLE: 'Toggle',
  BANNER: 'BannerDetail',
  CALL: 'Call',
  NAVIGATION: 'Navigation',
  DETAIL: 'Detail',
} as const;
