import ReactDOM from 'react-dom';
import React, { useRef, useEffect, useState } from 'react';
// Components
import Card, { CARD_TYPES } from 'molecules/Card';
import {
  Container,
  Wrapper,
  Oppener,
} from './styles';
import { CLICK_TYPES } from './helpers';

window.showPromotionCard = (
  feature: Feature,
  onClick?: (type: Promotion.ClickTypes, feature: Feature) => void,
  onClose?: (feature: Feature) => void
) => {
  ReactDOM.render(
    <PromotionCard
      feature={feature}
      onClick={onClick}
      onClose={onClose}
    />,
    document.querySelector('.mapbox-promoted-card')
  );
};

const PREFIX_CLASSNAME = 'promotion-card';

type Props = {
  feature: Feature;
  onClick?: (type: Promotion.ClickTypes, feature: Feature) => void;
  onClose?: (feature: Feature) => void;
};

const PromotionCard: React.FC<Props> = props => {
  const { onClick, onClose } = props;

  const ref = useRef<HTMLDivElement>(null);
  const isUpdated = useRef<boolean>(false);
  const [feature, setFeature] = useState(props.feature);
  const [isShowingFull, setIsShowingFull] = useState(false);
  const [isFadeout, setIsFadeout] = useState(false);
  const [isRendered, setIsRendered] = useState(false);

  window.updatePromotionCard = (updateFeature: Feature) => {
    isUpdated.current = true;
    setFeature(updateFeature);
  };
  window.closePromotionCard = () => {
    close();
  };

  const close = () => {
    if (!isUpdated.current) {
      setIsFadeout(true);
      setTimeout(() => {
        removeEventListeners();
        onClose && onClose(feature);
      }, 200);
    }
    isUpdated.current = false;
  };
  const removeEventListeners = () => {
    document.removeEventListener('click', handleClickOutside);
  };

  const handleClick = (type: Promotion.ClickTypes) => {
    onClick && onClick(type, feature);
  };
  const handleClickOutside = (event: MouseEvent) => {
    if (ref.current && !ref.current.contains(event.target as Node)) {
      close();
    }
  };
  const handleOpen = () => {
    setIsShowingFull(!isShowingFull);
  };

  useEffect(() => {
    document.addEventListener('click', handleClickOutside);
    return () => removeEventListeners();
  }, []);
  useEffect(() => {
    if (ref.current) {
      setIsRendered(true);
    }
  }, [ref]);

  return (
    <Container
      className={PREFIX_CLASSNAME}
      height={isShowingFull ? '100%' : '420px'}
      isShowingFull={isShowingFull}
      isFadeout={isFadeout}
      isRendered={isRendered}
      onClick={() => handleClick(CLICK_TYPES.CARD)}
      ref={ref}
    >
      <Wrapper>
        <Oppener onClick={handleOpen} />
        <Card
          classPrefix={PREFIX_CLASSNAME}
          feature={feature}
          cardType={CARD_TYPES.BOTTOM_CARD}
          isRendered={isRendered}
          onClick={handleClick}
        />
      </Wrapper>
    </Container>
  );
};

export default PromotionCard;
