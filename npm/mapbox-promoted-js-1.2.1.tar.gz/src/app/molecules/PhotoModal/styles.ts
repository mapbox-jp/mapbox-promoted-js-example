import styled from 'styled-components';

export const Header = styled.div`
  display: flex;
  position: absolute;
  padding: 15px 30px;
  width: 100%;
  cursor: pointer;
  z-index: 1;
`;
export const CloseButton = styled.div`
  height: 32px;
  font-size: 32px;
`;
export const Media = styled.div`
  display: flex;
  flex-direction: column;
  justify-content: center;
  padding: 40px 90px;
  width: 100%;
  height: 100%;
`;
export const MediaImage = styled.img`
  object-fit: cover;
  max-width: 100%;
  max-height: 100%;
`;
export const LeftButton = styled.div`
  position: absolute;
  display: flex;
  justify-content: flex-end;
  align-items: center;
  left: 0;
  width: 62px;
  height: 100%;
  font-size: 32px;
  cursor: pointer;
`;
export const RightButton = styled.div`
  position: absolute;
  display: flex;
  justify-content: flex-start;
  align-items: center;
  right: 0;
  width: 62px;
  height: 100%;
  font-size: 32px;
  cursor: pointer;
`;
