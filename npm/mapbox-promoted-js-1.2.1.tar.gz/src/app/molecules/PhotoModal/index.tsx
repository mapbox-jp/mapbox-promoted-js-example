import React, { useState } from 'react';
import { isLarge } from 'utils/browser';
// Components
import Icon, { ICON_TYPE } from 'atoms/Icon';
import Modal from 'atoms/Modal';
import {
  Header,
  CloseButton,
  Media,
  MediaImage,
  LeftButton,
  RightButton,
} from './styles';

type Props = {
  classPrefix: string;
  showingMedia: Feature.Profile.Media;
  media: Feature.Profile.Media[];
  width?: string;
  height?: string;
  isOpen?: boolean;
  onClose?: () => void;
};

const MediaModal: React.FC<Props> = props => {
  const { classPrefix, media, isOpen, onClose } = props;
  const PREFIX_CLASSNAME = `${classPrefix}__media-modal`;

  const [showingMedia, setShowingMedia] = useState<Feature.Profile.Media>(props.showingMedia);

  const handleClose = () => onClose && onClose();
  const handleClickLeft = () => {
    let index = media.findIndex(mediaItem => mediaItem.id === showingMedia.id);
    if (index - 1 < 0) {
      index = media.length - 1;
    } else {
      index -= 1;
    }
    setShowingMedia(media[index]);
  };
  const handleClickRight = () => {
    let index = media.findIndex(mediaItem => mediaItem.id === showingMedia.id);
    if (index + 1 >= media.length) {
      index = 0;
    } else {
      index += 1;
    }
    setShowingMedia(media[index]);
  };

  return (
    <Modal classPrefix={PREFIX_CLASSNAME} isOpen={isOpen}>
      <Header className={`${PREFIX_CLASSNAME}__header`}>
        <CloseButton
          className={`${PREFIX_CLASSNAME}__header__close-button`}
          onClick={handleClose}
        >
          <Icon
            className={`${PREFIX_CLASSNAME}__header__close-button__icon`}
            type={ICON_TYPE.XMARK}
            width='32px'
            height='32px'
            color='#ffffff'
          />
        </CloseButton>
      </Header>
      <Media className={`${PREFIX_CLASSNAME}__media`}>
        <LeftButton
          className={`${PREFIX_CLASSNAME}__media__left-button`}
          onClick={handleClickLeft}
        >
          <Icon
            className={`${PREFIX_CLASSNAME}__header__left-button__icon`}
            type={ICON_TYPE.ANGLE_LEFT}
            width='32px'
            height='32px'
            color='#ffffff'
          />
        </LeftButton>
        {showingMedia.type === 'image' ? (
          <MediaImage
            className={`${PREFIX_CLASSNAME}__media__img`}
            src={isLarge() ? showingMedia.media_items.large.url : showingMedia.media_items.medium.url}
          />
        ) : null}
        <RightButton
          className={`${PREFIX_CLASSNAME}__media__right-button`}
          onClick={handleClickRight}
        >
          <Icon
            className={`${PREFIX_CLASSNAME}__header__right-button__icon`}
            type={ICON_TYPE.ANGLE_RIGHT}
            width='32px'
            height='32px'
            color='#ffffff'
          />
        </RightButton>
      </Media>
    </Modal>
  );
};

export default MediaModal;
