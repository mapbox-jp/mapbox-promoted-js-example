import { createContext, useRef, useState, useEffect } from 'react';
// APIs
import {
  getNews,
  getProductCategories,
  getProducts,
  getMediaCategories,
  getMedia,
} from 'apis/profiles';

export type ProfileContext = {
  news: Feature.Profile.News[];
  newsIsLasted?: boolean;
  fetchNews: () => void,

  productCategories: Feature.Profile.Category[];
  products: Feature.Profile.Product[];
  productCategoryId?: string;
  productIsLasted?: boolean;
  fetchProductCategories: () => void;
  fetchProducts: (categoryId?: string) => void;

  mediaCategories: Feature.Profile.Category[];
  media: Feature.Profile.Media[];
  mediaCategoryId?: string;
  mediaIsLasted?: boolean;
  fetchMediaCategories: () => void;
  fetchMedia: (categoryId?: string) => void;
}

export const ProfileContext = createContext<ProfileContext>({
  news: [],
  fetchNews: () => {},

  productCategories: [],
  products: [],
  fetchProductCategories: () => {},
  fetchProducts: (_categoryId?: string) => {},

  mediaCategories: [],
  media: [],
  fetchMediaCategories: () => {},
  fetchMedia: (_categoryId?: string) => {},
});

export const useProfile = (featureId: string) => {
  return {
    ...useNews(featureId),
    ...useProductCategories(featureId),
    ...useProducts(featureId),
    ...useMediaCategories(featureId),
    ...useMedia(featureId),
  };
};

export const useNews = (featureId: string) => {
  const newsRef = useRef<Feature.Profile.News[]>([]);
  const [nextToken, setNextToken] = useState<string>();
  const [isLasted, setIsLasted] = useState(false);
  const [_, setDate] = useState<Date>();
  const reset = () => {
    newsRef.current = [];
    setNextToken(undefined);
    setIsLasted(false);
  };
  const fetchNews = () => {
    getNews(featureId, nextToken).then(({ news, token }) => {
      newsRef.current = nextToken ? [...newsRef.current, ...news] : news;
      setNextToken(token);
      if (!token) {
        setIsLasted(true);
      }
    }).catch((error) => {
      console.error(error);
    }).finally(() => {
      setDate(new Date());
    });
  };
  useEffect(() => {
    reset();
    fetchNews();
  }, [featureId]);
  return {
    news: newsRef.current,
    newsIsLasted: isLasted,
    fetchNews,
  };
};

export const useProductCategories = (featureId: string) => {
  const categoriesRef = useRef<Feature.Profile.Category[]>([]);
  const [_, setDate] = useState<Date>();
  const fetchProductCategories = () => {
    getProductCategories(featureId).then((categories) => {
      categoriesRef.current = [...categoriesRef.current, ...categories];
    }).catch((error) => {
      console.error(error);
    }).finally(() => {
      setDate(new Date());
    });
  };
  useEffect(() => {
    categoriesRef.current = [];
    fetchProductCategories();
  }, [featureId]);
  return {
    productCategories: categoriesRef.current,
    fetchProductCategories,
  };
};

export const useProducts = (featureId: string) => {
  const productsRef = useRef<Feature.Profile.Product[]>([]);
  const [nextToken, setNextToken] = useState<string>();
  const [categoryId, setCategoryId] = useState<string>();
  const [isLasted, setIsLasted] = useState(false);
  const [_, setDate] = useState<Date>();
  const reset = () => {
    productsRef.current = [];
    setNextToken(undefined);
    setCategoryId(undefined);
    setIsLasted(false);
  };
  const fetchProducts = (updatedCategoryId?: string) => {
    if (updatedCategoryId !== categoryId) {
      reset();
      setCategoryId(updatedCategoryId);
    }
    getProducts(featureId, nextToken, updatedCategoryId).then(({ products, token }) => {
      productsRef.current = [...productsRef.current, ...products];
      setNextToken(token);
      if (!token) {
        setIsLasted(true);
      }
    }).catch((error) => {
      console.error(error);
    }).finally(() => {
      setDate(new Date());
    });
  };
  useEffect(() => {
    reset();
    fetchProducts();
  }, [featureId]);
  return {
    products: productsRef.current,
    productCategoryId: categoryId,
    productIsLasted: isLasted,
    fetchProducts,
  };
};

export const useMediaCategories = (featureId: string) => {
  const categoriesRef = useRef<Feature.Profile.Category[]>([]);
  const [_, setDate] = useState<Date>();
  const fetchMediaCategories = () => {
    getMediaCategories(featureId).then((categories) => {
      categoriesRef.current = [...categoriesRef.current, ...categories];
    }).catch((error) => {
      console.error(error);
    }).finally(() => {
      setDate(new Date());
    });
  };
  useEffect(() => {
    categoriesRef.current = [];
    fetchMediaCategories();
  }, [featureId]);
  return {
    mediaCategories: categoriesRef.current,
    fetchMediaCategories,
  };
};

export const useMedia = (featureId: string) => {
  const mediaRef = useRef<Feature.Profile.Media[]>([]);
  const [nextToken, setNextToken] = useState<string>();
  const [categoryId, setCategoryId] = useState<string>();
  const [isLasted, setIsLasted] = useState(false);
  const [_, setDate] = useState<Date>();
  const reset = () => {
    mediaRef.current = [];
    setNextToken(undefined);
    setCategoryId(undefined);
    setIsLasted(false);
  };
  const fetchMedia = (updatedCategoryId?: string) => {
    if (updatedCategoryId !== categoryId) {
      reset();
      setCategoryId(updatedCategoryId);
    }
    getMedia(featureId, nextToken, updatedCategoryId).then(({ media, token }) => {
      mediaRef.current = [...mediaRef.current, ...media];
      setNextToken(token);
      if (!token) {
        setIsLasted(true);
      }
    }).catch((error) => {
      console.error(error);
    }).finally(() => {
      setDate(new Date());
    });
  };
  useEffect(() => {
    reset();
    fetchMedia();
  }, [featureId]);
  return {
    media: mediaRef.current,
    mediaCategoryId: categoryId,
    mediaIsLasted: isLasted,
    fetchMedia,
  };
};
