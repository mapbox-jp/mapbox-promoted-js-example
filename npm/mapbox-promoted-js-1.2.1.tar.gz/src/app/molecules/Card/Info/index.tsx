import React, { useRef, useState } from 'react';
// Components
import Icon, { ICON_TYPE } from 'atoms/Icon';
import BusinessHours from '../BusinessHours';
import {
  Container,
  Row,
  OpenerIcon,
  Opener,
  BusinessHoursWrapper,
  Value,
  Label,
  LabelText,
  Remarks,
} from './styles';
import { CLICK_TYPES } from '../helpers';

type Props = {
  classPrefix?: string;
  feature: Feature;
  onClick: (type: Promotion.ClickTypes, feature: Feature) => void;
};

const Info: React.FC<Props> = props => {
  const { classPrefix, feature, onClick } = props;
  const { address_ja, address_remarks, business_hours, business_hours_remarks, phone_number } = feature.properties;
  const PREFIX_CLASSNAME = classPrefix;

  const businessHoursRef = useRef<HTMLDivElement>(null);
  const [isOpeningBusinessHours, setIsOpeningBusinessHours] = useState(false);

  const handleClick = (type: Promotion.ClickTypes) => {
    if (type === CLICK_TYPES.BUSINESS_HOURS) {
      setIsOpeningBusinessHours(!isOpeningBusinessHours);
    }
    onClick && onClick(type, feature);
  };
  return (
    <Container className={PREFIX_CLASSNAME}>
      {address_ja ? (
        <Row
          className={`${PREFIX_CLASSNAME}__row`}
          onClick={() => handleClick(CLICK_TYPES.ADDRESS)}
        >
          <Value className={`${PREFIX_CLASSNAME}__row-value`}>
            <Icon
              type={ICON_TYPE.MAP_MARKER_DOT}
              width='14px'
              height='14px'
              color='#1a73e8'
              margin='0 12px 0 0'
            />
            <Label className={`${PREFIX_CLASSNAME}__row-label`}>
              <LabelText className={`${PREFIX_CLASSNAME}__row-label__text`}>
                {address_ja}
              </LabelText>
              {address_remarks ? (
                <Remarks className={`${PREFIX_CLASSNAME}__row-title__remarks`}>
                  {address_remarks}
                </Remarks>
              ) : null}
            </Label>
          </Value>
        </Row>
      ) : null}
      {business_hours && Object.keys(business_hours).length ? (
        <Row
          className={`${PREFIX_CLASSNAME}__row`}
          onClick={() => handleClick(CLICK_TYPES.BUSINESS_HOURS)}
        >
          <Value className={`${PREFIX_CLASSNAME}__row-value`}>
            <Icon
              type={ICON_TYPE.CLOCK}
              width='14px'
              height='14px'
              color='#1a73e8'
              margin='0 12px 0 0'
            />
            <Label className={`${PREFIX_CLASSNAME}__row-label`}>
              <LabelText className={`${PREFIX_CLASSNAME}__row-label__text`}>
                営業時間
              </LabelText>
              {business_hours_remarks ? (
                <Remarks className={`${PREFIX_CLASSNAME}__row-title__remarks`}>
                  {business_hours_remarks}
                </Remarks>
              ) : null}
            </Label>
            <OpenerIcon isOpening={isOpeningBusinessHours}>
              <Icon type={ICON_TYPE.ANGLE_DOWN} width='14px' height='14px' />
            </OpenerIcon>
          </Value>
          <Opener
            className={`${PREFIX_CLASSNAME}__row-opener`}
            isOpening={isOpeningBusinessHours}
            height={businessHoursRef.current?.clientHeight}
          >
            <BusinessHoursWrapper className={`${PREFIX_CLASSNAME}__business-hours-wrapper`}>
              <BusinessHours
                classPrefix={PREFIX_CLASSNAME}
                businessHours={business_hours}
                ref={businessHoursRef}
              />
            </BusinessHoursWrapper>
          </Opener>
        </Row>
      ) : null}
      {phone_number ? (
        <Row
          className={`${PREFIX_CLASSNAME}__row`}
          onClick={() => handleClick(CLICK_TYPES.CALL)}
        >
          <Value className={`${PREFIX_CLASSNAME}__row-value`}>
            <Icon
              type={ICON_TYPE.PHONE}
              width='14px'
              height='14px'
              color='#1a73e8'
              margin='0 12px 0 0'
            />
            <Label className={`${PREFIX_CLASSNAME}__row-label`}>
              <LabelText className={`${PREFIX_CLASSNAME}__row-label__text`}>
                {phone_number}
              </LabelText>
            </Label>
          </Value>
        </Row>
      ) : null}
    </Container>
  );
};

export default Info;
