import { ICON_TYPE } from 'atoms/Icon';
import { CLICK_TYPES } from '../helpers';

export const ACTION_TYPES = {
  ROUTE: 'action-type-route',
  PHONE_NUMBER: 'action-type-phone-number',
  PROMOTION_URL: 'action-type-promotion-url',
  LINE: 'action-type-external-links__line',
  INSTAGRAM: 'action-type-external-links__instagram',
  FACEBOOK: 'action-type-external-links__facebook',
  TWITTER: 'action-type-external-links__twitter',
  APP_STORE: 'action-type-external-links__app-store',
  PLAY_STORE: 'action-type-external-links__play-store',
} as const;

export type ActionTypes = typeof ACTION_TYPES[keyof typeof ACTION_TYPES];

type Actions = {
  [key in ActionTypes]: {
    key: string;
    classKey: string;
    iconType: string;
    clickType?: Promotion.ClickTypes;
    label?: string;
    isBlank?: boolean;
    isRequired?: boolean;
  };
};

export const ACTIONS: Actions = {
  [ACTION_TYPES.ROUTE]: {
    key: 'route',
    classKey: 'route',
    iconType: ICON_TYPE.ROUTE,
    clickType: CLICK_TYPES.ROUTE,
    label: '経路',
    isBlank: false,
    isRequired: true,
  },
  [ACTION_TYPES.PHONE_NUMBER]: {
    key: 'phone_number',
    classKey: 'phone-number',
    iconType: ICON_TYPE.CALL,
    clickType: CLICK_TYPES.CALL,
    label: '電話',
    isBlank: false,
  },
  [ACTION_TYPES.PROMOTION_URL]: {
    key: 'promotion_url',
    classKey: 'promotion-url',
    iconType: ICON_TYPE.EARTH,
    clickType: CLICK_TYPES.DETAIL,
    label: '公式サイト',
    isBlank: true,
  },
  [ACTION_TYPES.LINE]: {
    key: 'external_links.line',
    classKey: 'line',
    iconType: ICON_TYPE.LINE,
    clickType: CLICK_TYPES.LINE,
    label: '公式LINE',
    isBlank: true,
  },
  [ACTION_TYPES.INSTAGRAM]: {
    key: 'external_links.instagram',
    classKey: 'instagram',
    iconType: ICON_TYPE.INSTAGRAM,
    clickType: CLICK_TYPES.INSTAGRAM,
    label: 'Instagram',
    isBlank: true,
  },
  [ACTION_TYPES.FACEBOOK]: {
    key: 'external_links.facebook',
    classKey: 'facebook',
    iconType: ICON_TYPE.FACEBOOK,
    clickType: CLICK_TYPES.FACEBOOK,
    label: 'Facebook',
    isBlank: true,
  },
  [ACTION_TYPES.TWITTER]: {
    key: 'external_links.twitter',
    classKey: 'twitter',
    iconType: ICON_TYPE.TWITTER,
    clickType: CLICK_TYPES.TWITTER,
    label: 'Twitter',
    isBlank: true,
  },
  [ACTION_TYPES.APP_STORE]: {
    key: 'external_links.app_store',
    classKey: 'app_store',
    iconType: ICON_TYPE.PHONE,
    clickType: CLICK_TYPES.APP_STORE,
    label: 'AppStore',
    isBlank: true,
  },
  [ACTION_TYPES.PLAY_STORE]: {
    key: 'external_links.play_store',
    classKey: 'play_store',
    iconType: ICON_TYPE.PHONE,
    clickType: CLICK_TYPES.PLAY_STORE,
    label: 'PlayStore',
    isBlank: true,
  },
};
