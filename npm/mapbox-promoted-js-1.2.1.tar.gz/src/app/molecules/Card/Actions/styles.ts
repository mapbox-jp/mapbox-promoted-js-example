import styled from 'styled-components';

type Container = {
  isVertical?: boolean;
};

export const Container = styled.ul`
  display: flex;
  margin: ${({ isVertical }: Container) => isVertical ? '20px -10px 0px' : '8px -10px 0px'};
  padding: 0;
  left: 0;
  width: calc(100% + 10px + 10px);
  overflow-x: scroll;
  scrollbar-width: none;
  &::-webkit-scrollbar {
    display: none;
  }
`;
