import styled from 'styled-components';
import { CARD_TYPES, CardTypes } from '../helpers';

type Container = {
  cardType?: CardTypes;
};

export const Container = styled.ul`
  display: flex;
  margin: 20px -10px 0px;
  padding: ${({ cardType }: Container) => cardType === CARD_TYPES.BOTTOM_CARD ? '0 0 0' : '0 0 20px 0'};
  left: 0;
  width: calc(100% + 10px + 10px);
  overflow-x: scroll;
  scrollbar-width: none;
  &::-webkit-scrollbar {
    display: none;
  }
`;
