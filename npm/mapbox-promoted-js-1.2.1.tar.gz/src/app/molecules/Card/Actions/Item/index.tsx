import React from 'react';
import { isPc } from 'utils/browser';
// Components
import Icon from 'atoms/Icon';
import { ACTIONS, ActionTypes } from '../helpers';
import {
  createItemGlobalStyle,
  Container,
  ItemButton,
  ItemAnchor,
  ItemIcon,
  ItemLabel,
} from './styles';

type Props = {
  classPrefix?: string;
  type: ActionTypes;
  value: string;
  isPopup?: boolean;
  isBlank?: boolean;
  onClick: (type: Promotion.ClickTypes) => void;
};

const Item: React.FC<Props> = props => {
  const { classPrefix, type, value, isPopup, isBlank, onClick } = props;
  const PREFIX_CLASSNAME = `${classPrefix}__actions-item`;

  const GlobalStyle = createItemGlobalStyle(PREFIX_CLASSNAME);
  // const GlobalStyle = useMemo(() => {
  //   return createItemGlobalStyle(PREFIX_CLASSNAME);
  // }, [PREFIX_CLASSNAME]);
  const isVertical = isPc() && !isPopup;
  const action = ACTIONS[type];
  const { classKey, iconType, clickType } = action;
  const label = action.label || value;

  const handleClick = (type: Promotion.ClickTypes) => {
    onClick(type);
  };
  const renderContent = (iconType: string, label: string) => (
    <>
      <ItemIcon className={`${PREFIX_CLASSNAME}__icon`}>
        <Icon type={iconType} width='14px' height='14px' />
      </ItemIcon>
      {isPopup || !isPc() ? (
        <ItemLabel
          className={`${PREFIX_CLASSNAME}__label`}
          isPopup={isPopup}
        >
          {label}
        </ItemLabel>
      ) : null}
    </>
  );
  return (
    <>
      <GlobalStyle />
      <Container
        className={`${PREFIX_CLASSNAME} ${PREFIX_CLASSNAME}-${classKey}`}
        isVertical={isVertical}
        onClick={() => clickType && handleClick(clickType)}
      >
        {isBlank ? (
          <ItemAnchor
            className={`${PREFIX_CLASSNAME}__anchor`}
            isVertical={isVertical}
            href={value}
            target='_break'
          >
            {renderContent(iconType, label)}
          </ItemAnchor>
        ) : (
          <ItemButton
            className={`${PREFIX_CLASSNAME}__button`}
            isVertical={isVertical}
          >
            {renderContent(iconType, label)}
          </ItemButton>
        )}
        {!isPopup && isPc() && (
          <ItemLabel
            className={`${PREFIX_CLASSNAME}__label`}
            isVertical={isVertical}
            isPopup={isPopup}
          >
            {label}
          </ItemLabel>
        )}
      </Container>
    </>
  );
};

export default Item;
