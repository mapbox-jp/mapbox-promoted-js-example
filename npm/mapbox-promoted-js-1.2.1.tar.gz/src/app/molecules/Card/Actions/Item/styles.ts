import styled, { css, createGlobalStyle } from 'styled-components';

type Container = {
  isVertical?: boolean;
};
type Item = {
  isVertical?: boolean;
};
type ItemLabel = {
  isVertical?: boolean;
  isPopup?: boolean;
};

const largeButtonStyle = css`
  width: 68px;
  min-width: 68px;
  display: flex;
  flex-direction: column;
  align-items: center;
`;
const buttonStyle = css`
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 8px;
  width: ${({ isVertical }: Item) => isVertical ? '32px' : 'auto'};
  height: ${({ isVertical }: Item) => isVertical ? '32px' : 'auto'};
  white-space: nowrap;
  vertical-align: baseline;
  color: rgb(26, 115, 232);
  border: 1px solid rgb(26, 115, 232);
  border-radius: 8px;
  background-color: transparent;
  text-decoration: none;
  cursor: pointer;
`;

export const createItemGlobalStyle = (className?: string, space?: string) => createGlobalStyle`
  .${className} {
    &:first-child {
      margin-left: ${space || '9px'}
    }
    &:last-child {
      margin-right: ${space || '9px'}
    }
  }
`;
export const ItemAnchor = styled.a`
  white-space: nowrap;
  vertical-align: baseline;
  ${buttonStyle}
`;
export const ItemButton = styled.button`
  ${buttonStyle}
`;
export const ItemIcon = styled.span`
  display: flex;
  justify-content: center;
  align-items: center;
  width: 14px;
  min-width: 14px;
  height: 14px;
  min-height: 14px;
  font-size: 14px;
  cursor: pointer;
`;
export const ItemLabel = styled.span`
  margin: ${({ isVertical }: ItemLabel) => isVertical ? '12px 0 0 0' : '0 0 0 5px'};
  font-size: 11px;
  line-height: 1;
  color: ${({ isPopup }: ItemLabel) => isPopup ? null : 'rgb(26, 115, 232)'};
`;
export const Container = styled.li`
  ${({ isVertical }: Container) => isVertical && largeButtonStyle}
  & + & {
    margin-left: 4px;
  }
  &:hover {
    ${ItemAnchor}, ${ItemButton} {
      color: #ffffff;
      background-color: rgb(26, 115, 232);
      transition: background-color 0.1s, color 0.1s;
    }
    ${({ isVertical }: Container) => !isVertical && `
      ${ItemLabel} {
        color: #ffffff;
        transition: color 0.1s;
      }
    `}
  }
`;
