import React, { useMemo } from 'react';
// Components
import ActionItem from './Item';
import { Container } from './styles';
import { ACTION_TYPES, ACTIONS, ActionTypes } from './helpers';
import { CardTypes } from '../helpers';

type Props = {
  classPrefix?: string;
  feature: Feature;
  cardType?: CardTypes;
  isPopup?: boolean;
  onClick: (type: Promotion.ClickTypes) => void;
};

const Actions: React.FC<Props> = props => {
  const { classPrefix, feature, cardType, isPopup, onClick } = props;
  const { properties } = feature;
  const { feature_id } = properties;
  const externalLinks: Feature.ExternalLink[] = useMemo(
    () => properties.external_links && typeof properties.external_links === 'string' ?
      JSON.parse(properties.external_links) : properties.external_links || [],
    [feature_id]
  );
  const PREFIX_CLASSNAME = `${classPrefix}__actions`;

  const keys = Object.values(ACTION_TYPES) as ActionTypes[];
  const handleClick = (type: Promotion.ClickTypes) => onClick(type);
  return (
    <Container
      className={PREFIX_CLASSNAME}
      cardType={cardType}
    >
      {keys.map(key => {
        const action = ACTIONS[key];
        let value = (properties as any)[action.key];
        if (action.key.includes('external_links')) {
          const serviceType = action.key.split('.')[1];
          const externalLink = externalLinks.find(externalLink => externalLink.type === serviceType);
          if (!externalLink) { return; }
          value = externalLink.url;
        }
        return !!value || action.isRequired ? (
          <ActionItem
            classPrefix={classPrefix}
            type={key}
            value={value}
            isPopup={isPopup}
            isBlank={action.isBlank}
            onClick={handleClick}
            key={`${PREFIX_CLASSNAME}-${key}`}
          />
        ) : null;
      })}
    </Container>
  );
};

export default Actions;
