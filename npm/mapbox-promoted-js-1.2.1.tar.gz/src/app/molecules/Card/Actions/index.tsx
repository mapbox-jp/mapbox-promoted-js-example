import React, { useMemo } from 'react';
import { isPc } from 'utils/browser';
// Components
import ActionItem from './Item';
import { Container } from './styles';
import { ACTION_TYPES, ACTIONS, ActionTypes } from './helpers';

type Props = {
  classPrefix?: string;
  feature: Feature;
  isPopup?: boolean;
  onClick: (type: Promotion.ClickTypes) => void;
};

const Actions: React.FC<Props> = props => {
  const { classPrefix, feature, isPopup, onClick } = props;
  const { properties } = feature;
  const PREFIX_CLASSNAME = `${classPrefix}__actions`;

  const isVertical = useMemo(() => isPc() && !isPopup, [document.body.clientWidth]);

  const keys = Object.values(ACTION_TYPES) as ActionTypes[];
  const handleClick = (type: Promotion.ClickTypes) => {
    onClick(type);
  };
  return (
    <Container
      className={PREFIX_CLASSNAME}
      isVertical={isVertical}
    >
      {keys.map(key => {
        const action = ACTIONS[key];
        let value = (properties as any)[action.key];
        if (action.key.includes('external_links')) {
          const externalLinkString = properties['external_links'];
          if (!externalLinkString) { return; }
          const externalLinks = JSON.parse(externalLinkString) as Feature.ExternalLink[];
          const serviceType = action.key.split('.')[1];
          const externalLink = externalLinks.find(externalLink => externalLink.type === serviceType);
          if (!externalLink) { return; }
          value = externalLink.url;
        }
        return !!value || action.isRequired ? (
          <ActionItem
            classPrefix={classPrefix}
            type={key}
            value={value}
            isPopup={isPopup}
            isBlank={action.isBlank}
            onClick={handleClick}
            key={`${PREFIX_CLASSNAME}-${key}`}
          />
        ) : null;
      })}
    </Container>
  );
};

export default Actions;
