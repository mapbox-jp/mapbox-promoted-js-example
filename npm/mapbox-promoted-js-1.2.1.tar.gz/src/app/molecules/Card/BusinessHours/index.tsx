import React from 'react';
import {
  DAYS,
  DAY_PAIRS,
  parseBusinessHoursString
} from 'utils/businessHours';
import {
  Container,
  BusinessHour,
  Key,
  Value,
} from './styles';

type Props = {
  classPrefix?: string;
  businessHours: string;
};

const BusinessHours = React.forwardRef<HTMLUListElement, Props>((props, ref) => {
  const { classPrefix } = props;
  const businessHours = parseBusinessHoursString(props.businessHours);
  const PREFIX_CLASSNAME = `${classPrefix}__business-hours`;
  return (
    <Container className={PREFIX_CLASSNAME} ref={ref}>
      {DAYS.map((day: string) => {
        let value = '';
        if (day in businessHours) {
          value = businessHours[day].join(', ');
        }
        const isClosed = value === '';
        const DAILY_CLASSNAME = `${PREFIX_CLASSNAME}__${day}`;
        return (
          <BusinessHour className={DAILY_CLASSNAME} key={`business-hours__${day}`}>
            <Key className={`${DAILY_CLASSNAME}-day`}>
              {(DAY_PAIRS as any)[day]}
            </Key>
            <Value className={`${DAILY_CLASSNAME}-value`} isClosed={isClosed}>
              {isClosed ? '定休日' : value}
            </Value>
          </BusinessHour>
        );
      })}
    </Container>
  );
});

export default BusinessHours;
