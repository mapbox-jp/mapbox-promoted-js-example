import styled from 'styled-components';

type Value = {
  isClosed?: boolean;
};

export const Container = styled.ul`
  display: table;
  border-collapse: separate;
  border-spacing: 0 5px;
`;
export const BusinessHour = styled.li`
  display: table-row;
`;
export const Key = styled.span`
  display: table-cell;
  font-size: 12px;
`;
export const Value = styled.span`
  display: table-cell;
  padding-left: 50px;
  color: ${({ isClosed }: Value) => isClosed ? '#ff0000' : '#000000'};
  font-size: 12px;
  font-weight: ${({ isClosed }: Value) => isClosed ? '500' : '400'};
`;
