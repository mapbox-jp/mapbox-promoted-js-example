import React, { useRef, useMemo, useState } from 'react';
import { DEFAULT_BANNER_SIZE } from 'utils/config';
// Components
import HeaderInfo from './HeaderInfo';
import Tabs, { Tab } from './Tabs';
import Actions from './Actions';
import Summary from './Summary';
import News from './News';
import Products from './Products';
import Media from './Media';
import Info from './Info';
import {
  GlobalStyle,
  Container,
  Header,
  Banner,
  BannerImg,
  Wrapper,
  Content,
} from './styles';
import { CARD_TYPES, CardTypes, CLICK_TYPES, TAB_TYPES, TabTypes } from './helpers';

type Props = {
  classPrefix?: string;
  feature: Feature;
  height?: string;
  cardType?: CardTypes;
  isFadeout?: boolean;
  isRendered?: boolean;
  onClick: (
    type: Promotion.ClickTypes,
    feature: Feature
  ) => void;
};

const Card = React.forwardRef<HTMLDivElement, Props>((props, ref) => {
  const { classPrefix, feature, height, cardType, onClick } = props;
  const { properties } = feature;
  const { promotion_banner } = properties;

  const headerRef = useRef<HTMLDivElement>(null);
  const [selectedTab, setSelectedTab] = useState<TabTypes>(TAB_TYPES.SUMARRY);
  const profile = useMemo(() => properties.profile ? JSON.parse(properties.profile) : {}, []);
  const bannerSize = useMemo(() => {
    const { promotion_banner_width, promotion_banner_height } = properties;
    return {
      width: promotion_banner_width || DEFAULT_BANNER_SIZE.WIDTH,
      height: promotion_banner_height || DEFAULT_BANNER_SIZE.HEIGHT,
    };
  }, [properties]);

  const enableProfile = profile && !!Object.values(profile).find(value => value);

  const handleClickTab = (type: TabTypes) => {
    setSelectedTab(type);
    handleClick(CLICK_TYPES.TAB);
  };
  const handleClick = (type: Promotion.ClickTypes) => {
    onClick && onClick(type, feature);
  };
  const renderTabs = () => {
    return enableProfile ? (
      <Wrapper className={`${classPrefix}__wrapper`} cardType={cardType}>
        <Tabs classPrefix={classPrefix}>
          <Tab
            classPrefix={classPrefix}
            label="概要"
            isSelected={selectedTab === TAB_TYPES.SUMARRY}
            onClick={() => handleClickTab(TAB_TYPES.SUMARRY)}
          />
          {profile.news && (
            <Tab
              label="最新情報"
              isSelected={selectedTab === TAB_TYPES.NEWS}
              onClick={() => handleClickTab(TAB_TYPES.NEWS)}
            />
          )}
          {profile.products && (
            <Tab
              label="メニュー"
              isSelected={selectedTab === TAB_TYPES.PRODUCTS}
              onClick={() => handleClickTab(TAB_TYPES.PRODUCTS)}
            />
          )}
          {profile.media && (
            <Tab
              label="写真"
              isSelected={selectedTab === TAB_TYPES.MEDIA}
              onClick={() => handleClickTab(TAB_TYPES.MEDIA)}
            />
          )}
          <Tab
            classPrefix={classPrefix}
            label="情報"
            isSelected={selectedTab === TAB_TYPES.INFO}
            onClick={() => handleClickTab(TAB_TYPES.INFO)}
          />
        </Tabs>
        <Content className={`${classPrefix}__content`}>
          {renderContent()}
        </Content>
      </Wrapper>
    ) : (
      <Summary
        classPrefix={classPrefix}
        feature={feature}
        onClick={handleClick}
      />
    );
  };
  const renderContent = () => {
    switch (selectedTab) {
      case TAB_TYPES.SUMARRY:
        return (
          <Summary
            classPrefix={classPrefix}
            feature={feature}
            onClick={handleClick}
          />
        );
      case TAB_TYPES.NEWS:
        return (
          <News
            feature={feature} 
            headerHeight={headerRef.current && headerRef.current.clientHeight}
          />
        );
      case TAB_TYPES.PRODUCTS:
        return (
          <Products
            feature={feature} 
            headerHeight={headerRef.current && headerRef.current.clientHeight}
          />
        );
      case TAB_TYPES.MEDIA:
        return (
          <Media
            feature={feature} 
            headerHeight={headerRef.current && headerRef.current.clientHeight}
          />
        );
      case TAB_TYPES.INFO:
        return (
          <Info
            classPrefix={classPrefix}
            feature={feature}
            onClick={handleClick}
          />
        );
      default:
        return null;
    }
  };
  return (
    <>
      <GlobalStyle />
      <Container
        className={classPrefix}
        height={height}
        onClick={() => handleClick(CLICK_TYPES.CARD)}
        ref={ref}
      >
        <Header
          className={`${classPrefix}__header`}
          cardType={cardType}
          ref={headerRef}
        >
          <Banner
            className={`${classPrefix}__banner`}
            onClick={() => handleClick(CLICK_TYPES.BANNER)}
          >
            <BannerImg
              className={`${classPrefix}__banner-img`}
              src={promotion_banner}
              width={bannerSize.width}
              height={bannerSize.height}
            />
          </Banner>
          <HeaderInfo
            classPrefix={classPrefix}
            feature={feature}
            onClick={handleClick}
          />
          <Actions
            classPrefix={classPrefix}
            feature={feature}
            isPopup={cardType === CARD_TYPES.POPUP}
            onClick={handleClick}
          />
        </Header>
        {cardType !== CARD_TYPES.POPUP && renderTabs()}
      </Container>
    </>
  );
});

export default Card;

export {
  CARD_TYPES
};
