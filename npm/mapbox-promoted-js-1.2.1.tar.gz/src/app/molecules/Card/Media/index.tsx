import React, { useEffect, useRef, useState } from 'react';
// APIs
import { getMedia, getMediaCategories } from 'apis/profiles';
// Components
import Item from './Item';
import {
  Container,
  Categories,
  Category,
  Items,
} from './styles';

type Props = {
  feature: Feature;
  headerHeight?: number | null;
};

const Media: React.FC<Props> = props => {
  const { feature, headerHeight } = props;
  const { properties } = feature;
  const { feature_id } = properties;

  const mediaRef = useRef<Feature.Profile.Media[]>([]);
  const categoriesRef = useRef<Feature.Profile.Category[]>([]);

  const [selectedCategoryId, setSelectedCategoryId] = useState<string>();
  const [nextToken, setNextToken] = useState<string>('');
  const [isLasted, setIsLasted] = useState(false);
  const [_, setDate] = useState<Date>();

  const fetchCategories = () => {
    getMediaCategories(feature_id).then((categories) => {
      categoriesRef.current = [...categoriesRef.current, ...categories];
    }).catch((error) => {
      console.error(error);
    }).finally(() => {
      setDate(new Date());
    });
  };
  const fetchMedia = (nextToken?: string, cagetoryId?: string) => {
    getMedia(feature_id, nextToken, cagetoryId).then(({ media, token }) => {
      mediaRef.current = [...mediaRef.current, ...media];
      setNextToken(token || '');
      if (!token) {
        setIsLasted(true);
      }
    }).catch((error) => {
      console.error(error);
    }).finally(() => {
      setDate(new Date());
    });
  };
  const handleSelectCategory = (cagetoryId?: string) => {
    setSelectedCategoryId(cagetoryId);
    mediaRef.current = [];
    setNextToken('');
    setIsLasted(false);
    fetchMedia('', cagetoryId);
  };
  const handleReadMore = () => {
    fetchMedia(nextToken, selectedCategoryId);
  };
  useEffect(() => {
    !categoriesRef.current.length && fetchCategories();
    fetchMedia();
  }, []);

  return (
    <Container>
      {categoriesRef.current.length ? (
        <Categories>
          <Category
            isSelected={!selectedCategoryId}
            onClick={() => handleSelectCategory()}
          >
            すべて
          </Category>
          {categoriesRef.current.map((category) => (
            <Category
              isSelected={category.id === selectedCategoryId}
              onClick={() => handleSelectCategory(category.id)}
              key={`media-categories__${category.id}`}
            >
              {category.name}
            </Category>
          ))}
        </Categories>
      ) : null}
      <Items headerHeight={headerHeight}>
        {mediaRef.current.map((media: Feature.Profile.Media, i) => (
          <Item
            media={media}
            isLast={i === mediaRef.current.length - 1 && !isLasted}
            onReadMore={handleReadMore}
            key={`media-row__${media.id}`}
          />
        ))}
      </Items>
    </Container>
  );
};

export default Media;