import React, { useContext, useEffect, useRef, useState } from 'react';
import { ProfileContext } from 'molecules/Card/hooks';
// Components
import ScrollButton from 'atoms/ScrollButton';
import Item from './Item';
import {
  Container,
  CategoriesWrapper,
  Categories,
  Category,
  Items,
  ScrollButtonLeft,
  ScrollButtonRight,
  EmptyColumn,
} from './styles';

type Props = {
  classPrefix?: string;
  isHorizontal?: boolean;
  onClick?: (media: Feature.Profile.Media) => void;
};

const MEDIA_ITEM_WIDTH = 104.5;
const CATEGORIES_ITEM_WIDTH = 70;

const Media: React.FC<Props> = props => {
  const { classPrefix, isHorizontal, onClick } = props;
  const {
    mediaCategories,
    media,
    mediaCategoryId,
    mediaIsLasted,
    updateMediaCategory,
    readmoreMedia
  } = useContext(ProfileContext);
  const PREFIX_CLASSNAME = `${classPrefix}-media`;

  const ref = useRef<HTMLDivElement>(null);
  const mediaRef = useRef<HTMLUListElement>(null);
  const categoriesRef = useRef<HTMLDivElement>(null);
  const [isHovering, setIsHovering] = useState(false);
  const [isHoveringCategories, setIsHoveringCategories] = useState(false);
  const [_, setDate] = useState<Date>();

  const handleSelectCategory = (categoryId?: string) => updateMediaCategory(categoryId);
  const handleReadMore = () => readmoreMedia(mediaCategoryId);
  const handleMouseEnter = () => setIsHovering(true);
  const handleMouseLeave = () => setIsHovering(false);
  const handleMouseEnterCatevories = () => setIsHoveringCategories(true);
  const handleMouseLeaveCatevories = () => setIsHoveringCategories(false);
  const handleScroll = (left: boolean = false) => {
    if (!mediaRef.current) { return; }
    mediaRef.current.scroll({
      left: mediaRef.current.scrollLeft + (
        left ? -1 * MEDIA_ITEM_WIDTH : MEDIA_ITEM_WIDTH
      ),
      behavior: 'smooth'
    });
    mediaRef.current.scrollLeft
  };
  const handleScrollCategories = (left: boolean = false) => {
    if (!categoriesRef.current) { return; }
    categoriesRef.current.scroll({
      left: categoriesRef.current.scrollLeft + (
        left ? -1 * CATEGORIES_ITEM_WIDTH : CATEGORIES_ITEM_WIDTH
      ),
      behavior: 'smooth'
    });
    categoriesRef.current.scrollLeft
  };

  useEffect(() => {
    setDate(new Date());
  }, [ref]);

  return (
    <>
      {mediaCategories.length ? (
        <CategoriesWrapper
          className={`${PREFIX_CLASSNAME}__categories-wrapper`}
          isHorizontal={isHorizontal}
          onMouseEnter={handleMouseEnterCatevories}
          onMouseLeave={handleMouseLeaveCatevories}
        >
          {isHoveringCategories && (
            <ScrollButtonLeft
              className={`${PREFIX_CLASSNAME}__categories__scroll-button-left__wrapper`}
              onClick={() => handleScrollCategories(true)}
            >
              <ScrollButton
                classPrefix={`${PREFIX_CLASSNAME}__categories`}
                type='left'
                size='small'
              />
            </ScrollButtonLeft>
          )}    
          {ref.current ? (
            <Categories
              className={`${PREFIX_CLASSNAME}__categories`}
              width={`${ref.current.clientWidth}px`}
              isHorizontal={isHorizontal}
              ref={categoriesRef}
            >
              <Category
                className={`${PREFIX_CLASSNAME}__categories-item`}
                isSelected={!mediaCategoryId}
                onClick={() => handleSelectCategory()}
              >
                すべて
              </Category>
              {mediaCategories.map((category) => (
                <Category
                  className={`${PREFIX_CLASSNAME}__categories-item`}
                  isSelected={category.id === mediaCategoryId}
                  onClick={() => handleSelectCategory(category.id)}
                  key={`media-categories__${category.id}`}
                >
                  {category.name}
                </Category>
              ))}
            </Categories>
          ) : null}
          {isHoveringCategories && (
            <ScrollButtonRight
              className={`${PREFIX_CLASSNAME}__categories__scroll-button-right__wrapper`}
              onClick={() => handleScrollCategories()}
            >
              <ScrollButton
                classPrefix={`${PREFIX_CLASSNAME}__categories`}
                type='right'
                size='small'
              />
            </ScrollButtonRight>
          )}          
        </CategoriesWrapper>
      ) : null}
      <Container
        className={`${PREFIX_CLASSNAME}__content`}
        isHorizontal={isHorizontal}
        existCategories={!!mediaCategories.length}
        onMouseEnter={handleMouseEnter}
        onMouseLeave={handleMouseLeave}
        ref={ref}
      >
        {isHorizontal && isHovering && (
          <ScrollButtonLeft
            className={`${PREFIX_CLASSNAME}__scroll-button-left__wrapper`}
            onClick={() => handleScroll(true)}
          >
            <ScrollButton
              classPrefix={PREFIX_CLASSNAME}
              type='left'
            />
          </ScrollButtonLeft>
        )}
        <Items
          className={`${PREFIX_CLASSNAME}__items`}
          isHorizontal={isHorizontal}
          existCategories={!!mediaCategories.length}
          ref={mediaRef}
        >
          {isHorizontal ? (
            <EmptyColumn className={`${PREFIX_CLASSNAME}__empty-column`} />
          ) : null}
          {media.length ? media.map((row: Feature.Profile.Media, i) => (
            <Item
              classPrefix={PREFIX_CLASSNAME}
              media={row}
              isHorizontal={isHorizontal}
              isLast={i === media.length - 1 && !mediaIsLasted}
              onReadMore={handleReadMore}
              onClick={onClick}
              key={`media-row__${row.id}`}
            />
          )) : (
            <Item
              classPrefix={PREFIX_CLASSNAME}
              isHorizontal={isHorizontal}
              onClick={onClick}
              key='media-row__empty'
            />
          )}
          {isHorizontal ? (
            <EmptyColumn className={`${PREFIX_CLASSNAME}__empty-column`} />
          ) : null}
        </Items>
        {isHorizontal && isHovering && (
          <ScrollButtonRight
            className={`${PREFIX_CLASSNAME}__scroll-button-right__wrapper`}
            onClick={() => handleScroll()}
          >
            <ScrollButton
              classPrefix={PREFIX_CLASSNAME}
              type='right'
            />
          </ScrollButtonRight>
        )}
      </Container>
    </>
  );
};

export default Media;
