import React, { useContext } from 'react';
import { ProfileContext } from 'molecules/Card/hooks';
// Components
import Item from './Item';
import {
  Container,
  Categories,
  Category,
  Items,
} from './styles';

type Props = {
  classPrefix?: string;
  headerHeight?: number | null;
  isVertical?: boolean;
  onClick?: (media: Feature.Profile.Media) => void;
};

const Media: React.FC<Props> = props => {
  const { classPrefix, headerHeight, isVertical, onClick } = props;
  const {
    mediaCategories,
    media,
    mediaCategoryId,
    mediaIsLasted,
    fetchMedia,
  } = useContext(ProfileContext);
  const PREFIX_CLASSNAME = `${classPrefix}-media`;

  const handleSelectCategory = (categoryId?: string) => fetchMedia(categoryId);
  const handleReadMore = () => fetchMedia(mediaCategoryId);

  return (
    <Container
      className={`${PREFIX_CLASSNAME}__content`}
      isVertical={isVertical}
      existCategories={!!mediaCategories.length}
    >
      {mediaCategories.length ? (
        <Categories
          className={`${PREFIX_CLASSNAME}__categories`}
          isVertical={isVertical}
        >
          <Category
            className={`${PREFIX_CLASSNAME}__categories-item`}
            isSelected={!mediaCategoryId}
            onClick={() => handleSelectCategory()}
          >
            すべて
          </Category>
          {mediaCategories.map((category) => (
            <Category
              isSelected={category.id === mediaCategoryId}
              onClick={() => handleSelectCategory(category.id)}
              key={`media-categories__${category.id}`}
            >
              {category.name}
            </Category>
          ))}
        </Categories>
      ) : null}
      <Items
        className={PREFIX_CLASSNAME}
        headerHeight={headerHeight}
        isVertical={isVertical}
        existCategories={!!mediaCategories.length}
      >
        {media.map((row: Feature.Profile.Media, i) => (
          <Item
            classPrefix={PREFIX_CLASSNAME}
            media={row}
            isVertical={isVertical}
            isLast={i === media.length - 1 && !mediaIsLasted}
            onReadMore={handleReadMore}
            onClick={onClick}
            key={`media-row__${row.id}`}
          />
        ))}
      </Items>
    </Container>
  );
};

export default Media;