import styled from 'styled-components';

export const Container = styled.li`
  display: flex;
  position: relative;
  margin: 0 0 3px 0;
  width: calc(33.3% - 4px);
  aspect-ratio: 1 / 1;
  cursor: pointer;
  overflow: hidden;
  &:first-child {
    padding-top: 0;
  }
  &:last-child {
    padding-bottom: 0;
  }
  &:nth-child(3n + 1) {
    margin: 0 0 6px 0;
  }
  &:nth-child(3n + 2), &:nth-child(3n + 3) {
    margin: 0 0 6px 6px;
  }
`;
export const VerticalContainer = styled.li`
  display: flex;
  position: relative;
  width: 104.5px;
  min-width: 104.5px;
  height: 104.5px;
  min-height: 104.5px;
  aspect-ratio: 1 / 1;
  cursor: pointer;
  overflow: hidden;
  & + & {
    margin: 0 0 0 6px;
  }
  &:first-child {
    margin-left: 10px !important;
  }
  &:last-child {
    margin: 0 10px 0 6px;
  }
`;
export const Thumbnail = styled.div`
  width: 100%;
  min-width: 100%;
  height: 100%;
  min-height: 100%;
  border-radius: 4px;
  background-color: rgb(142, 142, 142);
  overflow: hidden;
`;
export const ThumbnailImg = styled.img`
  width: 100%;
  height: 100%;
  background-color: #f4f4f5;
  border-radius: 4px;
  object-fit: cover;
`;
