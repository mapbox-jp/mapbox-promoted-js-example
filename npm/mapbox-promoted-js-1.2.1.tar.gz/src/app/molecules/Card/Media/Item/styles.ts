import styled from 'styled-components';

export const Container = styled.li`
  display: flex;
  position: relative;
  margin: 0 0 3px 0;
  width: calc(33.3% - 2px);
  aspect-ratio: 1 / 1;
  cursor: pointer;
  overflow: hidden;
  &:first-child {
    padding-top: 0;
  }
  &:last-child {
    padding-bottom: 0;
  }
  &:nth-child(3n + 2), &:nth-child(3n + 3) {
    margin: 0 0 3px 3px;
  }
`;
export const Thumbnail = styled.div``;
export const ThumbnailImg = styled.img`
  width: 100%;
  height: 100%;
  background-color: #f4f4f5;
  border-radius: 4px;
  object-fit: cover;
`;
