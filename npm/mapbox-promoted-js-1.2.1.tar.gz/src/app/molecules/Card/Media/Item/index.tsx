import React, { useState } from 'react';
import { Waypoint } from 'react-waypoint';
// Components
import {
  Container,
  Thumbnail,
  ThumbnailImg,
} from './styles';

type Props = {
  media: Feature.Profile.Media;
  isLast?: boolean;
  onReadMore: () => void;
};

const Item: React.FC<Props> = props => {
  const { media, isLast, onReadMore } = props;
  const { title, media_items } = media;
  const [isRead, setIsRead] = useState(false);
  const handleRead = () => {
    onReadMore();
    setIsRead(true);
  };
  return (
    <Container>
      {isLast && !isRead && (
        <Waypoint onEnter={handleRead} />
      )}
      <Thumbnail>
        <ThumbnailImg src={media_items.small.url} alt={title} />
      </Thumbnail>
    </Container>
  );
};

export default Item;
