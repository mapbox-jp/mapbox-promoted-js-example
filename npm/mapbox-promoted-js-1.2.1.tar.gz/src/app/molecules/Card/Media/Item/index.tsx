import React, { useState } from 'react';
import { Waypoint } from 'react-waypoint';
// Components
import {
  Container,
  VerticalContainer,
  Thumbnail,
  ThumbnailImg,
} from './styles';

type Props = {
  classPrefix?: string;
  media?: Feature.Profile.Media;
  isHorizontal?: boolean;
  isLast?: boolean;
  onReadMore?: () => void;
  onClick?: (media: Feature.Profile.Media) => void;
};

const Item: React.FC<Props> = props => {
  const { classPrefix, media, isHorizontal, isLast, onReadMore, onClick } = props;
  const { title, media_items } = media || {};
  const id = `promotion-profile-media__${media && media.id || 'empty'}`;
  const [isRead, setIsRead] = useState(false);
  const handleRead = () => {
    onReadMore && onReadMore();
    setIsRead(true);
  };
  const handleClick = () => media && onClick && onClick(media);
  const renderContent = () => (
    <>
      {isLast && !isRead && (
        <Waypoint
          horizontal={isHorizontal}
          onEnter={handleRead}
        />
      )}
      <Thumbnail className={`${classPrefix}__item__thumb`}>
        {media_items && media_items.small && (
          <ThumbnailImg
            className={`${classPrefix}__item__thumb-img`}
            src={media_items.small.url}
            alt={title}
          />
        )}
      </Thumbnail>
    </>
  );
  return isHorizontal ? (
    <VerticalContainer
      id={id}
      className={`${classPrefix}__item`}
      onClick={handleClick}
    >
      {renderContent()}
    </VerticalContainer>
  ) : (
    <Container
      id={id}
      className={`${classPrefix}__item`}
      onClick={handleClick}
    >
      {renderContent()}
    </Container>
  );
};

export default Item;
