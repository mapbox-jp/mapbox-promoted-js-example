import styled from 'styled-components';

type Container = {
  headerHeight?: number | null;
};
type Category = {
  isSelected?: boolean;
};

export const Container = styled.div`
  position: relative;
`;
export const Categories = styled.div`
  position: relative;
  display: flex;
  padding: 12px 0 15px 0;
  width: 100%;
  height; 30px;
  box-shadow: rgb(0 0 0 / 30%) 0px 0px 10px;
  z-index: 1;
  overflow-x: scroll;
  white-space: nowrap;
  scrollbar-width: none;
  &::-webkit-scrollbar {
    display: none;
  }
`;
export const Category = styled.span`
  display: block;
  margin: 0 0 0 10px;
  padding: 5px 15px;
  background-color: ${({ isSelected }: Category) => isSelected ? '#007afc' : '#ecf7ff'};
  color: ${({ isSelected }: Category) => isSelected ? '#ffffff' : '#007afc'};
  border-radius: 15px;
  font-size: 12px;
  cursor: pointer;
  transition: color 0.1s;
  &:last-child {
    margin: 0 10px 0 10px;
  }
`;
export const Items = styled.ul`
  display: flex;
  padding: 15px 10px 15px;
  flex-flow: row wrap;
  max-height: ${({ headerHeight }: Container) => headerHeight ? `calc(100% - ${headerHeight}px - 50px - 56px)` : 'auto'};
  overflow-y: scroll;
`;
