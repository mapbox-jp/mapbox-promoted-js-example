import styled from 'styled-components';

type Description = {
  isVertical?: boolean;
};
type Content = {
  isVertical?: boolean;
};

export const Container = styled.li`
  border: solid 1px #ebebed;
  border-radius: 4px;
  cursor: pointer;
  overflow: hidden;
  & + & {
    margin: 10px 0 0 0;
  }
`;
export const VerticalContainer = styled.li`
  width: 140px;
  min-width: 140px;
  height: 192px;
  max-height: 192px;
  border: solid 1px #ebebed;
  border-radius: 4px;
  cursor: pointer;
  overflow: hidden;
  & + & {
    margin: 0 0 0 6px;
  }
  &:first-child {
    margin-left: 10px !important;
  }
  &:last-child {
    margin: 0 10px 0 6px;
  }
`;
export const Thumbnail = styled.div`
  width: 100%;
  height: 102px;
  background-color: rgb(142, 142, 142);
`;
export const ThumbnailImg = styled.img`
  width: 100%;
  height: 100%;
  object-fit: cover;
`;
export const Content = styled.div`
  padding: 10px;
  ${({ isVertical }: Content) => isVertical ? `
    height: 90px;
    max-height: 90px;
  ` : `

  `};
`;
export const Title = styled.h4`
  display: -webkit-box;
  margin: 0 0 4px 0;
  font-size: 13px;
  line-height: 1.8;
  color: #636363;
  overflow: hidden;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
`;
export const Description = styled.div`
  display: -webkit-box;
  font-size: 12px;
  line-height: 1.8;
  color: #636363;
  overflow: hidden;
  -webkit-line-clamp: ${({ isVertical }: Description) => isVertical ? '2' : 'initial'};
  -webkit-box-orient: vertical;
`;
