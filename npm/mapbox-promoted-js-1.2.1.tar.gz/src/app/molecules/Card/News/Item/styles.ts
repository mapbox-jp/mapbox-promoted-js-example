import styled from 'styled-components';

export const Container = styled.li`
  border: solid 1px #ebebed;
  border-radius: 4px;
  overflow: hidden;
  & + & {
    margin-top: 10px;
  }
`;
export const Thumbnail = styled.div`
  background-color: rgb(142, 142, 142);
`;
export const ThumbnailImg = styled.img`
  width: 100%;
  height: 102px;
  object-fit: cover;
`;
export const Content = styled.div`
  padding: 10px;
`;
export const Title = styled.h4`
  display: -webkit-box;
  margin: 0 0 6px 0;
  font-size: 13px;
  line-height: 1.8;
  color: #636363;
  overflow: hidden;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
`;
export const Description = styled.div`
  display: -webkit-box;
  font-size: 12px;
  line-height: 1.8;
  color: #636363;
  overflow: hidden;
  -webkit-line-clamp: 3;
  -webkit-box-orient: vertical;
`;
