import React, { useState } from 'react';
import { Waypoint } from 'react-waypoint';
// Components
import {
  Container,
  VerticalContainer,
  Thumbnail,
  ThumbnailImg,
  Content,
  Title,
  Description,
} from './styles';

type Props = {
  classPrefix?: string;
  news: Feature.Profile.News;
  isLast?: boolean;
  isVertical?: boolean;
  onReadMore: () => void;
  onClick?: (news: Feature.Profile.News) => void;
};

const Item: React.FC<Props> = props => {
  const { classPrefix, news, isLast, isVertical, onReadMore, onClick } = props;
  const { title, text, media_items } = news;
  const id = `promotion-profile-news__${news.id}`;
  const [isRead, setIsRead] = useState(false);
  const handleRead = () => {
    onReadMore();
    setIsRead(true);
  };
  const handleClick = () => onClick && onClick(news);
  const renderContent = () => (
    <>
      {isLast && !isRead && (
        <Waypoint onEnter={handleRead} />
      )}
      <Thumbnail className={`${classPrefix}__item__thumb`}>
        {media_items && Object.keys(media_items).length && (
          <ThumbnailImg
            className={`${classPrefix}__item__thumb-img`}
            src={media_items.small.url}
          />
        )}
      </Thumbnail>
      <Content
        className={`${classPrefix}__item__content`}
        isVertical={isVertical}
      >
        <Title className={`${classPrefix}__item__title`}>
          {title}
        </Title>
        <Description
          className={`${classPrefix}__item__description`}
          isVertical={isVertical}
        >
          {text}
        </Description>
      </Content>
    </>
  );
  return isVertical ? (
    <VerticalContainer
      id={id}
      className={`${classPrefix}__item`}
      onClick={handleClick}
    >
      {renderContent()}
    </VerticalContainer>
  ) : (
    <Container
      id={id}
      className={`${classPrefix}__item`}
      onClick={handleClick}
    >
      {renderContent()}
    </Container>
  );
};

export default Item;
