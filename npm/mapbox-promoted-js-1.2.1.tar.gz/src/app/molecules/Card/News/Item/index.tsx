import React, { useState } from 'react';
import { Waypoint } from 'react-waypoint';
// Components
import {
  Container,
  Thumbnail,
  ThumbnailImg,
  Content,
  Title,
  Description,
} from './styles';

type Props = {
  news: Feature.Profile.News;
  isLast?: boolean;
  onReadMore: () => void;
};

const Item: React.FC<Props> = props => {
  const { news, isLast, onReadMore } = props;
  const { title, text, media_items } = news;
  const [isRead, setIsRead] = useState(false);
  const handleRead = () => {
    onReadMore();
    setIsRead(true);
  };
  return (
    <Container>
      {isLast && !isRead && (
        <Waypoint onEnter={handleRead} />
      )}
      {media_items && Object.keys(media_items).length && (
        <Thumbnail>
          <ThumbnailImg src={media_items.small.url} />
        </Thumbnail>
      )}
      <Content>
        <Title>
          {title}
        </Title>
        <Description>
          {text}
        </Description>
      </Content>
    </Container>
  );
};

export default Item;