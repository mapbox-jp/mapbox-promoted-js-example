import React, { useEffect, useRef, useState } from 'react';
// APIs
import { getNews } from 'apis/profiles';
// Components
import Item from './Item';
import {
  Container,
} from './styles';

type Props = {
  feature: Feature;
  headerHeight?: number | null;
};

const News: React.FC<Props> = props => {
  const { feature, headerHeight } = props;
  const { properties } = feature;
  const { feature_id } = properties;

  const newsRef = useRef<Feature.Profile.News[]>([]);
  const [nextToken, setNextToken] = useState<string>('');
  const [isLasted, setIsLasted] = useState(false);
  const [_, setDate] = useState<Date>();

  const fetchNews = (nextToken?: string) => {
    getNews(feature_id, nextToken).then(({ news, token }) => {
      newsRef.current = [...newsRef.current, ...news];
      setNextToken(token || '');
      if (!token) {
        setIsLasted(true);
      }
    }).catch((error) => {
      console.error(error);
    }).finally(() => {
      setDate(new Date());
    });
  };
  const handleReadMore = () => {
    fetchNews(nextToken);
  };
  useEffect(() => {
    fetchNews();
  }, []);

  return (
    <Container headerHeight={headerHeight}>
      {newsRef.current.map((news: Feature.Profile.News, i) => (
        <Item
          news={news}
          isLast={i === newsRef.current.length - 1 && !isLasted}
          onReadMore={handleReadMore}
          key={`news-item__${news.id}`}
        />
      ))}
    </Container>
  );
};

export default News;