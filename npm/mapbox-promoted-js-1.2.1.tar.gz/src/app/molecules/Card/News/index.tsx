import React, { useContext, useEffect } from 'react';
import { ProfileContext } from 'molecules/Card/hooks';
// Components
import Item from './Item';
import {
  Container,
} from './styles';

type Props = {
  classPrefix?: string;
  selectedNews?: Feature.Profile.News;
  headerHeight?: number | null;
  isVertical?: boolean;
  onClick?: (news: Feature.Profile.News) => void;
};

const News: React.FC<Props> = props => {
  const { classPrefix, selectedNews, headerHeight, isVertical, onClick } = props;
  const {
    news,
    newsIsLasted,
    fetchNews,
  } = useContext(ProfileContext);
  const PREFIX_CLASSNAME = `${classPrefix}-news`;

  const handleReadMore = () => fetchNews();
  
  useEffect(() => {
    if (selectedNews) {
      const id = `promotion-profile-news__${selectedNews.id}`;
      const target = document.getElementById(id);
      target && target.scrollIntoView();
    }
  }, []);

  return (
    <Container
      className={PREFIX_CLASSNAME}
      headerHeight={headerHeight}
      isVertical={isVertical}
    >
      {news.map((row: Feature.Profile.News, i) => (
        <Item
          classPrefix={PREFIX_CLASSNAME}
          news={row}
          isLast={i === news.length - 1 && !newsIsLasted}
          isVertical={isVertical}
          onReadMore={handleReadMore}
          onClick={onClick}
          key={`news-item__${row.id}`}
        />
      ))}
    </Container>
  );
};

export default News;