import styled from 'styled-components';

type Container = {
  headerHeight?: number | null;
};

export const Container = styled.ul`
  padding: 15px 10px 15px;
  max-height: ${({ headerHeight }: Container) => headerHeight ? `calc(100% - ${headerHeight}px - 50px)` : 'auto'};
  overflow-y: scroll;
`;
