import styled from 'styled-components';

type Container = {
  headerHeight?: number | null;
  isVertical?: boolean;
};

export const Container = styled.ul`
  padding: 15px 10px 15px;
  max-height: ${({ headerHeight }: Container) => headerHeight ? `calc(100% - ${headerHeight}px - 30px)` : 'auto'};
  ${({ isVertical }: Container) => isVertical ? `
    display: flex;
    padding: 0;
    height: 192px;
    max-height: 192px;
    overflow-x: scroll;
    scrollbar-width: none;
    &::-webkit-scrollbar {
      display: none;
    }
  ` : `
    padding: 15px 10px 45px;
    overflow-y: scroll;
  `};
`;
