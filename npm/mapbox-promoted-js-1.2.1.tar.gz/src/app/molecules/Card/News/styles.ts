import styled from 'styled-components';

type Container = {
  isHorizontal?: boolean;
};

export const Container = styled.div`
  position: relative;
  width: 100%;
  height: auto;
  overflow-y: scroll;
`;
export const Items = styled.ul`
  ${({ isHorizontal }: Container) => isHorizontal ? `
    display: flex;
    padding: 0;
    overflow-x: scroll;
    scrollbar-width: none;
    &::-webkit-scrollbar {
      display: none;
    }
  ` : `
    padding: 15px 10px 45px;
  `};
`;
export const ScrollButtonLeft = styled.div`
  position: absolute;
  display: flex;
  align-items: center;
  padding: 0 0 0 8px;
  top: 0;
  left: 0;
  height: 100%;
`;
export const ScrollButtonRight = styled.div`
  position: absolute;
  display: flex;
  align-items: center;
  padding: 0 8px 0 0;
  top: 0;
  right: 0;
  height: 100%;
`;
export const EmptyColumn = styled.li`
  width: 10px;
  min-width: 10px;
`;
