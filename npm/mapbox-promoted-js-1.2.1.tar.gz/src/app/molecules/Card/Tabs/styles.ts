import styled from 'styled-components';

type Container = {
  isPc?: boolean;
};

export const Container = styled.ul`
  position: relative;
  display: flex;
  margin: 0;
  padding: 0;
  left: 0;
  width: 100%;
  background-color: ${({ isPc }: Container) => isPc ? '#f4f4f5' : 'none'};
  list-style: none;
  z-index: 3;
  &:before {
    content: "";
    position: absolute;
    display: block;
    bottom: 0px;
    width: 100%;
    border-top: 2px solid #f4f4f5;
  }
`;
