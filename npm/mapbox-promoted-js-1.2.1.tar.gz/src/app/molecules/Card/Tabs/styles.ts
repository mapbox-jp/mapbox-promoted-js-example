import styled from 'styled-components';

type Container = {
  isPc?: boolean;
};

export const Container = styled.ul`
  position: relative;
  display: flex;
  flex-shrink: 0;
  width: 100%;
  height: 30px;
  max-height: 30px;
  background-color: ${({ isPc }: Container) => isPc ? '#f4f4f5' : '#ffffff'};
  list-style: none;
  z-index: 3;
  &:before {
    content: "";
    position: absolute;
    display: block;
    bottom: 0px;
    width: 100%;
    border-top: 2px solid #f4f4f5;
  }
`;
