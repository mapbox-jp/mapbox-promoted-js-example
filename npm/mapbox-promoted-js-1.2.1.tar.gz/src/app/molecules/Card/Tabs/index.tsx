import React from 'react';
import Tab from './Tab';
import { Container } from './styles';
import { isPc } from 'utils/browser';

type Props = {
  classPrefix?: string;
  children?: React.ReactNode;
};

const Tabs: React.FC<Props> = props => {
  const { classPrefix, children } = props;
  return (
    <Container
      className={`${classPrefix}__tabs`}
      isPc={isPc()}
    >
      {children}
    </Container>
  );
};

export default Tabs;
export {
  Tab,
};