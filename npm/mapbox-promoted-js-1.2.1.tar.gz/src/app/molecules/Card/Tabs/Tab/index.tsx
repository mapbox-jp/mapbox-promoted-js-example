import React from 'react';
import { Container } from './styles';
import { CLICK_TYPES } from '../../helpers';

type Props = {
  classPrefix?: string;
  label?: string;
  isSelected?: boolean;
  onClick: (type: Promotion.ClickTypes) => void;
};

const Tab: React.FC<Props> = props => {
  const { classPrefix, label, isSelected, onClick } = props;
  const handleClick = () => {
    onClick(CLICK_TYPES.TAB);
  };
  return (
    <Container
      className={`${classPrefix}__tabs-item`}
      isSelected={isSelected}
      onClick={handleClick}
    >
      {label}
    </Container>
  );
};

export default Tab;