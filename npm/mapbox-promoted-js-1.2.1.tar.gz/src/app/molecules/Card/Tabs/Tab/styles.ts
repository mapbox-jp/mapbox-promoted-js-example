import styled from 'styled-components';

type Container = {
  isSelected?: boolean;
};

export const Container = styled.li`
  display: flex;
  justify-content: center;
  align-items: center;
  flex-grow: 1;
  padding: 9px 0 7px;
  line-height: 1;
  font-size: 12px;
  border-bottom: solid 2px ${({ isSelected }: Container) => isSelected ? 'rgb(26, 115, 232)' : 'transparent'};
  color: ${({ isSelected }: Container) => isSelected ? 'rgb(26, 115, 232)' : '#636363'};
  cursor: pointer;
  transition: border-bottom 0.1s, color 0.1s;
  z-index: 1;
`;
