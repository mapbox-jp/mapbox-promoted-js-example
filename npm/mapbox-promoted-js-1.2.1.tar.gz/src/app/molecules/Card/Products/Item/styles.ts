import styled from 'styled-components';

export const Container = styled.li`
  display: flex;
  position: relative;
  padding: 13px 0px;
  width: 100%;
  cursor: pointer;
  overflow: hidden;
  &:first-child {
    padding-top: 0;
  }
  &:last-child {
    padding-bottom: 0;
  }
  & + & {
    :before {
      content: "";
      position: absolute;
      display: block;
      top: 0;
      width: 100%;
      border-top: 1px solid #e8eaed;
    }
  }
`;
export const Thumbnail = styled.div``;
export const ThumbnailImg = styled.img`
  width: 75px;
  height: 75px;
  background-color: #f4f4f5;
  object-fit: cover;
  border-radius: 4px;
`;
export const Content = styled.div`
  padding: 10px 0 10px 18px;
  width: 100%;
`;
export const Title = styled.h4`
  display: -webkit-box;
  margin: 0 0 6px 0;
  font-size: 14px;
  line-height: 1.8;
  color: #636363;
  overflow: hidden;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
`;
export const Description = styled.div`
  display: -webkit-box;
  font-size: 13px;
  line-height: 1.8;
  color: #636363;
  overflow: hidden;
  -webkit-line-clamp: 1;
  -webkit-box-orient: vertical;
`;

