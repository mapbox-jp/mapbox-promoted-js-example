import React, { useState } from 'react';
import { Waypoint } from 'react-waypoint';
// Components
import {
  Container,
  VerticalContainer,
  Thumbnail,
  ThumbnailImg,
  Content,
  Title,
  Price,
} from './styles';

type Props = {
  classPrefix?: string;
  product: Feature.Profile.Product;
  isVertical?: boolean;
  isLast?: boolean;
  onReadMore: () => void;
  onClick?: (product: Feature.Profile.Product) => void;
};

const Item: React.FC<Props> = props => {
  const { classPrefix, product, isVertical, isLast, onReadMore, onClick } = props;
  const { title, price, image_url } = product;
  const id = `promotion-profile-products__${product.id}`;
  const [isRead, setIsRead] = useState(false);
  const handleRead = () => {
    onReadMore();
    setIsRead(true);
  };
  const handleClick = () => onClick && onClick(product);
  const renderContent = () => (
    <>
      {isLast && !isRead && (
        <Waypoint onEnter={handleRead} />
      )}
      <Thumbnail className={`${classPrefix}__item__thumb`}>
        {image_url && (
          <ThumbnailImg
            className={`${classPrefix}__item__thumb-img`}
            src={image_url}
          />
        )}
      </Thumbnail>
      <Content
        className={`${classPrefix}__item__content`}
        isVertical={isVertical}
      >
        <Title
          className={`${classPrefix}__item__title`}
          isVertical={isVertical}
        >
          {title}
        </Title>
        {!!price && (
          <Price className={`${classPrefix}__item__price`}>
            {`${price}円`}
          </Price>
        )}
      </Content>
    </>
  );
  return isVertical ? (
    <VerticalContainer
      id={id}
      className={`${classPrefix}__item`}
      onClick={handleClick}
    >
      {renderContent()}
    </VerticalContainer>
  ) : (
    <Container
      id={id}
      className={`${classPrefix}__item`}
      onClick={handleClick}
    >
      {renderContent()}
    </Container>
  );
};

export default Item;
