import React, { useState } from 'react';
import { Waypoint } from 'react-waypoint';
// Components
import {
  Container,
  Thumbnail,
  ThumbnailImg,
  Content,
  Title,
  Description,
} from './styles';

type Props = {
  product: Feature.Profile.Product;
  isLast?: boolean;
  onReadMore: () => void;
};

const Item: React.FC<Props> = props => {
  const { product, isLast, onReadMore } = props;
  const { title, text, image_url } = product;
  const [isRead, setIsRead] = useState(false);
  const handleRead = () => {
    onReadMore();
    setIsRead(true);
  };
  return (
    <Container>
      {isLast && !isRead && (
        <Waypoint onEnter={handleRead} />
      )}
      <Thumbnail>
        <ThumbnailImg src={image_url} />
      </Thumbnail>
      <Content>
        <Title>
          {title}
        </Title>
        <Description>
          {text}
        </Description>
      </Content>
    </Container>
  );
};

export default Item;
