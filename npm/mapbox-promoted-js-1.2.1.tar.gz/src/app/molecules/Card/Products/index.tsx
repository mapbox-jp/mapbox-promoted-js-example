import React, { useContext, useEffect } from 'react';
import { ProfileContext } from 'molecules/Card/hooks';
// Components
import Item from './Item';
import {
  Container,
  Categories,
  Category,
  Items,
} from './styles';

type Props = {
  classPrefix?: string;
  selectedProduct?: Feature.Profile.Product;
  headerHeight?: number | null;
  isVertical?: boolean;
  onClick?: (product: Feature.Profile.Product) => void;
};

const Products: React.FC<Props> = props => {
  const { classPrefix, selectedProduct, headerHeight, isVertical, onClick } = props;
  const {
    productCategories,
    products,
    productCategoryId,
    productIsLasted,
    fetchProducts,
  } = useContext(ProfileContext);
  const PREFIX_CLASSNAME = `${classPrefix}-products`;

  const handleSelectCategory = (categoryId?: string) => fetchProducts(categoryId);
  const handleReadMore = () => fetchProducts(productCategoryId);
  
  useEffect(() => {
    if (selectedProduct) {
      const id = `promotion-profile-products__${selectedProduct.id}`;
      const target = document.getElementById(id);
      target && target.scrollIntoView();
    }
  }, []);

  return (
    <Container
      className={`${PREFIX_CLASSNAME}__content`}
      isVertical={isVertical}
      existCategories={!!productCategories.length}
    >
      {productCategories.length ? (
        <Categories
          className={`${PREFIX_CLASSNAME}__categories`}
          isVertical={isVertical}
        >
          <Category
            className={`${PREFIX_CLASSNAME}__categories-item`}
            isSelected={!productCategoryId}
            onClick={() => handleSelectCategory()}
          >
            すべて
          </Category>
          {productCategories.map((category) => (
            <Category
              className={`${PREFIX_CLASSNAME}__categories-item`}
              isSelected={category.id === productCategoryId}
              onClick={() => handleSelectCategory(category.id)}
              key={`product-categories__${category.id}`}
            >
              {category.name}
            </Category>
          ))}
        </Categories>
      ) : null}
      <Items
        className={PREFIX_CLASSNAME}
        headerHeight={headerHeight}
        isVertical={isVertical}
        existCategories={!!productCategories.length}
      >
        {products.map((row: Feature.Profile.Product, i) => (
          <Item
            classPrefix={PREFIX_CLASSNAME}
            product={row}
            isVertical={isVertical}
            isLast={i === products.length - 1 && !productIsLasted}
            onReadMore={handleReadMore}
            onClick={onClick}
            key={`products-row__${row.id}`}
          />
        ))}
      </Items>
    </Container>
  );
};

export default Products;
