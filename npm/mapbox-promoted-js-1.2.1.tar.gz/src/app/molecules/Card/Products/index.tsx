import React, { useEffect, useRef, useState } from 'react';
// APIs
import { getProducts, getProductCategories } from 'apis/profiles';
// Components
import Item from './Item';
import {
  Container,
  Categories,
  Category,
  Items,
} from './styles';

type Props = {
  feature: Feature;
  headerHeight?: number | null;
};

const Products: React.FC<Props> = props => {
  const { feature, headerHeight } = props;
  const { properties } = feature;
  const { feature_id } = properties;

  const productsRef = useRef<Feature.Profile.Product[]>([]);
  const categoriesRef = useRef<Feature.Profile.Category[]>([]);

  const [selectedCategoryId, setSelectedCategoryId] = useState<string>();
  const [nextToken, setNextToken] = useState<string>('');
  const [isLasted, setIsLasted] = useState(false);
  const [_, setDate] = useState<Date>();

  const fetchCategories = () => {
    getProductCategories(feature_id).then((categories) => {
      categoriesRef.current = [...categoriesRef.current, ...categories];
    }).catch((error) => {
      console.error(error);
    }).finally(() => {
      setDate(new Date());
    });
  };
  const fetchProducts = (nextToken?: string, cagetoryId?: string) => {
    getProducts(feature_id, nextToken, cagetoryId).then(({ products, token }) => {
      productsRef.current = [...productsRef.current, ...products];
      setNextToken(token || '');
      if (!token) {
        setIsLasted(true);
      }
    }).catch((error) => {
      console.error(error);
    }).finally(() => {
      setDate(new Date());
    });
  };
  const handleSelectCategory = (cagetoryId?: string) => {
    setSelectedCategoryId(cagetoryId);
    productsRef.current = [];
    setNextToken('');
    setIsLasted(false);
    fetchProducts('', cagetoryId);
  };
  const handleReadMore = () => {
    fetchProducts(nextToken, selectedCategoryId);
  };
  useEffect(() => {
    !categoriesRef.current.length && fetchCategories();
    fetchProducts();
  }, []);

  return (
    <Container>
      {categoriesRef.current.length ? (
        <Categories>
          <Category
            isSelected={!selectedCategoryId}
            onClick={() => handleSelectCategory()}
          >
            すべて
          </Category>
          {categoriesRef.current.map((category) => (
            <Category
              isSelected={category.id === selectedCategoryId}
              onClick={() => handleSelectCategory(category.id)}
              key={`product-categories__${category.id}`}
            >
              {category.name}
            </Category>
          ))}
        </Categories>
      ) : null}
      <Items headerHeight={headerHeight}>
        {productsRef.current.map((product: Feature.Profile.Product, i) => (
          <Item
            product={product}
            isLast={i === productsRef.current.length - 1 && !isLasted}
            onReadMore={handleReadMore}
            key={`products-row__${product.id}`}
          />
        ))}
      </Items>
    </Container>
  );
};

export default Products;
