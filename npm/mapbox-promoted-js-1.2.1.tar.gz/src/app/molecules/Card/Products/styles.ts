import styled from 'styled-components';
import { CONFIG } from 'utils/config';

type Container = {
  isVertical?: boolean;
  existCategories?: boolean;
};
type Categories = {
  isVertical?: boolean;
};
type Category = {
  isSelected?: boolean;
};
type Items = {
  headerHeight?: number | null;
  isVertical?: boolean;
  existCategories?: boolean;
};

export const Container = styled.div`
  position: relative;
  width: 100%;
  height: ${({ existCategories }: Container) => existCategories ? '133px' : '93px'};
  max-height: ${({ existCategories }: Container) => existCategories ? '133px' : '93px'};
  ${({ isVertical }: Container) => isVertical ? `

  ` : `
    height: auto;
    max-height: auto;
  `};
`;
export const Categories = styled.div`
  position: relative;
  display: flex;
  width: 100%;
  height; 30px;
  z-index: 1;
  overflow-x: scroll;
  white-space: nowrap;
  scrollbar-width: none;
  &::-webkit-scrollbar {
    display: none;
  }
  ${({ isVertical }: Categories) => isVertical ? `

  ` : `
    padding: 12px 0 15px 0;
    box-shadow: rgb(0 0 0 / 30%) 0px 0px 10px;
  `};
`;
export const Category = styled.span`
  display: block;
  margin: 0 0 0 10px;
  padding: 5px 15px;
  background-color: ${({ isSelected }: Category) => isSelected ? CONFIG.BASE_COLOR : '#ecf7ff'};
  color: ${({ isSelected }: Category) => isSelected ? '#ffffff' : CONFIG.BASE_COLOR};
  border-radius: 15px;
  font-size: 12px;
  cursor: pointer;
  transition: color 0.1s;
  &:last-child {
    margin: 0 10px 0 10px;
  }
`;
export const Items = styled.ul`
  display: flex;
  max-height: ${({ headerHeight, existCategories }: Items) => headerHeight ? `calc(100% - ${headerHeight}px - 30px - ${existCategories ? '57px' : '0px'})` : 'auto'};
  margin: ${({ existCategories }: Container) => existCategories ? '10px 0 0' : '0'};
  ${({ isVertical }: Items) => isVertical ? `
    margin: 10px 0 0;
    overflow-x: scroll;
    scrollbar-width: none;
    &::-webkit-scrollbar {
      display: none;
    }
  ` : `
    margin: 0;
    padding: 15px 10px 45px;
    flex-flow: row wrap;
    overflow-y: scroll;
  `};
`;
