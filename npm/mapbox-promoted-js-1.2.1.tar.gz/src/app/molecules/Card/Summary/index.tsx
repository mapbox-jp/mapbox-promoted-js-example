import React, { useRef, useMemo, useState } from 'react';
import { CONFIG } from 'utils/config';
// Components
import Icon, { ICON_TYPE } from 'atoms/Icon';
import BusinessHours from '../BusinessHours';
import News from '../News';
import Products from '../Products';
import Media from '../Media';
import {
  Container,
  Row,
  Title,
  OpenerIcon,
  Opener,
  BusinessHoursWrapper,
  Value,
  Label,
  LabelText,
  Remarks,
} from './styles';
import { CLICK_TYPES } from '../helpers';

type Props = {
  classPrefix?: string;
  feature: Feature;
  headerHeight?: number | null;
  onClick: (type: Promotion.ClickTypes, profileItem?: Feature.ProfileItem) => void;
};

export const PREFIX_PROFILE_CLASSNAME = 'promotion-profile';

const Summary: React.FC<Props> = props => {
  const { classPrefix, feature, headerHeight, onClick } = props;
  const { properties } = feature;
  const { summary, address_ja, address_remarks, business_hours, business_hours_remarks, phone_number } = properties;
  const PREFIX_CLASSNAME = classPrefix;

  const businessHoursRef = useRef<HTMLUListElement>(null);
  const [isOpeningBusinessHours, setIsOpeningBusinessHours] = useState(false);
  const profile = useMemo(
    () => properties.profile && typeof properties.profile === 'string' ?
      JSON.parse(properties.profile) : properties.profile,
    [properties.feature_id]
  );
  const enableProfile = profile && !!Object.values(profile).find(value => value);

  const handleClick = (type: Promotion.ClickTypes, item?: Feature.ProfileItem) => {
    if (type === CLICK_TYPES.BUSINESS_HOURS) {
      setIsOpeningBusinessHours(!isOpeningBusinessHours);
    }
    onClick && onClick(type, item);
  };

  return (
    <Container
      className={PREFIX_CLASSNAME}
      enableProfile={enableProfile}
      headerHeight={headerHeight}
    >
      {summary ? (
        <Row
          className={`${PREFIX_CLASSNAME}__row`}
          onClick={() => handleClick(CLICK_TYPES.SUMMARY)}
        >
          <Title className={`${PREFIX_CLASSNAME}__row-title`}>
            概要
          </Title>
          <Value className={`${PREFIX_CLASSNAME}__row-value`}>
            <Label className={`${PREFIX_CLASSNAME}__row-label`}>
              <LabelText
                className={`${PREFIX_CLASSNAME}__row-label__text`}
                lineClamp={3}
              >
                {summary}
              </LabelText>
            </Label>
          </Value>
        </Row>
      ) : null}
      {address_ja ? (
        <Row
          className={`${PREFIX_CLASSNAME}__row`}
          onClick={() => handleClick(CLICK_TYPES.ADDRESS)}
        >
          <Value className={`${PREFIX_CLASSNAME}__row-value`}>
            <Icon
              type={ICON_TYPE.MAP_MARKER_DOT}
              width='14px'
              height='14px'
              color={CONFIG.BASE_COLOR}
              margin='0 12px 0 0'
            />
            <Label className={`${PREFIX_CLASSNAME}__row-label`}>
              <LabelText className={`${PREFIX_CLASSNAME}__row-label__text`}>
                {address_ja}
              </LabelText>
              {address_remarks ? (
                <Remarks className={`${PREFIX_CLASSNAME}__row-title__remarks`}>
                  {address_remarks}
                </Remarks>
              ) : null}
            </Label>
          </Value>
        </Row>
      ) : null}
      {business_hours && Object.keys(business_hours).length ? (
        <Row
          className={`${PREFIX_CLASSNAME}__row`}
          cursor='pointer'
          onClick={() => handleClick(CLICK_TYPES.BUSINESS_HOURS)}
        >
          <Value className={`${PREFIX_CLASSNAME}__row-value`}>
            <Icon
              type={ICON_TYPE.CLOCK}
              width='14px'
              height='14px'
              color={CONFIG.BASE_COLOR}
              margin='0 12px 0 0'
            />
            <Label className={`${PREFIX_CLASSNAME}__row-label`}>
              <LabelText className={`${PREFIX_CLASSNAME}__row-label__text`}>
                営業時間
              </LabelText>
              {business_hours_remarks ? (
                <Remarks className={`${PREFIX_CLASSNAME}__row-title__remarks`}>
                  {business_hours_remarks}
                </Remarks>
              ) : null}
            </Label>
            <OpenerIcon isOpening={isOpeningBusinessHours}>
              <Icon type={ICON_TYPE.ANGLE_DOWN} width='14px' height='14px' />
            </OpenerIcon>
          </Value>
          <Opener
            className={`${PREFIX_CLASSNAME}__row-opener`}
            isOpening={isOpeningBusinessHours}
            height={businessHoursRef.current?.clientHeight}
          >
            <BusinessHoursWrapper className={`${PREFIX_CLASSNAME}__business-hours-wrapper`}>
              <BusinessHours
                classPrefix={PREFIX_CLASSNAME}
                businessHours={business_hours}
                ref={businessHoursRef}
              />
            </BusinessHoursWrapper>
          </Opener>
        </Row>
      ) : null}
      {phone_number ? (
        <Row
          className={`${PREFIX_CLASSNAME}__row`}
          onClick={() => handleClick(CLICK_TYPES.CALL)}
        >
          <Value className={`${PREFIX_CLASSNAME}__row-value`}>
            <Icon
              type={ICON_TYPE.PHONE}
              width='14px'
              height='14px'
              color={CONFIG.BASE_COLOR}
              margin='0 12px 0 0'
            />
            <Label className={`${PREFIX_CLASSNAME}__row-label`}>
              <LabelText className={`${PREFIX_CLASSNAME}__row-label__text`}>
                {phone_number}
              </LabelText>
            </Label>
          </Value>
        </Row>
      ) : null}
      {profile.news ? (
        <Row className={`${PREFIX_CLASSNAME}__row`}>
          <Title className={`${PREFIX_CLASSNAME}__row-title`}>
            最新情報
          </Title>
          <Value
            className={`${PREFIX_CLASSNAME}__row-value`}
            padding='0'
            margin='0 -10px'
          >
            <News
              classPrefix={PREFIX_PROFILE_CLASSNAME}
              isVertical
              onClick={news => handleClick(CLICK_TYPES.NEWS_ITEM, news)}
            />
          </Value>
        </Row>
      ) : null}
      {profile.products ? (
        <Row className={`${PREFIX_CLASSNAME}__row`}>
          <Title className={`${PREFIX_CLASSNAME}__row-title`}>
            メニュー
          </Title>
          <Value
            className={`${PREFIX_CLASSNAME}__row-value`}
            padding='0'
            margin='0 -10px'
          >
            <Products
              classPrefix={PREFIX_PROFILE_CLASSNAME}
              isVertical
              onClick={product => handleClick(CLICK_TYPES.PRODUCT_ITEM, product)}
            />
          </Value>
        </Row>
      ) : null}
      {profile.media ? (
        <Row className={`${PREFIX_CLASSNAME}__row`}>
          <Title className={`${PREFIX_CLASSNAME}__row-title`}>
            写真
          </Title>
          <Value
            className={`${PREFIX_CLASSNAME}__row-value`}
            padding='0'
            margin='0 -10px'
          >
            <Media
              classPrefix={PREFIX_PROFILE_CLASSNAME}
              isVertical
              onClick={media => handleClick(CLICK_TYPES.MEDIA_ITEM, media)}
            />
          </Value>
        </Row>
      ) : null}
    </Container>
  );
};

export default Summary;
