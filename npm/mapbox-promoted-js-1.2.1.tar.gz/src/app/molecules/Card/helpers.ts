export const CARD_TYPES = {
  SIDE_MENU: 'sidemenu-card',
  BOTTOM_CARD: 'bottom-card',
  POPUP: 'popup-card',
} as const;

export type CardTypes = typeof CARD_TYPES[keyof typeof CARD_TYPES];

export const CLICK_TYPES = {
  ADS: 'Ads',
  CARD: 'Card',
  BANNER: 'BannerDetail',
  SUMMARY: 'Summary',
  ADDRESS: 'Address',
  BUSINESS_HOURS: 'BusinessHours',
  CALL: 'Call',
  ROUTE: 'Route',
  LINE: 'Line',
  INSTAGRAM: 'Instagram',
  FACEBOOK: 'Facebook',
  TWITTER: 'Twitter',
  APP_STORE: 'AppStore',
  PLAY_STORE: 'PlayStore',
  DETAIL: 'Detail',
  TAB: 'Tab',
} as const;

export const TAB_TYPES = {
  SUMARRY: 'card-tab-sumarry',
  NEWS: 'card-tab-news',
  PRODUCTS: 'card-tab-products',
  MEDIA: 'card-tab-media',
  INFO: 'card-tab-info',
} as const;

export type TabTypes = typeof TAB_TYPES[keyof typeof TAB_TYPES];
