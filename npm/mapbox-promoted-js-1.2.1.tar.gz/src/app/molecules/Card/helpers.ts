export const CLICK_TYPES = {
  ATTRIBUTION: 'attribution',
  QUOTE: 'quote',
  CARD: 'Card',
  BANNER: 'BannerDetail',
  SUMMARY: 'Summary',
  ADDRESS: 'Address',
  BUSINESS_HOURS: 'BusinessHours',
  CALL: 'Call',
  ROUTE: 'Route',
  NAVIGATION: 'Navigation',
  LINE: 'Line',
  INSTAGRAM: 'Instagram',
  FACEBOOK: 'Facebook',
  TWITTER: 'Twitter',
  APP_STORE: 'AppStore',
  PLAY_STORE: 'PlayStore',
  DETAIL: 'Detail',
  TAB: 'Tab',
  NEWS: 'News',
  PRODUCT: 'Product',
  MEDIA: 'Media',
  NEWS_ITEM: 'NewsItem',
  PRODUCT_ITEM: 'ProductItem',
  MEDIA_ITEM: 'MediaItem',
} as const;

export const TAB_TYPES = {
  SUMARRY: 'card-tab-sumarry',
  NEWS: 'card-tab-news',
  PRODUCT: 'card-tab-product',
  MEDIA: 'card-tab-media',
  INFO: 'card-tab-info',
} as const;

export type TabTypes = typeof TAB_TYPES[keyof typeof TAB_TYPES];
