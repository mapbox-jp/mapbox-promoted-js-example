import styled from 'styled-components';

type Container = {
  height?: string;
};
type Banner = {
  height: number;
};

export const Container = styled.div`
  display: flex;
  flex-direction: column;
  height: ${({ height }: Container) => height || '100%'};
  background-color: rgb(255, 255, 255);
`;
export const Header = styled.div`
  flex-shrink: 0;
  padding: 10px;
`;
export const Banner = styled.div.attrs(({ height }: Banner) => ({ height }))`
  display: block;
  border-radius: 4px;
  overflow: hidden;
`;
export const BannerAnchar = styled.a.attrs(({ height }: Banner) => ({ height }))`
  display: block;
  border-radius: 4px;
  overflow: hidden;
`;
export const BannerImg = styled.img`
  width: 100%;
  height: auto;
  object-fit: cover;
`;
