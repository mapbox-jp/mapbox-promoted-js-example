import styled from 'styled-components';
import { CARD_TYPES, CardTypes } from './helpers';

type Container = {
  height?: string;
};
type Header = {
  cardType?: CardTypes;
};
type Banner = {
  height: number;
};

export const Container = styled.div`
  height: ${({ height }: Container) => height || '100%'};
  background-color: rgb(255, 255, 255);
`;
export const Header = styled.div`
  padding: ${({ cardType }: Header) => cardType === CARD_TYPES.BOTTOM_CARD ? '18px 10px 10px' : CARD_TYPES.BOTTOM_CARD ? '10px' : '10px'};
`;
export const Banner = styled.div.attrs(({ height }: Banner) => ({ height }))`
  background-color: rgb(142, 142, 142);
  border-radius: 4px;
  overflow: hidden;
`;
export const BannerAnchar = styled.a.attrs(({ height }: Banner) => ({ height }))`
  background-color: rgb(142, 142, 142);
  border-radius: 4px;
  overflow: hidden;
`;
export const BannerImg = styled.img`
  width: 100%;
  height: auto;
  object-fit: cover;
`;
export const Wrapper = styled.div`
  margin: 0;
  width: 100%;
`;
export const Content = styled.div``;
