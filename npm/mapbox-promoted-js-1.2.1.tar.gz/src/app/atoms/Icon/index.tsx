import React from 'react';
import { Container } from './styles';

import 'assets/fonts/style.css';

export const ICON_TYPE = {
  BOOKMARK: 'icon-bookmark',
  CALL: 'icon-call',
  CALENDAR: 'icon-calendar',
  ANGLE_DOWN: 'icon-angle-down',
  ANGLE_LEFT: 'icon-angle-left',
  ANGLE_RIGHT: 'icon-angle-right',
  ANGLE_UP: 'icon-angle-up',
  CLOCK: 'icon-clock',
  EARTH: 'icon-earth',
  LOCATION_ARROW: 'icon-location-arrow',
  MAP_MARKER: 'icon-marker-pin',
  MAP_MARKER_DOT: 'icon-marker-dot',
  PHONE: 'icon-phone',
  QUESTION: 'icon-question',
  QUESTION_CIRCLE: 'icon-question-circle',
  ROUTE: 'icon-route',
  SEARCH: 'icon-search',
  SHIELD_CHECK: 'icon-shield-check',
  TIMES: 'icon-times',
  LINE: 'icon-line',
  INSTAGRAM: 'icon-instagram',
  FACEBOOK: 'icon-facebook',
  TWITTER: 'icon-twitter',
  XMARK: 'icon-xmark',
};

export type IconType = typeof ICON_TYPE[keyof typeof ICON_TYPE];

type Props = {
  className?: string;
  type: IconType;
  size?: string;
  width?: string;
  height?: string;
  color?: string;
  margin?: string;
}

const Icon: React.FC<Props> = props => {
  const { className, type, size, width, height, margin, color } = props;
  return (
    <Container
      className={`icon ${type} ${className}`}
      size={size}
      margin={margin}
      width={width}
      height={height}
      color={color}
    />
  );
}

export default Icon
