import React, { useEffect, useRef, useCallback } from 'react';
// Components
import {
  Container,
  Title,
  Description,
  Actions,
  AboutButton,
  CloseButton,
} from './styles';

type Props = {
  classPrefix?: string;
  onClickDetail?: () => void;
  onClose?: (event?: React.MouseEvent<HTMLButtonElement, MouseEvent>) => void;
};

const Tooltip: React.FC<Props> = props => {
  const { classPrefix, onClickDetail, onClose } = props;
  const PREFIX_CLASSNAME = `${classPrefix}__tooltip`;

  const ref = useRef<HTMLDivElement>(null);

  const handleClickDetail = () => onClickDetail && onClickDetail();
  const handleClose = (event?: React.MouseEvent<HTMLButtonElement, MouseEvent>) => onClose && onClose(event);
  const handleClickOutside = useCallback((event: MouseEvent) => {
    if (ref.current && !ref.current.contains(event.target as Node)) {
      handleClose();
    }
  }, []);
  const removeEventListeners = () =>
    document.removeEventListener('click', handleClickOutside);

  useEffect(() => {
    document.addEventListener('click', handleClickOutside);
    return () => removeEventListeners();
  }, []);

  return (
    <Container
      className={PREFIX_CLASSNAME}
      ref={ref}
    >
      <Title className={`${PREFIX_CLASSNAME}__title`}>
        この広告について
      </Title>
          <Description className={`${PREFIX_CLASSNAME}__description`}>
            この広告はマップボックス・ジャパン合同会社が運営・管理するMapbox広告プラットフォームによって表示されています。<br />
            Mapbox広告について詳しく知りたい方、ご意見・お問合せのある方は、下記より同社サイトへアクセスしてください。
          </Description>
          <Actions className={`${PREFIX_CLASSNAME}__actions`}>
            <AboutButton
              className={`${PREFIX_CLASSNAME}__about`}
              href='https://www.mapbox.jp/ads'
              target='_blank'
              onClick={handleClickDetail}
            >
              Mapbox広告ページへ
            </AboutButton>
            <CloseButton
              className={`${PREFIX_CLASSNAME}__close`}
              onClick={handleClose}
            >
              閉じる
            </CloseButton>
          </Actions>
    </Container>
  );
};

export default Tooltip;
