import React from 'react';
import { ModalStyle, StyledModal } from './styles';

type Props = {
  classPrefix?: string;
  width?: string;
  height?: string;
  isOpen?: boolean;
  children?: React.ReactNode;
};

const Modal: React.FC<Props> = props => {
  const { classPrefix, width, height, isOpen, children } = props;
  return (
    <StyledModal
      isOpen={!!isOpen}
      width={width}
      height={height}
      overlayClassName={{
        base: `${classPrefix}__overlay-base`,
        afterOpen: `${classPrefix}__overlay-after`,
        beforeClose: `${classPrefix}__overlay-before`,
      }}
      style={ModalStyle}
    >
      {children}
    </StyledModal>
  );
};

export default Modal;
