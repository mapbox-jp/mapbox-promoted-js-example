import styled, { createGlobalStyle } from 'styled-components';
import Modal from 'react-modal';

type StyledModal = {
  width?: string;
  height?: string;
};

export const GlobalStyle = createGlobalStyle`
  .modal {
    &__overlay {
      &-base {
        position: fixed;
        bottom: -100%;
        right: 0;
        left: 0;
        height: 100%;
        transition: all 0.2;
        z-index: 10;
      }
      &-after {
        bottom: 0;
      }
      &-before {
        bottom: -100%;
      }
    }
  }
`;
export const ModalStyle = {
  content: {
    padding: 0,
    top: 0,
    bottom: 0,
    right: 0,
    left: 0,
    border: 'none',
    backgroundColor: '#000000',
  }
};
export const StyledModal = styled(Modal)`
  position: fixed;
  top: 0;
  width: ${({ width }: StyledModal) => width || '100%'};
  height: ${({ height }: StyledModal) => height || '100%'};
`;
