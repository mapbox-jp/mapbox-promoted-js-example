import React from 'react';
import { Container } from './styles';

type Props = {
  classPrefix?: string;
  onClick?: () => void;
};

const PromotionTag: React.FC<Props> = props => {
  const { classPrefix, onClick } = props;
  const handleClick = () => {
    onClick && onClick();
  };
  return (
    <Container
      className={`${classPrefix ? `${classPrefix}__` : ''}promotion-tag`}
      onClick={handleClick}
    >
      広告
    </Container>
  );
};

export default PromotionTag;
