import { CONFIG } from 'utils/config';
import PromotionSideCard from './organisms/SideCard';

window.addEventListener('DOMContentLoaded', () => {
  window.updateConfig = (updateConfig: Config) => {
    CONFIG.ACCESS_TOKEN = updateConfig.ACCESS_TOKEN;
    CONFIG.MEDIA_ID     = updateConfig.MEDIA_ID;
    CONFIG.SESSION_ID   = updateConfig.SESSION_ID;
    CONFIG.BASE_URL     = updateConfig.BASE_URL;
    CONFIG.LOG_URL      = updateConfig.LOG_URL;
    CONFIG.BASE_COLOR   = updateConfig.BASE_COLOR;
    CONFIG.MEDIA_MODAL  = updateConfig.MEDIA_MODAL;
    CONFIG.DEBUG        = updateConfig.DEBUG;
  };
});

export {
  PromotionSideCard,
};
