import { CONFIG } from 'utils/config';
import PromotionPopup from './organisms/Popup';
import PromotionCard from './organisms/Card';
import PromotionSideCard from './organisms/SideCard';

window.addEventListener('DOMContentLoaded', () => {
  window.renderApp = (updateConfig: Config) => {
    CONFIG.ACCESS_TOKEN = updateConfig.ACCESS_TOKEN;
    CONFIG.BASE_URL     = updateConfig.BASE_URL;
    CONFIG.LOG_URL      = updateConfig.LOG_URL;
    CONFIG.BASE_COLOR   = updateConfig.BASE_COLOR;
    CONFIG.MEDIA_MODAL  = updateConfig.MEDIA_MODAL;
  };
});

export {
  PromotionPopup,
  PromotionCard,
  PromotionSideCard,
};
