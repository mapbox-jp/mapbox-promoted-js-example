import Promoted from './promoted';
import promotionSideCard from './promotionSideCard';

import '@babel/polyfill';

export {
  Promoted,
  promotionSideCard,
};
