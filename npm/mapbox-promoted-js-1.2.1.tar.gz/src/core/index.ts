import Promoted from './promoted';
import PromotionPopup from './promotionPopup';
import promotionSideCard from './promotionSideCard';

import '@babel/polyfill';

export {
  Promoted,
  PromotionPopup,
  promotionSideCard,
};
