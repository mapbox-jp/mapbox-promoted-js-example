import mapboxgl from 'mapbox-gl';
import { Plugin as PromotedMapbox } from 'promoted-mapbox-plugin-js';
import { CONFIG } from 'utils/config';
import { isSmall } from 'utils/browser';
import PromotionPopup from './promotionPopup';
import PromotionCard from './promotionCard';
import PromotionSideCard from './promotionSideCard';
import Event from './event';
import Source from './source';
import Session from './session';
import EventAction from './eventAction';
import Logger from './logger';
import { SESSION_EVENT_TYPES } from './helpers';

class Promoted extends Event implements Promoted.Core {
  private _map: PromotedPlugin.Plugin;
  private _source: Promoted.Source;
  private _session: Promoted.Session;
  private _eventAction: Promoted.EventAction;
  private _logger: Promoted.Logger;
  private _promotionPopup: Promoted.PromotionPopup;
  private _promotionCard: Promoted.PromotionCard;
  private _promotionSideCard: Promoted.PromotionSideCard;

  constructor(options: Promoted.Core.Options) {
    super();
    const {
      map,
      accessToken,
      container,
      baseUrl,
      logUrl,
    } = options;

    if (map instanceof mapboxgl.Map) {
      this._map = new PromotedMapbox(map);
    } else {
      this._map = map;
    }

    CONFIG.ACCESS_TOKEN = accessToken;
    if (typeof container === 'string') {
      CONFIG.CONTAINER = document.querySelector(container) || undefined;
    } else { 
      CONFIG.CONTAINER = container;
    }

    baseUrl && (CONFIG.BASE_URL = baseUrl);
    logUrl && (CONFIG.LOG_URL = logUrl);

    this._logger = new Logger();
    this._session = new Session(this._logger);
    this._eventAction = new EventAction(this, this._session, this._logger);
    this._source = new Source(this, this._session, this._eventAction, this._logger);
    this._eventAction.source = this._source;

    this._promotionPopup = new PromotionPopup(this, this._session, this._logger);
    this._promotionCard = new PromotionCard(this, this._session, this._logger);
    this._promotionSideCard = new PromotionSideCard(this, this._session, this._logger);

    this._session.on(SESSION_EVENT_TYPES.START_SESSION, (_type, data) => this.fire(data));
    this._session.on(SESSION_EVENT_TYPES.UPDATE_SESSION, (_type, data) => this.fire(data));
    this._session.on(SESSION_EVENT_TYPES.END_SESSION, (_type, data) => this.fire(data));
  }

  get map() {
    return this._map.map;
  }

  get plugin() {
    return this._map;
  }

  get tilesets(): { [quadkey: string]: Feature[] } {
    return this._source.tilesets;
  }

  get features(): Feature[] {
    return [];
  }

  get promotionPopup(): Promoted.PromotionPopup {
    return this._promotionPopup;
  }

  get promotionCard(): Promoted.PromotionCard {
    return this._promotionCard;
  }

  get promotionSideCard(): Promoted.PromotionSideCard {
    return this._promotionSideCard;
  }

  public show(feature: Feature) {
    if (isSmall()) {
      this._promotionCard.show(feature);
    } else {
      this._promotionSideCard.show(feature);
    }
  }

  public visibleLayer() {
    this._map.visibleLayer();
  }

  public hideLayer() {
    this._map.hideLayer();
  }

  public selectFeature(feature: Feature) {
    this._map.selectFeature(feature);
  }

  public deselectLayer() {
    this._map.deselectLayer();
  }

  public reload() {
    this._source.reload();
  }
}

export default Promoted;
