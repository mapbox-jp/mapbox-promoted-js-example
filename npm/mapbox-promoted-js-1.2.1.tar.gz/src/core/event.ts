class Event implements Promoted.Event {
  private _listeners: Promoted.Event.Listeners = {};

  public on(type: Promoted.EventTypes, listener: Promoted.Event.Listener) {
    const listenerExists = this._listeners[type] && this._listeners[type].indexOf(listener) !== -1;
    if (!listenerExists) {
      this._listeners[type] = this._listeners[type] || [];
      this._listeners[type].push(listener);
    }
  }

  public off(type: Promoted.EventTypes, listener: Promoted.Event.Listener) {
    if (this._listeners && this._listeners[type]) {
      const index = this._listeners[type].indexOf(listener);
      if (index !== -1) {
        this._listeners[type].splice(index, 1);
      }
    }
  }

  public fire(data: Promoted.EventData) {
    const type = data.type as Promoted.EventTypes;
    const listeners = this._listeners[type] ? this._listeners[type].slice() : [];
    for (const listener of listeners) {
      listener.call(this, type, data);
    }
  }
}

export default Event;
