export const DISPLAY_TYPES = {
  NONE: 'none',
  POPUP: 'popup',
  CARD: 'card',
  SIDE_CARD: 'side_card',
} as const;

export const PROMOTION_TYPES = {
  CARD: 'card',
} as const;

export const EVENT_TYPES = {
  LOAD: 'load',
  MOVEEND: 'moveend',
  ZOOMEND: 'zoomend',
  SOURCEDATA: 'sourcedata',
  SOURCEDATAEND: 'sourcedataend',
  CLICK_PIN: 'click_pin',
  
  START_SESSION: 'start_session',
  UPDATE_SESSION: 'update_session',
  END_SESSION: 'end_session',

  CLICK_POPUP: 'click_popup',
  SHOW_POPUP: 'show_popup',
  CLOSE_POPUP: 'close_popup',

  CLICK_CARD: 'click_card',
  SHOW_CARD: 'show_card',
  UPDATE_CARD: 'update_card',
  CLOSE_CARD: 'close_card',

  CLICK_SIDE_CARD: 'click_side_card',
  SHOW_SIDE_CARD: 'show_side_card',
  UPDATE_SIDE_CARD: 'update_side_card',
  OPEN_SIDE_CARD: 'open_side_card',
  HIDE_SIDE_CARD: 'hide_side_card',
  CLOSE_SIDE_CARD: 'close_side_card',
} as const;

export const SESSION_EVENT_TYPES = {
  START_SESSION: 'start_session',
  UPDATE_SESSION: 'update_session',
  END_SESSION: 'end_session',
} as const;

export const CLICK_TYPES = {
  ADS: 'Ads',
  CARD: 'Card',
  BANNER: 'BannerDetail',
  SUMMARY: 'Summary',
  ADDRESS: 'Address',
  BUSINESS_HOURS: 'BusinessHours',
  CALL: 'Call',
  NAVIGATION: 'Navigation',
  LINE: 'Line',
  INSTAGRAM: 'Instagram',
  FACEBOOK: 'Facebook',
  TWITTER: 'Twitter',
  APP_STORE: 'AppStore',
  PLAY_STORE: 'PlayStore',
  DETAIL: 'Detail',
  TAB: 'Tab',
  NEWS: 'News',
  PRODUCT: 'Product',
  MEDIA: 'Media',
  NEWS_ITEM: 'NewsItem',
  PRODUCT_ITEM: 'ProductItem',
  MEDIA_ITEM: 'MediaItem',
} as const;

export type ClickTypes = typeof CLICK_TYPES[keyof typeof CLICK_TYPES];

export const CALLTOACTION_TYPES: string[] = [
  CLICK_TYPES.ADS,
  CLICK_TYPES.BANNER,
  CLICK_TYPES.CALL,
  CLICK_TYPES.NAVIGATION,
  CLICK_TYPES.LINE,
  CLICK_TYPES.INSTAGRAM,
  CLICK_TYPES.FACEBOOK,
  CLICK_TYPES.TWITTER,
  CLICK_TYPES.APP_STORE,
  CLICK_TYPES.PLAY_STORE,
  CLICK_TYPES.DETAIL,
  CLICK_TYPES.NEWS,
  CLICK_TYPES.PRODUCT,
  CLICK_TYPES.MEDIA,
];

export const FEEDBACK_TYPES = {
  ATTRIBUTION_DETAIL: 'AdsAttributionDetail',
  QUOTE: 'AdsQuote',
} as const;

export const isFeedback = (type: string) =>
  type === CLICK_TYPES.ADS;

export const isCallToAction = (type: Promotion.ClickTypes) =>
  CALLTOACTION_TYPES.includes(type);
