export const DISPLAY_TYPES = {
  NONE: 'none',
  POPUP: 'popup',
  CARD: 'card',
  SIDE_CARD: 'side_card',
} as const;

export const PROMOTION_TYPES = {
  CARD: 'card',
} as const;

export const EVENT_TYPES = {
  LOAD: 'load',
  MOVEEND: 'moveend',
  ZOOMEND: 'zoomend',
  SOURCEDATA: 'sourcedata',
  SOURCEDATAEND: 'sourcedataend',
  CLICK_PIN: 'click_pin',
  
  START_SESSION: 'start_session',
  UPDATE_SESSION: 'update_session',
  END_SESSION: 'end_session',

  CLICK_POPUP: 'click_popup',
  SHOW_POPUP: 'show_popup',
  CLOSE_POPUP: 'close_popup',

  CLICK_CARD: 'click_card',
  SHOW_CARD: 'show_card',
  UPDATE_CARD: 'update_card',
  CLOSE_CARD: 'close_card',

  CLICK_SIDE_CARD: 'click_side_card',
  SHOW_SIDE_CARD: 'show_side_card',
  UPDATE_SIDE_CARD: 'update_side_card',
  OPEN_SIDE_CARD: 'open_side_card',
  HIDE_SIDE_CARD: 'hide_side_card',
  CLOSE_SIDE_CARD: 'close_side_card',
} as const;

export const SESSION_EVENT_TYPES = {
  START_SESSION: 'start_session',
  UPDATE_SESSION: 'update_session',
  END_SESSION: 'end_session',
} as const;

export const CLICK_TYPES = {
  ADS: 'Ads',
  TOGGLE: 'Toggle',
  BANNER: 'BannerDetail',
  CALL: 'Call',
  ROUTE: 'Route',
  NAVIGATION: 'Navigation',
  LINE: 'Line',
  INSTAGRAM: 'Instagram',
  FACEBOOK: 'Facebook',
  TWITTER: 'Twitter',
  APP_STORE: 'AppStore',
  PLAY_STORE: 'PlayStore',
  DETAIL: 'Detail',
} as const;

export type ClickTypes = typeof CLICK_TYPES[keyof typeof CLICK_TYPES];

export const FEEDBACK_TYPES = {
  ATTRIBUTION_DETAIL: 'AdsAttributionDetail',
  QUOTE: 'AdsQuote',
} as const;

export const isFeedback = (type: string) => {
  return type === CLICK_TYPES.ADS;
};

export const isCallToAction = (type: Promotion.ClickTypes) => {
  return (Object.values(CLICK_TYPES) as string[]).includes(type);
};
