import {
  insertEndpointElement,
  updateEndpointElement,
  removeEndpointElement,
} from 'utils/browser';
import EventData from './eventData';
import { EVENT_TYPES } from './helpers';

class PromotionSideCard implements Promoted.PromotionSideCard {
  private _promoted: Promoted.Core;
  private _session: Promoted.Session;
  private _logger: Promoted.Logger;
  private _feature: Feature | undefined;

  constructor(promoted: Promoted.Core, session: Promoted.Session, logger: Promoted.Logger) {
    this._promoted = promoted;
    this._session = session;
    this._logger = logger;
  }

  get feature() {
    return this._feature;
  }

  private clickEvent(clickType: Promotion.ClickTypes, feature: Feature, profileItems?: Feature.ProfileItems) {
    let eventData: any = {
      clickType,
      feature,
    };
    if (profileItems && profileItems.news) {
      eventData['news'] = profileItems.news;
    }
    if (profileItems && profileItems.product) {
      eventData['product'] = profileItems.product;
    }
    if (profileItems && profileItems.media) {
      eventData['media'] = profileItems.media;
    }
    this._promoted.fire(new EventData(EVENT_TYPES.CLICK_SIDE_CARD, eventData));
    this._promoted.sendAction(feature, clickType);
    this._session.update();
  }

  private updateEvent(feature: Feature) {
    this._promoted.fire(new EventData(
      EVENT_TYPES.CLOSE_SIDE_CARD, {
        feature 
      }
    ));
    this._promoted.plugin.selectFeature(feature);
    this._logger.deselect(
      this._session.sessionId,
      feature,
      Math.floor(this._promoted.plugin.zoomLevel)
    );
  }

  private closeEvent(feature: Feature) {
    this._promoted.fire(new EventData(
      EVENT_TYPES.CLOSE_SIDE_CARD, {
        feature 
      }
    ));
    this._promoted.plugin.deselectLayer();
    this._logger.deselect(
      this._session.sessionId,
      feature,
      Math.floor(this._promoted.plugin.zoomLevel)
    );
  }

  public render(container: string | HTMLElement, feature: Feature): HTMLElement | undefined {
    return renderPromotionSideCardInnerElement && renderPromotionSideCardInnerElement(
      container,
      feature,
      (clickType: Promotion.ClickTypes, targetFeature: Feature, profileItems?: Feature.ProfileItems) => {
        this.clickEvent(clickType, targetFeature, profileItems);
      },
      (targetFeature: Feature) => {
        this.updateEvent(targetFeature);
      },
      (targetFeature: Feature) => {
        this.closeEvent(targetFeature);
      },
    );
  }

  public show(feature: Feature) {
    const { properties } = feature;
    const element = document.querySelector('.mapbox-promoted-side-card');
    const featureClass = `mapbox-promoted-side-card__feature-${properties.feature_id}`;
    const childElement = document.querySelector(`.${featureClass}`);
    this._feature = feature;

    // when if same promotion icon was clicked, it deletes current promotion side card.
    if (element && childElement) { return; }
    // when if another promotion icon was clicked, it updates promotion side card.
    if (element && !childElement && updatePromotionSideCard) {
      this._promoted.fire(new EventData(
        EVENT_TYPES.UPDATE_SIDE_CARD, {
          feature
        }
      ));
      updateEndpointElement('.mapbox-promoted-side-card', `mapbox-promoted-side-card ${featureClass}`);
      updatePromotionSideCard(feature);
      return;
    }

    insertEndpointElement(`mapbox-promoted-side-card ${featureClass}`);

    if (showPromotionSideCard) {
      showPromotionSideCard(
        feature,
        (clickType: Promotion.ClickTypes, targetFeature: Feature, profileItems?: Feature.ProfileItems) => {
          this.clickEvent(clickType, targetFeature, profileItems);
        },
        (targetFeature: Feature) => {
          this.updateEvent(targetFeature);
        },
        (targetFeature: Feature) => {
          this.closeEvent(targetFeature);
          this.remove();
        },
        (targetFeature: Feature) => {
          this._promoted.fire(new EventData(
            EVENT_TYPES.OPEN_SIDE_CARD, {
              feature: targetFeature
            }
          ));
        },
        (targetFeature: Feature) => {
          this._promoted.fire(new EventData(
            EVENT_TYPES.HIDE_SIDE_CARD, {
              feature: targetFeature
            }
          ));
        }
      );
      this._promoted.plugin.selectFeature(feature);
      this._promoted.fire(new EventData(
        EVENT_TYPES.SHOW_SIDE_CARD, {
          feature
        }
      ));
    }
  }

  public close() {
    this._feature = undefined;
    closePromotionSideCard && closePromotionSideCard();
  }

  public remove() {
    try {
      this._feature = undefined;
      removeEndpointElement('.mapbox-promoted-side-card');
    } catch (error: any) {
      console.error(error);
      this._logger.log('error_internal', error);
    }
  }
}

export default PromotionSideCard;
