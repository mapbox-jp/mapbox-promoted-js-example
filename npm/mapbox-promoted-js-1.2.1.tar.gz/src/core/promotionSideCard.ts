import {
  insertEndpointElement,
  updateEndpointElement,
  removeEndpointElement,
} from 'utils/browser';
import EventData from './eventData';
import { EVENT_TYPES, FEEDBACK_TYPES, isFeedback, isCallToAction } from './helpers';

class PromotionSideCard implements Promoted.PromotionSideCard {
  private _promoted: Promoted.Core;
  private _session: Promoted.Session;
  private _logger: Promoted.Logger;
  private _feature: Feature | undefined;

  constructor(promoted: Promoted.Core, session: Promoted.Session, logger: Promoted.Logger) {
    this._promoted = promoted;
    this._session = session;
    this._logger = logger;
  }

  get feature() {
    return this._feature;
  }

  private sendAction(feature: Feature, clickType: Promotion.ClickTypes) {
    try {
      if (isFeedback(clickType)) {
        this._logger.feedback(
          this._session.sessionId,
          feature,
          Math.floor(this._promoted.plugin.zoomLevel),
          FEEDBACK_TYPES.QUOTE,
        );
      } else if (isCallToAction(clickType)) {
        this._logger.callToAction(
          this._session.sessionId,
          feature,
          Math.floor(this._promoted.plugin.zoomLevel),
          clickType as Promoted.Logger.ActionTypes,
        );
      }
    } catch (error: any) {
      console.error(error);
      this._logger.log('error_internal', error);
    }
  }

  public show(feature: Feature) {
    const { properties } = feature;
    const element = document.querySelector('.mapbox-promoted-side-card');
    const featureClass = `mapbox-promoted-side-card__feature-${properties.feature_id}`;
    const childElement = document.querySelector(`.${featureClass}`);
    this._feature = feature;

    // when if same promotion icon was clicked, it deletes current promotion side card.
    if (element && childElement) { return; }
    // when if another promotion icon was clicked, it updates promotion side card.
    if (element && !childElement && updatePromotionSideCard) {
      this._promoted.fire(new EventData(
        EVENT_TYPES.UPDATE_SIDE_CARD, {
          feature
        }
      ));
      updateEndpointElement('.mapbox-promoted-side-card', `mapbox-promoted-side-card ${featureClass}`);
      updatePromotionSideCard(feature);
      return;
    }

    this._promoted.fire(new EventData(
      EVENT_TYPES.SHOW_SIDE_CARD, {
        feature
      }
    ));
    insertEndpointElement(`mapbox-promoted-side-card ${featureClass}`);

    if (showPromotionSideCard) {
      showPromotionSideCard(
        feature,
        (clickType: Promotion.ClickTypes, targetFeature: Feature) => {
          this._promoted.fire(new EventData(
            EVENT_TYPES.CLICK_SIDE_CARD, {
              clickType, feature: targetFeature
            }
          ));
          this.sendAction(targetFeature, clickType);
          this._session.update();
        },
        (targetFeature: Feature) => {
          this._promoted.fire(new EventData(
            EVENT_TYPES.CLOSE_SIDE_CARD, {
              feature: targetFeature 
            }
          ));
          this._promoted.plugin.deselectLayer();
          this._logger.deselect(
            this._session.sessionId,
            targetFeature,
            Math.floor(this._promoted.plugin.zoomLevel)
          );
          this.remove();
        },
        (targetFeature: Feature) => {
          this._promoted.fire(new EventData(
            EVENT_TYPES.OPEN_SIDE_CARD, {
              feature: targetFeature
            }
          ));
        },
        (targetFeature: Feature) => {
          this._promoted.fire(new EventData(
            EVENT_TYPES.HIDE_SIDE_CARD, {
              feature: targetFeature
            }
          ));
        }
      );
      this._promoted.plugin.selectFeature(feature);
    }
  }

  public close() {
    this._feature = undefined;
    closePromotionSideCard && closePromotionSideCard();
  }

  public remove() {
    try {
      this._feature = undefined;
      removeEndpointElement('.mapbox-promoted-side-card');
    } catch (error: any) {
      console.error(error);
      this._logger.log('error_internal', error);
    }
  }
}

export default PromotionSideCard;