class EventData implements Promoted.EventData {
  public type: Promoted.EventTypes;
  public data: Object;

  constructor(type: Promoted.EventTypes, data: Object = {}) {
    this.type = type;
    this.data = data;
  }
}

export default EventData;
