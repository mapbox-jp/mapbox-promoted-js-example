import { Popup } from 'mapbox-gl';
import EventData from './eventData';
import { EVENT_TYPES, FEEDBACK_TYPES, isFeedback, isCallToAction } from './helpers';

class PromotionPopup implements Promoted.PromotionPopup {
  private _promoted: Promoted.Core;
  private _session: Promoted.Session;
  private _logger: Promoted.Logger;
  private _popupGroups: { [featureId: string]: Promoted.PromotionPopup.PopupGroup } = {};

  constructor(promoted: Promoted.Core, session: Promoted.Session, logger: Promoted.Logger) {
    this._promoted = promoted;
    this._session = session;
    this._logger = logger;
  }

  private sendAction(feature: Feature, clickType: Promotion.ClickTypes) {
    try {
      if (isFeedback(clickType)) {
        this._logger.feedback(
          this._session.sessionId,
          feature,
          Math.floor(this._promoted.plugin.zoomLevel),
          FEEDBACK_TYPES.QUOTE,
        );
      } else if (isCallToAction(clickType)) {
        this._logger.callToAction(
          this._session.sessionId,
          feature,
          Math.floor(this._promoted.plugin.zoomLevel),
          clickType as Promoted.Logger.ActionTypes,
        );
      }
    } catch (error: any) {
      console.error(error);
      this._logger.log('error_internal', error);
    }
  }

  private scrutinyPopups() {
    for (const popupGroup of Object.values(this._popupGroups)) {
      this.close(popupGroup.feature);
    }
  }

  public getFeatureByPoints(x: number, y: number): Feature | undefined {
    const selectedFeatures = this._promoted.plugin.getRenderedFeatures({ x, y });
    if (selectedFeatures.length <= 0) { return; }
    return selectedFeatures[0] as Feature;
  }

  public generatePopupClassName(feature: Feature): string {
    return `mapbox-promoted-popup__feature-${feature.properties.feature_id}`;
  }

  public show(feature: Feature, options?: PromotionPopup.InputOptions) {
    const { properties } = feature;
    const { feature_id, promotion_type } = properties;
    const coordinates = (feature.geometry as any).coordinates.slice();
    const popupClass = this.generatePopupClassName(feature);
    const popupElement = document.querySelector(`.${popupClass}`);
    if (popupElement) { return; }

    this.scrutinyPopups();

    this._promoted.fire(new EventData(
      EVENT_TYPES.SHOW_POPUP, {
        feature
      }
    ));
    this._logger.select(this._session.sessionId, feature, Math.floor(this._promoted.plugin.zoomLevel), promotion_type || 'card');

    const popup = new Popup({
      offset: [0, -30],
      closeOnClick: false,
      closeButton: false,
      className: `mapbox-promoted-popup ${popupClass}`,
    }).setLngLat(coordinates)
      .setHTML(`<div class="mapbox-promoted-popup__content__feature-${properties.feature_id}" />`)
      .addTo(this._promoted.map);

    this._popupGroups[feature_id] = {
      popup,
      sessionId: this._session.sessionId,
      feature,
    };

    if (showPromotionPopup) {
      showPromotionPopup(
        this,
        feature,
        (clickType: Promotion.ClickTypes, targetFeature: Feature) => {
          this._promoted.fire(new EventData(
            EVENT_TYPES.CLICK_POPUP, {
              clickType,
              feature: targetFeature
            }
          ));
          this.sendAction(targetFeature, clickType);
          this._session.update();
        },
        (targetFeature: Feature) => {
          this.remove(targetFeature);
        },
        options
      );
      this._promoted.plugin.selectFeature(feature);
    }
  }

  public close(feature: Feature) {
    const { feature_id } = feature.properties
    const popupGroup = this._popupGroups[feature_id];
    if (!popupGroup) { return; }
    window.requestAnimationFrame(() => {
      closePromotionPopup && closePromotionPopup(feature);
    });
  }

  public remove(feature: Feature) {
    try {
      const { feature_id } = feature.properties
      const popupGroup = this._popupGroups[feature_id];
      if (!popupGroup) { return; }
      popupGroup.popup.remove();
      this._promoted.fire(new EventData(
        EVENT_TYPES.CLOSE_POPUP, {
          feature
        }
      ));
      this._promoted.plugin.deselectLayer();
      this._logger.deselect(
        this._session.sessionId,
        feature,
        Math.floor(this._promoted.plugin.zoomLevel)
      );
      delete this._popupGroups[feature_id];
    } catch (error: any) {
      console.error(error);
      this._logger.log('error_internal', error);
    }
  }
}

export default PromotionPopup;
