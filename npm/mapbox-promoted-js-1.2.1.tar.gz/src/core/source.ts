import { getFeatures } from 'apis/features';
import {
  quadkeyToTile,
  getTileBound,
  getQuadkeysOnBound,
} from 'utils/geometry';

class Source implements Promoted.Source {
  private _promoted: Promoted.Core;
  private _session: Promoted.Session;
  private _eventAction: Promoted.EventAction;
  private _logger: Promoted.Logger;
  private _tilesetsMap: { [quadkey: string]: Feature[] } = {};
  private _featuresMap: { [featureId: string]: Feature } = {};
  private _renderedFeatureLogsMap: { [featureId: string]: FeatureLog } = {};

  constructor(
    promoted: Promoted.Core,
    session: Promoted.Session,
    eventAction: Promoted.EventAction,
    logger: Promoted.Logger
  ) {
    this._promoted = promoted;
    this._session = session;
    this._eventAction = eventAction;
    this._logger = logger;
  }

  get tilesets(): { [quadkey: string]: Feature[] } {
    return this._tilesetsMap;
  }

  get features(): Feature[] {
    return Object.values(this._featuresMap);
  }

  public getFeaturesOnBounds(): Feature[] {
    const { sw, ne } = this._promoted.plugin.getBounds();
    const { quadkeys } = getQuadkeysOnBound(sw, ne, this._promoted.plugin.zoomLevel);
    const featuresOnBound: Feature[] = [];
    for (const quadkey of quadkeys) {
      if (!(quadkey in this._tilesetsMap)) continue;
      const features = this._tilesetsMap[quadkey];
      for (const feature of features) {
        const coordinates = (feature.geometry as any).coordinates;
        if (
          sw.lng <= coordinates[0] && coordinates[0] < ne.lng &&
          sw.lat <= coordinates[1] && coordinates[1] < ne.lat
        ) {
          featuresOnBound.push(feature);
        }
      }
    }
    return featuresOnBound;
  }

  public convertToFeaturesMap(features: Feature[]): { [key: string]: Feature } {
    const featuresMap: { [key: string]: Feature } = {};
    for (const feature of features) {
      featuresMap[feature.properties.feature_id] = feature;
    }
    return featuresMap;
  }

  public addSource(quadkeys: string[]) {
    for (const quadkey of quadkeys) {
      // It is already requested, and there are same data at this._tileset
      if (this._tilesetsMap[quadkey]) {
        const features = this._tilesetsMap[quadkey];
        this.updateFeatures(quadkey, features);
        continue;
      }
      // There is not data with a quadkey, it need to make request
      getFeatures(quadkey).then((response: GeoJSON.FeatureCollection<GeoJSON.Geometry> ) => {
        const features = response.features as Feature[];
        this.updateFeatures(quadkey, features, true);
      }).catch((error) => {
        console.error(error);
        if (error.status !== 0) {
          this._logger.log('error_internal', error.text || error.toString());
        }
      });
    }
  }

  private updateFeatures(quadkey: string, features: Feature[], isFetch = false) {
    try {
      const { x, y, z } = quadkeyToTile(quadkey);
      const { ne, sw } = getTileBound(x, y, z);

      if (isFetch) {
        this._tilesetsMap[quadkey] = features;
      }
  
      // Adding or updating features by key
      for (const feature of features) {
        this._featuresMap[feature.properties.feature_id] = feature;
      }
      // Remove features that are droped at the new auction
      for (const feature of Object.values(this._featuresMap)) {
        const coordinates = (feature.geometry as any).coordinates;
        // Current features which are contained at the coordinates that was requested
        if (
          ne.lng <= coordinates[0] && coordinates[0] < sw.lng &&
          sw.lat <= coordinates[1] && coordinates[1] < ne.lat
        ) {
          const targetFeature = features.find(responseFeature =>
            responseFeature.properties.feature_id === feature.properties.feature_id);
          if (!targetFeature) {
            delete this._featuresMap[feature.properties.feature_id];
          }
        }
      }
      this.render();
    } catch (error: any) {
      this._logger.log('error_internal', error);
    }
  }

  private render() {
    const { visibledFeatures, unvisibledFeatures } = this.updateFeatureVisibles();
    this._promoted.plugin.render(this.features, visibledFeatures, unvisibledFeatures);
  }

  public updateFeatureVisibles(): {
    visibledFeatures: Feature[];
    unvisibledFeatures: Feature[];
  } {
    const features = this.getFeaturesOnBounds();
    const featuresMap = this.convertToFeaturesMap(features);
    const visibledFeatures: Feature[] = [];
    const visibledFeatureLogsMap: { [featureId: string]: FeatureLog } = {};
    const unvisibledFeatures: Feature[] = [];
    const unvisibledFeatureLogsMap: { [featureId: string]: FeatureLog } = {};

    // unvisibled feature objects that was rendered before
    const updateRenderedFeatureLogs: { [featureId: string]: FeatureLog } = {};
    for (const featureLog of Object.values(this._renderedFeatureLogsMap)) {
      const isExist = !!featuresMap[featureLog.feature.properties.feature_id];
      if (!isExist) {
        unvisibledFeatures.push(featureLog.feature);
        unvisibledFeatureLogsMap[featureLog.feature.properties.feature_id] = {
          ...featureLog,
          endActionType: this._eventAction.lastActionType,
          endZoomLevel: this._promoted.plugin.zoomLevel,
          visibleEndTime: Date.now(),
        };
      } else {
        updateRenderedFeatureLogs[featureLog.feature.properties.feature_id] = featureLog;
      }
    }
    this._renderedFeatureLogsMap = updateRenderedFeatureLogs;

    // adding visibled new feature objects
    for (const feature of features) {
      const isExisted = !!this._renderedFeatureLogsMap[feature.properties.feature_id];
      if (!isExisted && feature.properties.cps) {
        visibledFeatures.push(feature);
        visibledFeatureLogsMap[feature.properties.feature_id] = {
          feature,
          startActionType: this._eventAction.lastActionType,
          startZoomLevel: this._promoted.plugin.zoomLevel,
          visibleStartTime: Date.now(),
        };
      }
    };
    this._renderedFeatureLogsMap = { ...this._renderedFeatureLogsMap, ...visibledFeatureLogsMap };

    Object.keys(unvisibledFeatureLogsMap).length && (
      this._logger.visibles(this._session.sessionId, Object.values(unvisibledFeatureLogsMap))
    );

    return {
      visibledFeatures,
      unvisibledFeatures,
    }
  }

  public reload() {
    this._tilesetsMap = {};
    this._featuresMap = {};
    this._promoted.plugin.reload();
  }
}

export default Source;
