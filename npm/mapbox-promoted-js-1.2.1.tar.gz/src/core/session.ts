import { v4 as uuidv4 } from 'uuid';
import EventData from './eventData';
import SessionEvent from './sessionEvent';
import { SESSION_EVENT_TYPES } from './helpers';

const SESSION_INTERVAL = 60 * 1000;

class Session extends SessionEvent implements Promoted.Session {
  private _logger: Promoted.Logger;
  private _start = new Date();
  private _sessionId = '';
  private _timerId = -1;

  constructor(logger: Promoted.Logger) {
    super();

    this._logger = logger;
  }

  get startDate() {
    return this._start;
  }

  get sessionId() {
    if (!this._sessionId) {
      this.start();
    }
    return this._sessionId;
  }

  public start() {
    this._start = new Date();
    this._sessionId = uuidv4();
    this._timerId = window.setTimeout(this.end.bind(this), SESSION_INTERVAL);
    this._logger.session(this._sessionId);
    this.fire(new EventData(
      SESSION_EVENT_TYPES.START_SESSION, {
        start: this.startDate
      }
    ));
  }

  public update() {
    if (this._timerId === -1) {
      this.start();
      return;
    }
    clearTimeout(this._timerId);
    this._timerId = window.setTimeout(this.end.bind(this), SESSION_INTERVAL);
    this.fire(new EventData(
      SESSION_EVENT_TYPES.UPDATE_SESSION, {
        start: this.startDate
      }
    ));
  }

  private end() {
    this._timerId = -1;
    this.fire(new EventData(
      SESSION_EVENT_TYPES.END_SESSION, {
        start: this.startDate
      }
    ));
    this._sessionId = '';
  }
}

export default Session;
