import ajax from './ajax';
import { CONFIG } from 'utils/config';

const getLinkParams = (linkStr: string) => {
  const match = linkStr.match(/<https?\:\/\/.*?\/loc\/v1\/features\/.*?\/.*?\?limit=(.*?)\&start=(.*?)>/) || [];
  return {
    type: match[0],
    limit: match[1],
    token: match[2],
  };
};

export function getMediaCategories(featureId: string): Promise<Feature.Profile.Category[]> {
  return new Promise((resolve, reject) => {
    const headers = {
      'Authorization': `Bearer ${CONFIG.ACCESS_TOKEN}`,
    };
    const url = `/loc/v1/features/${featureId}/media/categories`;
    return new ajax(CONFIG.BASE_URL, { headers }).get(url).then((response: any) => {
      resolve(response[0].categories);
    }).catch((error: Error) => {
      reject(error);
    });
  });
}

export function getNews(featureId: string, start?: string, limit = 6): Promise<{ news: Feature.Profile.News[], token?: string }> {
  return new Promise((resolve, reject) => {
    const headers = {
      'Authorization': `Bearer ${CONFIG.ACCESS_TOKEN}`,
    };
    const url = `/loc/v1/features/${featureId}/news?limit=${limit}${start ? `&start=${start}` : ''}`;
    return new ajax(CONFIG.BASE_URL, { headers }).get(url).then((response: any) => {
      const { token } = getLinkParams(response[1].link || '');
      resolve({
        news: response[0].news,
        token
      });
    }).catch((error: Error) => {
      reject(error);
    });
  });
}

export function getProductCategories(featureId: string): Promise<Feature.Profile.Category[]> {
  return new Promise((resolve, reject) => {
    const headers = {
      'Authorization': `Bearer ${CONFIG.ACCESS_TOKEN}`,
    };
    const url = `/loc/v1/features/${featureId}/products/categories`;
    return new ajax(CONFIG.BASE_URL, { headers }).get(url).then((response: any) => {
      resolve(response[0].categories);
    }).catch((error: Error) => {
      reject(error);
    });
  });
}

export function getProducts(featureId: string, start?: string, categoryId?: string, limit = 8): Promise<{ products: Feature.Profile.Product[], token?: string }> {
  return new Promise((resolve, reject) => {
    const headers = {
      'Authorization': `Bearer ${CONFIG.ACCESS_TOKEN}`,
    };
    const url = `/loc/v1/features/${featureId}/products?limit=${limit}${start ? `&start=${start}` : ''}${categoryId ? `&category_id=${categoryId}` : ''}`;
    return new ajax(CONFIG.BASE_URL, { headers }).get(url).then((response: any) => {
      const { token } = getLinkParams(response[1].link || '');
      resolve({
        products: response[0].products,
        token
      });
    }).catch((error: Error) => {
      reject(error);
    });
  });
}

export function getMedia(featureId: string, start?: string, categoryId?: string, limit = 16): Promise<{ media: Feature.Profile.Media[], token?: string }> {
  return new Promise((resolve, reject) => {
    const headers = {
      'Authorization': `Bearer ${CONFIG.ACCESS_TOKEN}`,
    };
    const url = `/loc/v1/features/${featureId}/media?limit=${limit}${start ? `&start=${start}` : ''}${categoryId ? `&category_id=${categoryId}` : ''}`;
    return new ajax(CONFIG.BASE_URL, { headers }).get(url).then((response: any) => {
      const { token } = getLinkParams(response[1].link || '');
      resolve({
        media: response[0].media,
        token
      });
    }).catch((error: Error) => {
      reject(error);
    });
  });
}
