import ajax from './ajax';
import { CONFIG } from 'utils/config';

const getLinkParams = (linkStr: string) => {
  const categoryIdMatch = linkStr.match(/category_id=([\w-%]+)?[\&]?/) || [];
  const limitMatch      = linkStr.match(/limit=([\w-%]+)?[\&]?/)       || [];
  const startMatch      = linkStr.match(/start=([\w-%]+)?[\&]?/)       || [];
  return {
    categoryId: categoryIdMatch[1],
    limit: limitMatch[1],
    token: startMatch[1],
  };
};

export function getMediaCategories(featureId: string): Promise<Feature.Profile.Category[]> {
  return new Promise((resolve, reject) => {
    const headers = {
      'Authorization': `Bearer ${CONFIG.ACCESS_TOKEN}`,
    };
    let url = `/loc/v1/features/${featureId}/media/categories?`;
    url += CONFIG.MEDIA_ID ? `&media_id=${CONFIG.MEDIA_ID}` : '';
    url += CONFIG.SESSION_ID ? `&session_id=${CONFIG.SESSION_ID}` : '';
    return new ajax(CONFIG.BASE_URL, { headers }).get(url).then((response: any) => {
      resolve(response[0].categories);
    }).catch((error: Error) => {
      reject(error);
    });
  });
}

export function getNews(
  featureId: string,
  start?: string,
  limit = 6,
): Promise<{ news: Feature.Profile.News[], token?: string }> {
  return new Promise((resolve, reject) => {
    const headers = {
      'Authorization': `Bearer ${CONFIG.ACCESS_TOKEN}`,
    };
    let url = `/loc/v1/features/${featureId}/news?limit=${limit}`;
    url += start ? `&start=${start}` : '';
    url += CONFIG.MEDIA_ID ? `&media_id=${CONFIG.MEDIA_ID}` : '';
    url += CONFIG.SESSION_ID ? `&session_id=${CONFIG.SESSION_ID}` : '';
    return new ajax(CONFIG.BASE_URL, { headers }).get(url).then((response: any) => {
      const { token } = getLinkParams(response[1].link || '');
      resolve({
        news: response[0].news,
        token
      });
    }).catch((error: Error) => {
      reject(error);
    });
  });
}

export function getProductCategories(featureId: string): Promise<Feature.Profile.Category[]> {
  return new Promise((resolve, reject) => {
    const headers = {
      'Authorization': `Bearer ${CONFIG.ACCESS_TOKEN}`,
    };
    let url = `/loc/v1/features/${featureId}/products/categories?`;
    url += CONFIG.MEDIA_ID ? `&media_id=${CONFIG.MEDIA_ID}` : '';
    url += CONFIG.SESSION_ID ? `&session_id=${CONFIG.SESSION_ID}` : '';
    return new ajax(CONFIG.BASE_URL, { headers }).get(url).then((response: any) => {
      resolve(response[0].categories);
    }).catch((error: Error) => {
      reject(error);
    });
  });
}

export function getProducts(
  featureId: string,
  start?: string,
  categoryId?: string,
  limit = 8
): Promise<{ products: Feature.Profile.Product[], token?: string }> {
  return new Promise((resolve, reject) => {
    const headers = {
      'Authorization': `Bearer ${CONFIG.ACCESS_TOKEN}`,
    };
    let url = `/loc/v1/features/${featureId}/products?limit=${limit}`;
    url += start ? `&start=${start}` : '';
    url += categoryId ? `&category_id=${categoryId}` : '';
    url += CONFIG.MEDIA_ID ? `&media_id=${CONFIG.MEDIA_ID}` : '';
    url += CONFIG.SESSION_ID ? `&session_id=${CONFIG.SESSION_ID}` : '';
    return new ajax(CONFIG.BASE_URL, { headers }).get(url).then((response: any) => {
      const { token } = getLinkParams(response[1].link || '');
      resolve({
        products: response[0].products,
        token
      });
    }).catch((error: Error) => {
      reject(error);
    });
  });
}

export function getMedia(
  featureId: string,
  start?: string,
  categoryId?: string,
  limit = 16
): Promise<{ media: Feature.Profile.Media[], token?: string }> {
  return new Promise((resolve, reject) => {
    const headers = {
      'Authorization': `Bearer ${CONFIG.ACCESS_TOKEN}`,
    };
    let url = `/loc/v1/features/${featureId}/media?limit=${limit}`;
    url += start ? `&start=${start}` : '';
    url += categoryId ? `&category_id=${categoryId}` : '';
    url += CONFIG.MEDIA_ID ? `&media_id=${CONFIG.MEDIA_ID}` : '';
    url += CONFIG.SESSION_ID ? `&session_id=${CONFIG.SESSION_ID}` : '';
    return new ajax(CONFIG.BASE_URL, { headers }).get(url).then((response: any) => {
      const { token } = getLinkParams(response[1].link || '');
      resolve({
        media: response[0].media,
        token
      });
    }).catch((error: Error) => {
      reject(error);
    });
  });
}
