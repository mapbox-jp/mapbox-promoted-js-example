class AjaxError extends Error implements Promoted.AjaxError {
  private _message: string;
  private _status?: number;
  private _name: string;
  private _url: string;

  constructor(message: string, status?: number, options: Promoted.AjaxError.Options = {}) {
    super();

    const { name, url } = options;

    this._message = message;
    this._status = status;
    this._name = name || 'Error';
    this._url = url || '';
  }

  get text() {
    return `${this._name} ${this._status}: url - ${this._url}, response - ${this._message}${this.stackAt && ` ${this.stackAt}`}`;
  }

  get message() {
    return this._message;
  }

  get status() {
    return this._status;
  }

  get name() {
    return this._name;
  }

  get url() {
    return this._url;
  }

  get stackAt() {
    if (!this.stack) {
      return '';
    }
    const match = this.stack.replace(/(\r\n|\n|\r)/gm, '').match(/^(.*) at (.*)$/);
    let stackAt = '';
    if (match && match.length > 2) {
      stackAt = match[2]
    }
    return stackAt ? `at ${stackAt}` : '';
  }
}

export default AjaxError;
