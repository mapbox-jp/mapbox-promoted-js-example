import ajax from './ajax';
import { CONFIG } from 'utils/config';

export function getFeatures(quadkey: string): Promise<GeoJSON.FeatureCollection<GeoJSON.Geometry>> {
  return new Promise((resolve, reject) => {
    const headers = {
      'Authorization': `Bearer ${CONFIG.ACCESS_TOKEN}`,
    };
    const url = `/loc/v1/features/quad/${quadkey}?scale=1`;
    return new ajax(CONFIG.BASE_URL, { headers }).get(url).then((response: any) => {
      resolve(response);
    }).catch((error: Error) => {
      reject(error);
    });
  });
}
