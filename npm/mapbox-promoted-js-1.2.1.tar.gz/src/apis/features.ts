import ajax from './ajax';
import { CONFIG } from 'utils/config';

export function getFeatures(quadkey: string, scaleIcon: number = 1): Promise<GeoJSON.FeatureCollection<GeoJSON.Geometry>> {
  return new Promise((resolve, reject) => {
    const headers = {
      'Authorization': `Bearer ${CONFIG.ACCESS_TOKEN}`,
    };
    const url = `/loc/v1/features/quad/${quadkey}?scale_icon=${scaleIcon}`;
    return new ajax(CONFIG.BASE_URL, { headers }).get(url).then((response: any) => {
      resolve(response[0]);
    }).catch((error: Error) => {
      reject(error);
    });
  });
}
