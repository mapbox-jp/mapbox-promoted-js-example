import openingHours from 'opening_hours';
import {
  format,
  isSameDay,
  isAfter,
  isBefore,
  startOfDay,
  endOfDay,
  startOfWeek,
  endOfWeek,
  differenceInMinutes,
  differenceInCalendarDays,
  addDays,
  getDay
} from 'date-fns';

export const DAYS = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
export const DAY_PAIRS = {
  sun: '日曜日',
  mon: '月曜日',
  tue: '火曜日',
  wed: '水曜日',
  thu: '木曜日',
  fri: '金曜日',
  sat: '土曜日',
};

export const parseBusinessHoursString = (
  businessHoursString: string,
  date: Date = new Date()
): { [key: string]: string[] } => {
  const tmpBusinessHours = parseBusinessHours(businessHoursString, date);
  const businessHours: { [key: string]: string[] } = {};
  for (const key of Object.keys(tmpBusinessHours)) {
    const { start, end } = tmpBusinessHours[key];
    businessHours[key] = [`${format(start, 'HH:mm')} ~ ${format(end, 'HH:mm')}`];
  }
  return businessHours;
};

export const parseBusinessHours = (
  businessHoursString: string,
  date: Date = new Date()
): {
  [key: string]: {
    start: Date;
    end: Date;
  }
} => {
  const startDateOfWeek = startOfWeek(date);
  const endDateOfWeek = endOfWeek(date);
  const oh = new openingHours(businessHoursString);
  const intervals = oh.getOpenIntervals(startDateOfWeek, endDateOfWeek);
  let businessHours: { [key: string]: { start: Date; end: Date; } } = {};
  for (const interval of intervals) {
    const start = interval[0] as Date;
    const end   = interval[1] as Date;
    if (isSameDay(start, end)) {
      const dayNo = getDay(start);
      const day = DAYS[dayNo];
      businessHours[day] = { start, end };
    } else {
      for (let index = 0; index <= differenceInCalendarDays(end, start); index ++) {
        const updatedStart = addDays(start, index);
        const dayNo = getDay(updatedStart);
        const day = DAYS[dayNo];
        businessHours[day] = { start: updatedStart, end: endOfDay(updatedStart) };
      }
    }
  }
  return businessHours;
};

const getNearestBusinessHours = (
  businessHours: {
    [key: string]: {
      start: Date;
      end: Date;
    }
  },
  now = new Date
) => {
  for (let index = 0; index < 7; index ++) {
    const dayNo = getDay(addDays(now, index));
    if (DAYS[dayNo] in businessHours) {
      return businessHours[DAYS[dayNo]];
    }
  }
  return '';
};

export const getBusinessHoursLabel = (businessHoursStr: string, now = new Date): string => {
  const businessHours = parseBusinessHours(businessHoursStr);
  const is24Hours = Object.keys(businessHours).length === 7 && !Object.keys(businessHours).find((key) => {
    const { start, end } = businessHours[key];
    return !(differenceInMinutes(start, startOfDay(start)) === 0 && differenceInMinutes(end, endOfDay(start)) === 0);
  });
  for (const day of Object.keys(businessHours)) {
    const { start, end } = businessHours[day];
    const isToday = isSameDay(now, start);
    const isRange = isAfter(now, start) && isBefore(now, end);
    const diffStart = differenceInMinutes(now, start);
    const diffEnd   = differenceInMinutes(end, now);
    const isRangeBefore20Min = isBefore(now, end)  && 0 < diffStart && diffStart <= 20;
    const isRangeAfter20Min  = isAfter(now, start) && 0 < diffEnd   && diffEnd   <= 20;
    if (is24Hours) { // 24時間営業
      return '24時間営業';
    } else if (isRangeBefore20Min) { // まもなく開店：xx:xx 〜 yy:yy
      return `まもなく開店： ${format(start, 'HH:mm')} 〜 ${format(end, 'HH:mm')}`;
    } else if (isRange) { // 営業中：xx:xx 〜 yy:yy
      return `営業中： ${format(start, 'HH:mm')} 〜 ${format(end, 'HH:mm')}`;
    } else if (isRangeAfter20Min) { // まもなく閉店：xx:xx 〜 yy:yy
      return `まもなく閉店： ${format(start, 'HH:mm')} 〜 ${format(end, 'HH:mm')}`;
    } else if (isToday) { // 営業時間外：営業開始 xx:xx 〜 yy:yy
      return `営業時間外： 営業開始 ${format(start, 'HH:mm')} 〜 ${format(end, 'HH:mm')}`;
    }
  }
  const nearestBusinessHours = getNearestBusinessHours(businessHours, now);
  if (nearestBusinessHours) { // 営業時間外：営業開始 ○ xx:xx〜yy:yy
    const { start, end } = nearestBusinessHours;
    const day = DAYS[getDay(start)];
    const dayLabel = DAY_PAIRS[day as 'mon'];
    return `営業時間外： 営業開始 ${dayLabel.slice(0, 1)} ${format(start, 'HH:mm')} 〜 ${format(end, 'HH:mm')}`;
  }
  return '詳細はお問い合わせください';
};
