import { CONFIG } from './config';

export const isSp = (): boolean => {
  return window.innerWidth <= CONFIG.MEDIUM_MAX_WIDTH;
};

export const isPc = (): boolean => {
  return window.innerWidth > CONFIG.MEDIUM_MAX_WIDTH;
};

export const isSmall = (): boolean => {
  return window.innerWidth <= CONFIG.SMALL_MAX_WIDTH;
};

export const isMedium = (): boolean => {
  return CONFIG.SMALL_MAX_WIDTH < window.innerWidth && window.innerWidth <= CONFIG.MEDIUM_MAX_WIDTH;
};

export const isLarge = (): boolean => {
  return CONFIG.MEDIUM_MAX_WIDTH < window.innerWidth;
};

export const insertEndpointElement = (className: string): void => {
  if (!CONFIG.CONTAINER) {
    throw new Error(`Filed to find element: ${CONFIG.CONTAINER}`);
  }
  const endpoint = document.createElement('div');
  endpoint.className = className;
  CONFIG.CONTAINER.appendChild(endpoint);
};

export const updateEndpointElement = (selector: string, updateClassName: string): void => {
  const targetElement = document.querySelector(selector);
  if (!targetElement) {
    throw new Error(`Filed to find element: ${selector}`);
  }
  targetElement.className = updateClassName;
};

export const removeEndpointElement = (selector: string): void => {
  const targetElement = document.querySelector(selector);
  if (targetElement && targetElement.parentNode) {
    targetElement.parentNode.removeChild(targetElement);
  }
};

export const observeElementExist = (target: string | HTMLElement, callback: () => void) => {
  let targetNode: HTMLElement | null;
  if (typeof target === 'string') {
    targetNode = document.querySelector(target);
  } else {
    targetNode = target;
  }
  if (!targetNode) {
    throw Error(`Failed getting target node. target: ${target}`);
  }

  const observer = new MutationObserver((_mutations) => {
    if (!document.body.contains(targetNode)) {
      observer.disconnect();
      callback();
    }
  });
  observer.observe(document.body, {
    characterData: true,
    subtree: true,
    childList: true,
    attributes: true,
  });
};
