/// <reference types="mapbox-gl" />
declare module 'mapbox-promoted-js' {
  namespace Promoted {
    namespace Core {
      type Options = {
        baseUrl?: string;
        logUrl?: string;
      };
    }

    type Tile = {
      x: number;
      y: number;
      z: number;
      quadkey: string;
    };

    class Event {
      type: EventTypes;
      data: Object;
      constructor(type: EventTypes, data?: Object);
    }

    const EVENT_TYPES: {
      readonly LOAD: 'load';
      readonly MOVEEND: 'moveend';
      readonly ZOOMEND: 'zoomend';
      readonly SOURCEDATA: 'sourcedata';
      readonly SOURCEDATAEND: 'sourcedataend';
      readonly CLICK_PIN: 'click_pin';

      readonly START_SESSION: 'start_session';
      readonly UPDATE_SESSION: 'update_session';
      readonly END_SESSION: 'end_session';

      readonly CLICK_POPUP: 'click_popup';
      readonly SHOW_POPUP: 'show_popup';
      readonly CLOSE_POPUP: 'close_popup';

      readonly CLICK_CARD: 'click_card';
      readonly SHOW_CARD: 'show_card';
      readonly UPDATE_CARD: 'update_card';
      readonly CLOSE_CARD: 'close_card';
    
      readonly CLICK_SIDE_CARD: 'click_side_card';
      readonly SHOW_SIDE_CARD: 'show_side_card';
      readonly UPDATE_SIDE_CARD: 'update_side_card';
      readonly OPEN_SIDE_CARD: 'open_side_card';
      readonly HIDE_SIDE_CARD: 'hide_side_card';
      readonly CLOSE_SIDE_CARD: 'close_side_card';
    }
    type EventTypes = typeof EVENT_TYPES[keyof typeof EVENT_TYPES];
    type Listener = (type: EventTypes, event: Promoted.EventData) => any;

    namespace Session {
      namespace Event {
        type Listener = (type: EventTypes, event: Promoted.EventData) => any;
        type Listeners = { [key: string]: Array<Listener> };
      }
  
      const EVENT_TYPES: {
        readonly START_SESSION: 'start_session';
        readonly UPDATE_SESSION: 'update_session';
        readonly END_SESSION: 'end_session';
      };
      type EventTypes = typeof EVENT_TYPES[keyof typeof EVENT_TYPES];

      class Event {
        type: EventTypes;
        data: Object;
        constructor(type: EventTypes, data?: Object);
      }
    }

    namespace EventData {
      type EventTypes = Promoted.EventTypes | Promoted.Session.EventTypes;
    }
  
    class EventData {
      type: EventData.EventTypes;
      data: Object;
      constructor(type: EventData.EventTypes, data?: Object);
    } 
  }

  export class Promoted {
    constructor(map: mapboxgl.Map, token: string, options?: Promoted.Core.Options);
    get map(): mapboxgl.Map;
    get sourceId(): string;
    get layerId(): string;
    get tilesets(): { [quadkey: string]: Feature[] };
    get features(): Feature[];
    public show(feature: Feature): void;
    public visibleLayer(): void;
    public hideLayer(): void;
    public reload(): void;
    public on(type: Promoted.EventTypes, listener: Promoted.Listener): void;
    public off(type: Promoted.EventTypes, listener: Promoted.Listener): void;
    public reload(): void;
  }

  namespace Feature {
    interface Properties {
      cps: string;
      icon?: string;
      advertizer?: string;
      category?: string;
      addressJa?: string;
      addressEn?: string;
      nameJa?: string;
      nameEn?: string;
      subtitle?: string;
      phoneNumber?: string;
      promotionBanner?: string;
      promotionBannerWidth?: number;
      promotionBannerHeight?: number;
      promotionCard?: string;
      promotionUrl?: string;
      displayPromotionInternal?: boolean;
      directions?: string;
      lat?: string;
      lng?: string;
      minZoom?: string;
      satOpen?: string;
      satClose?: string;
      sunOpen?: string;
      sunClose?: string;
      weekOpen?: string;
      weekClose?: string;
      holidayOpen?: string;
      holidayClose?: string;
    }
  }
  interface Feature extends mapboxgl.MapboxGeoJSONFeature {
    properties: Feature.Properties;
  }
}