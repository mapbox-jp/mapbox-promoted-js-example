# Web Promoted SDK 

## Exampleプロジェクト

下記のリポジトリにexampleプロジェクトを用意しています。<br />
https://github.com/mapbox-jp/mapbox-promoted-js-example

## Installation / インストール

1. Web Promoted SDKでは二つのJavaScriptファイルで導入の手続きが必要になります
* プロモーションのロジックを担当する**lib/core/commonjs/index.js**の導入
* map上にプロモーションを描画するweb componentとなる**lib/app/es/index.js**の導入

### npmを利用した導入

#### core/commonjs/index.jsの導入

1. package.jsonに配布された**mapbox-promoted-js-VERSION.tar.gz**へのパスを追記する

```
"dependencies": {
  ...
  "mapbox-gl": "1.13.0",
  "mapbox-promoted-js": "file:FILE_PATH/mapbox-promoted-js-1.0.0.tar.gz",
  "@types/mapbox-promoted-js": "file:FILE_PATH/mapbox-promoted-js-1.0.0.tar.gz",
},
```

2. npm installでパッケージをインストールする

#### app/es/index.jsの導入

1. **mapbox-promoted-js-VERSION.tar.gz**を解凍し、**lib/app/es/index.js**をプロジェクト配下に配置する（下記の例では**mapbox-promoted-js/app.js**に配置）
2. htmlにscriptを埋め込む

```
<html lang='en'>
  <head>
    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link href='https://api.tiles.mapbox.com/mapbox-gl-js/v2.3.0/mapbox-gl.css' rel='stylesheet'/>
    <script src='/mapbox-promoted-js/app.js'></script>
    <title>
      <%= title %>
    </title>
  </head>
  <body>
    <div id='app'></div>
  </body>
</html>
```

### CDNを利用した導入

#### core/commonjs/index.jsとapp/es/index.jsの導入

1. **mapbox-promoted-js-VERSION.tar.gz**を解凍し、**lib/app/es/index.js**と**lib/core/browser/index.js**のそれぞれをプロジェクト配下に配置する（下記の例では**lib/app/es/index.js**は**mapbox-promoted-js/app.js**に、**lib/core/browser/index.js**は**mapbox-promoted-js/core.js**に配置）
2. htmlにscriptを埋め込む

```
<html lang='en'>
  <head>
    <meta charset='utf-8'>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link href='https://api.tiles.mapbox.com/mapbox-gl-js/v2.3.0/mapbox-gl.css' rel='stylesheet'/>
    <script src='/mapbox-promoted-js/app.js'></script>
    <script src='/mapbox-promoted-js/core.js'></script>
    <title>
      <%= title %>
    </title>
  </head>
  <body>
    <div id='app'></div>
  </body>
</html>
```


# Documentation on Specification / 仕様ドキュメント

## Hello World

### npmを利用した方法

以下のコードを導入する事により広告が自動で配信されます。
Mapbox Studioで作成したTokenをMapboxPromotedの初期化時に第二引数に設定してください。

```
import mapboxgl from 'mapbox-gl';
import { Promoted } from 'mapbox-promoted-js';

const token = 'xxxxxxxxxxxxxxxxxxxxxxxxxxx';
mapboxgl.accessToken = token;
const map = new mapboxgl.Map({
  container: 'app',
  style: 'mapbox://styles/mapbox/streets-v11',
  center: [139.7746987, 35.6272648],
  zoom: 13
});
const promoted = new Promoted(map, token);
```

### CDNを利用した方法
```
const token = 'xxxxxxxxxxxxxxxxxxxxxxxxxxx';
window.mapboxgl.accessToken = token;
const map = new window.mapboxgl.Map({
  container: 'app',
  style: 'mapbox://styles/mapbox/streets-v11',
  center: [139.7746987, 35.6272648],
  zoom: 13
});
const promoted = new window.PromotedCore.Promoted(map, token);
```


## Mapbox Promoted API / メソッド

### Promotion Popup
```
// プロモーションポップアップを表示するメソッドです。
//（mapbox-promoted-js側で利用するためのメソッドになります）
window.showPromotionPopup(
  properties: Feature.Properties,
  onClick?: (type: Promotion.ClickTypes, adid: string) => void,
  onClose?: (adid: string) => void
);

// プロモーションポップアップをクローズするメソッドです。
window.closePromotionPopup();
```


## Callback API / コールバックメソッド

以下のコードを導入する事により各種コールバックイベントを発火させることができます。

```
promoted.on('load', (type: string, event: any) => console.log(type, event));
```

### Common Event

以下はイベントのタイプ、及びコールバックと戻り値になります。

```
promoted.on('load', (type: string, event: {
  map: mapboxgl.Map
}) => void);

promoted.on('moveend', (type: string, event: {
  map: mapboxgl.Map,
  originEvent: mapboxgl.MapboxEvent<any>.originalEvent
}) => void);

promoted.on('zoomend', (type: string, event: {
  map: mapboxgl.Map,
  originEvent: mapboxgl.MapboxEvent<any>.originalEvent
}) => void);

promoted.on('sourcedata', (type: string, event: {
  map: mapboxgl.Map,
  originEvent: mapboxgl.MapboxEvent<any>.originalEvent
  tiles: Tile[]
}) => void);

promoted.on('sourcedataend', (type: string, event: {
  map: mapboxgl.Map,
  originEvent: mapboxgl.MapboxEvent<any>.originalEvent
  visibledFeatures: Feature[],
  unvisibledFeatures: Feature[]
}) => void);

promoted.on('click_pin', (type: string, event: {
  map: mapboxgl.Map,
  originEvent: mapboxgl.MapboxEvent<any>.originalEvent
  feature: Feature
}) => void);

promoted.on('start_session', (type: string, event: {
  start: Date
}) => void);

promoted.on('update_session', (type: string, event: {
  start: Date
}) => void);

promoted.on('end_session', (type: string, event: {
  start: Date
}) => void);
```


### Promotion Popup Event

```
promoted.on('click_popup', (type: string, event: {
  clickType: 'popup' | 'banner' | 'phone' | 'directions' | 'detail',
  feature: Feature,
}) => void);
promoted.on('show_popup', event: { feature: Feature }) => void);
promoted.on('close_popup', event: { feature: Feature }) => void);
```


## デバッグモードで実行

デバッグモードで実行することで、プロモーションのクリックやピンの表示によるイベントログを発火を防ぎます。
本番環境以外の環境では"debug: true"を追記するようにしてください。

```
const promoted = new MapboxPromoted(
  map,
  MAPBOX_TOKEN,
  {
    debug: true,
  }
);
```


## テスト環境に接続

以下のコードを導入する事により環境を変更することができます。
各種パラメタについては配布されたものを利用してください。

```
const promoted = new MapboxPromoted(
  map,
  MAPBOX_TOKEN,
  {
    baseUrl: PROMOTED_BASE_URL,
    logUrl: PROMOTED_LOG_URL,
  }
);
```
